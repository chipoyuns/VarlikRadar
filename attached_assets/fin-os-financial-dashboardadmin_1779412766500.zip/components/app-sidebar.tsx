"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useState } from "react"
import {
  Briefcase,
  ArrowLeftRight,
  Wallet,
  Target,
  CreditCard,
  TrendingUp,
  Sparkles,
  FileBarChart,
  Settings,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Shield,
  Eye,
  Bell,
  Lock,
  Palette,
  Globe,
  Crown,
  Database,
} from "lucide-react"
import { cn } from "@/lib/utils"

// Mock user - admin role for visibility
const currentUser = { role: "admin" }

const mainNavItems = [
  { href: "/", label: "Portfoyum", icon: Briefcase },
  { href: "/islemler", label: "Islemler", icon: ArrowLeftRight },
  { href: "/butce", label: "Butce", icon: Wallet },
  { href: "/hedefler", label: "Hedefler", icon: Target },
  { href: "/borclar", label: "Borclar", icon: CreditCard },
  { href: "/simulator", label: "Simulator", icon: TrendingUp },
  { href: "/ai-koc", label: "AI Koc", icon: Sparkles },
  { href: "/reports", label: "Raporlar", icon: FileBarChart },
]

const settingsSubItems = [
  { href: "/settings", label: "Genel", icon: Settings },
  { href: "/settings/gorunum", label: "Gorunum", icon: Palette },
  { href: "/settings/bildirimler", label: "Bildirimler", icon: Bell },
  { href: "/settings/gizlilik", label: "Gizlilik", icon: Lock },
  { href: "/settings/bolgesel", label: "Bolgesel", icon: Globe },
  { href: "/settings/premium", label: "Premium", icon: Crown },
  { href: "/settings/yedekleme", label: "Yedekleme", icon: Database },
]

const adminSubItems = [
  { href: "/admin", label: "Genel Bakis", icon: Eye },
  { href: "/admin/kullanicilar", label: "Kullanicilar", icon: Briefcase },
  { href: "/admin/uyeler", label: "Uyeler", icon: CreditCard },
  { href: "/admin/istatistikler", label: "Istatistikler", icon: TrendingUp },
  { href: "/admin/icerik", label: "Icerik", icon: FileBarChart },
  { href: "/admin/sistem", label: "Sistem", icon: Database },
  { href: "/admin/guvenlik", label: "Guvenlik", icon: Shield },
  { href: "/admin/ayarlar", label: "Ayarlar", icon: Settings },
  { href: "/admin/destek", label: "Destek", icon: Sparkles },
]

export function AppSidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(pathname.startsWith("/settings"))
  const [adminOpen, setAdminOpen] = useState(pathname.startsWith("/admin"))

  const isAdmin = currentUser.role === "admin" || currentUser.role === "superadmin"

  return (
    <aside
      className={cn(
        "fixed left-0 top-0 h-screen bg-[#0E1117] border-r border-[rgba(255,255,255,0.06)] flex flex-col transition-all duration-300 z-50",
        collapsed ? "w-[72px]" : "w-[220px]"
      )}
    >
      {/* Logo */}
      <div className="p-4 border-b border-[rgba(255,255,255,0.06)]">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#00D4AA] glow-green flex items-center justify-center flex-shrink-0">
            <span className="text-[#080A0F] font-bold text-lg">F</span>
          </div>
          {!collapsed && (
            <div className="overflow-hidden">
              <h1 className="text-lg font-semibold text-[#F0F2F7] tracking-tight">FinOS</h1>
              <p className="text-[10px] text-[#4E5A6B] leading-tight">Yatirim Platformu</p>
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto finos-scrollbar">
        {/* Main Nav Items */}
        {mainNavItems.map((item) => {
          const isActive = pathname === item.href
          const Icon = item.icon
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group relative",
                isActive
                  ? "bg-[rgba(0,212,170,0.08)] text-[#00D4AA]"
                  : "text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)] hover:text-[#F0F2F7]"
              )}
            >
              {isActive && (
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-6 bg-[#00D4AA] rounded-r-full" />
              )}
              <Icon className={cn("w-5 h-5 flex-shrink-0", isActive && "text-[#00D4AA]")} />
              {!collapsed && (
                <span className="text-sm font-medium truncate">{item.label}</span>
              )}
            </Link>
          )
        })}

        {/* Settings with Sub Menu */}
        <div>
          <button
            onClick={() => !collapsed && setSettingsOpen(!settingsOpen)}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group relative",
              pathname.startsWith("/settings")
                ? "bg-[rgba(0,212,170,0.08)] text-[#00D4AA]"
                : "text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)] hover:text-[#F0F2F7]"
            )}
          >
            {pathname.startsWith("/settings") && (
              <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-6 bg-[#00D4AA] rounded-r-full" />
            )}
            <Settings className={cn("w-5 h-5 flex-shrink-0", pathname.startsWith("/settings") && "text-[#00D4AA]")} />
            {!collapsed && (
              <>
                <span className="text-sm font-medium truncate flex-1 text-left">Ayarlar</span>
                <ChevronDown className={cn("w-4 h-4 transition-transform", settingsOpen && "rotate-180")} />
              </>
            )}
          </button>
          
          {/* Settings Sub Items */}
          {!collapsed && settingsOpen && (
            <div className="ml-4 mt-1 space-y-1 border-l border-[rgba(255,255,255,0.06)] pl-3">
              {settingsSubItems.map((item) => {
                const isActive = pathname === item.href
                const Icon = item.icon
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      "flex items-center gap-2 px-2 py-2 rounded-lg transition-all duration-200 text-xs",
                      isActive
                        ? "bg-[rgba(0,212,170,0.08)] text-[#00D4AA]"
                        : "text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)] hover:text-[#F0F2F7]"
                    )}
                  >
                    <Icon className="w-4 h-4 flex-shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </Link>
                )
              })}
            </div>
          )}
        </div>

        {/* Admin with Sub Menu - Only for Admins */}
        {isAdmin && (
          <div>
            <button
              onClick={() => !collapsed && setAdminOpen(!adminOpen)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group relative",
                pathname.startsWith("/admin")
                  ? "bg-[rgba(255,71,87,0.08)] text-[#FF4757]"
                  : "text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)] hover:text-[#F0F2F7]"
              )}
            >
              {pathname.startsWith("/admin") && (
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-6 bg-[#FF4757] rounded-r-full" />
              )}
              <div className="relative">
                <Shield className={cn("w-5 h-5 flex-shrink-0", pathname.startsWith("/admin") && "text-[#FF4757]")} />
                {/* Pulsing red dot */}
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-[#FF4757] rounded-full animate-pulse" />
              </div>
              {!collapsed && (
                <>
                  <span className="text-sm font-medium truncate flex-1 text-left">Admin</span>
                  <span className="px-1.5 py-0.5 text-[9px] font-bold bg-[#FF4757] text-white rounded">
                    ADMIN
                  </span>
                  <ChevronDown className={cn("w-4 h-4 transition-transform", adminOpen && "rotate-180")} />
                </>
              )}
            </button>
            
            {/* Admin Sub Items */}
            {!collapsed && adminOpen && (
              <div className="ml-4 mt-1 space-y-1 border-l border-[rgba(255,71,87,0.2)] pl-3">
                {adminSubItems.map((item) => {
                  const isActive = pathname === item.href
                  const Icon = item.icon
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={cn(
                        "flex items-center gap-2 px-2 py-2 rounded-lg transition-all duration-200 text-xs",
                        isActive
                          ? "bg-[rgba(255,71,87,0.08)] text-[#FF4757]"
                          : "text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)] hover:text-[#F0F2F7]"
                      )}
                    >
                      <Icon className="w-4 h-4 flex-shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </Link>
                  )
                })}
              </div>
            )}
          </div>
        )}
      </nav>

      {/* User Profile */}
      <div className="p-3 border-t border-[rgba(255,255,255,0.06)]">
        <div className={cn("flex items-center gap-3", collapsed && "justify-center")}>
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#4B9EFF] to-[#A78BFA] flex items-center justify-center flex-shrink-0">
            <span className="text-white font-semibold text-sm">AY</span>
          </div>
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-[#F0F2F7] truncate">Ahmet Y.</span>
                <span className="px-1.5 py-0.5 text-[9px] font-bold bg-[#FFB833] text-[#080A0F] rounded glow-gold">
                  PRO
                </span>
              </div>
              <p className="text-[10px] text-[#4E5A6B]">Premium Uye</p>
            </div>
          )}
        </div>
      </div>

      {/* Collapse Button */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-[#151A23] border border-[rgba(255,255,255,0.1)] rounded-full flex items-center justify-center text-[#8892A4] hover:text-[#F0F2F7] hover:bg-[#1a2030] transition-colors"
      >
        {collapsed ? <ChevronRight className="w-3 h-3" /> : <ChevronLeft className="w-3 h-3" />}
      </button>
    </aside>
  )
}
