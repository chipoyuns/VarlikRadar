"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { formatCurrency } from "@/components/ui/finos-components"
import { portfolioSummary } from "@/lib/mock-data"
import { 
  TrendingUp, 
  TrendingDown,
  Calculator,
  Target,
  Clock,
  Bitcoin,
  DollarSign,
  Coins,
  CircleDot,
  AlertTriangle,
  Baby,
  Home,
  Briefcase,
  Heart,
  Sparkles,
  ChevronRight,
  Zap,
} from "lucide-react"
import { useState, useMemo } from "react"
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  Legend,
  ReferenceLine,
} from "recharts"

// Geçmiş verisi için mock data
const historicalData = {
  bitcoin: [
    { year: "2020", value: 100 },
    { year: "2021", value: 580 },
    { year: "2022", value: 320 },
    { year: "2023", value: 850 },
    { year: "2024", value: 1560 },
    { year: "2025", value: 2340 },
  ],
  gold: [
    { year: "2020", value: 100 },
    { year: "2021", value: 125 },
    { year: "2022", value: 155 },
    { year: "2023", value: 245 },
    { year: "2024", value: 389 },
    { year: "2025", value: 489 },
  ],
  bist100: [
    { year: "2020", value: 100 },
    { year: "2021", value: 178 },
    { year: "2022", value: 265 },
    { year: "2023", value: 412 },
    { year: "2024", value: 489 },
    { year: "2025", value: 612 },
  ],
  usd: [
    { year: "2020", value: 100 },
    { year: "2021", value: 145 },
    { year: "2022", value: 198 },
    { year: "2023", value: 265 },
    { year: "2024", value: 312 },
    { year: "2025", value: 385 },
  ],
}

// Comparison chart data
const comparisonData = historicalData.bitcoin.map((item, index) => ({
  year: item.year,
  bitcoin: item.value,
  gold: historicalData.gold[index].value,
  bist100: historicalData.bist100[index].value,
  usd: historicalData.usd[index].value,
}))

// Kriz senaryoları
const crisisScenarios = [
  { 
    id: "2008", 
    name: "2008 Küresel Krizi", 
    description: "-45% global hisse, -30% kripto",
    impact: { crypto: -30, stock: -45, bond: -10, gold: 15 },
    recoveryMonths: 36,
  },
  { 
    id: "2020", 
    name: "2020 COVID Dip", 
    description: "-35% kripto, -25% hisse",
    impact: { crypto: -35, stock: -25, bond: -5, gold: 8 },
    recoveryMonths: 18,
  },
  { 
    id: "2021", 
    name: "2021 Kripto Kışı", 
    description: "-80% BTC/ETH",
    impact: { crypto: -80, stock: -5, bond: 0, gold: 2 },
    recoveryMonths: 24,
  },
  { 
    id: "2022", 
    name: "2022 TL Krizi", 
    description: "Özel Türkiye senaryosu",
    impact: { crypto: 10, stock: -20, bond: -15, gold: 45 },
    recoveryMonths: 12,
  },
]

// Hayat senaryoları
const lifeScenarios = [
  { id: "baby", name: "Çocuk Olursa", icon: Baby, monthlyExpense: 8000, fireImpact: 6 },
  { id: "house", name: "Ev Alırsam", icon: Home, monthlyExpense: 15000, fireImpact: 4 },
  { id: "jobless", name: "İşsiz Kalırsam", icon: Briefcase, monthlyExpense: -85000, fireImpact: 12 },
  { id: "marriage", name: "Evlenirsem", icon: Heart, monthlyExpense: 5000, fireImpact: 3 },
]

export default function SimulatorPage() {
  const [activeTab, setActiveTab] = useState<"past" | "future" | "crisis" | "life">("past")
  
  // Tab 1: Geçmiş states
  const [pastAmount, setPastAmount] = useState(100000)
  const [pastDate, setPastDate] = useState("2020-01")
  
  // Tab 2: Gelecek states
  const [monthlyContribution, setMonthlyContribution] = useState(5000)
  const [futureYears, setFutureYears] = useState(10)
  const [annualReturn, setAnnualReturn] = useState(12)
  const [initialCapital, setInitialCapital] = useState(50000)
  
  // Tab 3: Kriz states
  const [selectedCrisis, setSelectedCrisis] = useState(crisisScenarios[0])
  const [customImpact, setCustomImpact] = useState(-30)
  
  // Tab 4: Hayat states
  const [selectedLifeScenario, setSelectedLifeScenario] = useState(lifeScenarios[0])

  // Calculate past results
  const pastResults = useMemo(() => {
    const multipliers = {
      bitcoin: 23.4,
      gold: 4.89,
      bist100: 6.12,
      usd: 3.85,
    }
    return [
      { name: "Bitcoin", icon: Bitcoin, value: pastAmount * multipliers.bitcoin, return: (multipliers.bitcoin - 1) * 100, color: "#FFB833" },
      { name: "Altın", icon: Coins, value: pastAmount * multipliers.gold, return: (multipliers.gold - 1) * 100, color: "#FFD700" },
      { name: "BIST 100", icon: TrendingUp, value: pastAmount * multipliers.bist100, return: (multipliers.bist100 - 1) * 100, color: "#4B9EFF" },
      { name: "USD", icon: DollarSign, value: pastAmount * multipliers.usd, return: (multipliers.usd - 1) * 100, color: "#00D4AA" },
    ]
  }, [pastAmount])

  // Calculate future projections
  const futureProjections = useMemo(() => {
    const scenarios = [
      { name: "Kötümser", rate: annualReturn / 2, color: "#8892A4" },
      { name: "Baz", rate: annualReturn, color: "#00D4AA" },
      { name: "İyimser", rate: annualReturn * 1.5, color: "#FFB833" },
    ]
    
    return scenarios.map(scenario => {
      let value = initialCapital
      const monthlyRate = scenario.rate / 100 / 12
      
      for (let year = 0; year < futureYears; year++) {
        for (let month = 0; month < 12; month++) {
          value = value * (1 + monthlyRate) + monthlyContribution
        }
      }
      
      return { ...scenario, finalValue: Math.round(value) }
    })
  }, [monthlyContribution, futureYears, annualReturn, initialCapital])

  // Future projection chart data
  const futureChartData = useMemo(() => {
    const data = []
    const scenarios = [
      { name: "pessimistic", rate: annualReturn / 2 },
      { name: "base", rate: annualReturn },
      { name: "optimistic", rate: annualReturn * 1.5 },
    ]
    
    for (let year = 0; year <= futureYears; year++) {
      const point: Record<string, number | string> = { year: `${2025 + year}` }
      
      scenarios.forEach(scenario => {
        let value = initialCapital
        const monthlyRate = scenario.rate / 100 / 12
        
        for (let y = 0; y < year; y++) {
          for (let month = 0; month < 12; month++) {
            value = value * (1 + monthlyRate) + monthlyContribution
          }
        }
        
        point[scenario.name] = Math.round(value)
      })
      
      data.push(point)
    }
    
    return data
  }, [monthlyContribution, futureYears, annualReturn, initialCapital])

  // Crisis impact calculation
  const crisisImpact = useMemo(() => {
    const currentValue = portfolioSummary.totalAsset
    const totalImpact = selectedCrisis.impact.crypto * 0.4 + 
                       selectedCrisis.impact.stock * 0.3 + 
                       selectedCrisis.impact.bond * 0.2 + 
                       selectedCrisis.impact.gold * 0.1
    const afterValue = currentValue * (1 + totalImpact / 100)
    const damage = currentValue - afterValue
    
    return {
      before: currentValue,
      after: afterValue,
      damage,
      damagePercent: Math.abs(totalImpact),
      recoveryMonths: selectedCrisis.recoveryMonths,
    }
  }, [selectedCrisis])

  // Life scenario impact
  const lifeImpact = useMemo(() => {
    const currentFireAge = 41
    const newFireAge = currentFireAge + selectedLifeScenario.fireImpact
    const monthlyExpenseChange = selectedLifeScenario.monthlyExpense
    
    // 5-year wealth projection
    const currentMonthlyIncome = 110000
    const currentMonthlyExpense = 56000
    const newMonthlyExpense = currentMonthlyExpense + monthlyExpenseChange
    
    const beforeProjection = []
    const afterProjection = []
    let beforeWealth = portfolioSummary.totalAsset
    let afterWealth = portfolioSummary.totalAsset
    
    for (let year = 0; year <= 5; year++) {
      beforeProjection.push({ year: `${2025 + year}`, value: Math.round(beforeWealth) })
      afterProjection.push({ year: `${2025 + year}`, value: Math.round(afterWealth) })
      
      beforeWealth = beforeWealth * 1.1 + (currentMonthlyIncome - currentMonthlyExpense) * 12
      afterWealth = afterWealth * 1.1 + (currentMonthlyIncome - newMonthlyExpense) * 12
    }
    
    return {
      currentFireAge,
      newFireAge,
      monthlyExpenseChange,
      beforeProjection,
      afterProjection,
    }
  }, [selectedLifeScenario])

  const tabs = [
    { id: "past" as const, label: "📈 Geçmiş (Ya Atsaydın?)" },
    { id: "future" as const, label: "🔮 Gelecek (Ne Olur?)" },
    { id: "crisis" as const, label: "💥 Kriz Senaryosu" },
    { id: "life" as const, label: "🧬 Hayat Senaryosu" },
  ]

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-semibold text-[#F0F2F7]">Simülatör</h1>
          <p className="text-sm text-[#8892A4]">Yatırım senaryolarını test edin</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg">
            <Sparkles className="w-4 h-4 text-[#A78BFA]" />
            <span className="text-xs text-[#8892A4]">AI Destekli</span>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-2 mb-6 p-1 bg-[#0E1117] rounded-xl border border-[rgba(255,255,255,0.06)]">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === tab.id
                ? "bg-[#151A23] text-[#F0F2F7] border border-[rgba(255,255,255,0.1)]"
                : "text-[#8892A4] hover:text-[#F0F2F7] hover:bg-[rgba(255,255,255,0.04)]"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab 1: Geçmiş Simülatörü */}
      {activeTab === "past" && (
        <div className="space-y-6">
          {/* Title & Inputs */}
          <div className="finos-card p-6">
            <h2 className="text-xl font-semibold text-[#F0F2F7] mb-4">
              {"Eğer X yıl önce yatırsaydın..."}
            </h2>
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="text-[#8892A4]">₺</span>
                <input
                  type="number"
                  value={pastAmount}
                  onChange={(e) => setPastAmount(Number(e.target.value) || 0)}
                  className="w-32 px-3 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm font-mono text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]"
                />
              </div>
              <span className="text-[#8892A4]">tarihten itibaren</span>
              <select
                value={pastDate}
                onChange={(e) => setPastDate(e.target.value)}
                className="px-3 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]"
              >
                <option value="2020-01">Ocak 2020</option>
                <option value="2021-01">Ocak 2021</option>
                <option value="2022-01">Ocak 2022</option>
                <option value="2023-01">Ocak 2023</option>
              </select>
              <button className="px-4 py-2 bg-[#00D4AA] rounded-lg text-sm font-medium text-[#080A0F] hover:bg-[#00D4AA]/90 transition-colors">
                Hesapla
              </button>
            </div>
          </div>

          {/* Results Grid */}
          <div className="grid grid-cols-4 gap-4">
            {pastResults.map((result) => (
              <div key={result.name} className="finos-card p-5">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 rounded-lg bg-[#151A23] flex items-center justify-center">
                    <result.icon className="w-4 h-4" style={{ color: result.color }} />
                  </div>
                  <span className="text-sm font-medium text-[#F0F2F7]">{result.name}</span>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-[#4E5A6B]">Başlangıç: {formatCurrency(pastAmount)}</p>
                  <p className="text-2xl font-semibold font-mono text-[#00D4AA]">
                    {formatCurrency(result.value)}
                  </p>
                  <p className="text-lg font-mono text-[#00D4AA]">
                    +%{result.return.toLocaleString("tr-TR", { maximumFractionDigits: 0 })}
                  </p>
                </div>
                {/* Mini sparkline */}
                <div className="h-12 mt-3">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={historicalData[result.name.toLowerCase().replace(" ", "") as keyof typeof historicalData] || historicalData.bitcoin}>
                      <defs>
                        <linearGradient id={`spark-${result.name}`} x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={result.color} stopOpacity={0.3} />
                          <stop offset="95%" stopColor={result.color} stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <Area
                        type="monotone"
                        dataKey="value"
                        stroke={result.color}
                        strokeWidth={2}
                        fill={`url(#spark-${result.name})`}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            ))}
          </div>

          {/* Comparison Chart */}
          <div className="finos-card p-6">
            <h3 className="text-lg font-semibold text-[#F0F2F7] mb-4">Karşılaştırma Grafiği</h3>
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={comparisonData}>
                  <XAxis 
                    dataKey="year" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: '#4E5A6B', fontSize: 12 }}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: '#4E5A6B', fontSize: 12 }}
                    tickFormatter={(value) => `%${value}`}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0E1117',
                      border: '1px solid rgba(255,255,255,0.1)',
                      borderRadius: '8px',
                      color: '#F0F2F7',
                    }}
                    formatter={(value: number, name: string) => [
                      `%${value}`,
                      name === "bitcoin" ? "Bitcoin" : name === "gold" ? "Altın" : name === "bist100" ? "BIST 100" : "Dolar"
                    ]}
                  />
                  <Legend 
                    formatter={(value) => value === "bitcoin" ? "Bitcoin" : value === "gold" ? "Altın" : value === "bist100" ? "BIST 100" : "Dolar"}
                    wrapperStyle={{ color: '#8892A4' }}
                  />
                  <Line type="monotone" dataKey="bitcoin" stroke="#FFB833" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="gold" stroke="#FFD700" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="bist100" stroke="#4B9EFF" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="usd" stroke="#00D4AA" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Gelecek Simülatörü */}
      {activeTab === "future" && (
        <div className="grid grid-cols-3 gap-6">
          {/* Input Panel */}
          <div className="space-y-4">
            <div className="finos-card p-5">
              <h3 className="text-lg font-semibold text-[#F0F2F7] mb-4">Parametreler</h3>
              
              <div className="space-y-5">
                <div>
                  <label className="flex items-center justify-between text-sm text-[#8892A4] mb-2">
                    <span>Her ay</span>
                    <span className="font-mono text-[#F0F2F7]">{formatCurrency(monthlyContribution)}</span>
                  </label>
                  <input
                    type="range"
                    min="1000"
                    max="50000"
                    step="500"
                    value={monthlyContribution}
                    onChange={(e) => setMonthlyContribution(parseInt(e.target.value))}
                    className="w-full h-2 bg-[#151A23] rounded-lg appearance-none cursor-pointer accent-[#00D4AA]"
                  />
                  <div className="flex justify-between text-xs text-[#4E5A6B] mt-1">
                    <span>₺1.000</span>
                    <span>₺50.000</span>
                  </div>
                </div>

                <div>
                  <label className="flex items-center justify-between text-sm text-[#8892A4] mb-2">
                    <span>Yıl boyunca</span>
                    <span className="font-mono text-[#F0F2F7]">{futureYears} yıl</span>
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="40"
                    value={futureYears}
                    onChange={(e) => setFutureYears(parseInt(e.target.value))}
                    className="w-full h-2 bg-[#151A23] rounded-lg appearance-none cursor-pointer accent-[#00D4AA]"
                  />
                  <div className="flex justify-between text-xs text-[#4E5A6B] mt-1">
                    <span>1 yıl</span>
                    <span>40 yıl</span>
                  </div>
                </div>

                <div>
                  <label className="flex items-center justify-between text-sm text-[#8892A4] mb-2">
                    <span>Yıllık getiri</span>
                    <span className="font-mono text-[#F0F2F7]">%{annualReturn}</span>
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="30"
                    value={annualReturn}
                    onChange={(e) => setAnnualReturn(parseInt(e.target.value))}
                    className="w-full h-2 bg-[#151A23] rounded-lg appearance-none cursor-pointer accent-[#00D4AA]"
                  />
                  <div className="flex justify-between text-xs text-[#4E5A6B] mt-1">
                    <span>%1</span>
                    <span>%30</span>
                  </div>
                </div>

                <div>
                  <label className="block text-sm text-[#8892A4] mb-2">Başlangıç sermayesi</label>
                  <input
                    type="text"
                    value={formatCurrency(initialCapital)}
                    onChange={(e) => {
                      const value = parseInt(e.target.value.replace(/[^0-9]/g, '')) || 0
                      setInitialCapital(value)
                    }}
                    className="w-full px-3 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm font-mono text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Results & Chart */}
          <div className="col-span-2 space-y-4">
            {/* Scenario Results */}
            <div className="grid grid-cols-3 gap-4">
              {futureProjections.map((projection) => (
                <div 
                  key={projection.name} 
                  className={`finos-card p-5 ${projection.name === "Baz" ? "glow-green" : ""}`}
                >
                  <div className="flex items-center gap-2 mb-3">
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: projection.color }}
                    />
                    <span className="text-sm text-[#8892A4]">
                      {projection.name} (%{projection.rate})
                    </span>
                  </div>
                  <p 
                    className="text-2xl font-semibold font-mono"
                    style={{ color: projection.color }}
                  >
                    {formatCurrency(projection.finalValue)}
                  </p>
                </div>
              ))}
            </div>

            {/* Projection Chart */}
            <div className="finos-card p-6">
              <h3 className="text-lg font-semibold text-[#F0F2F7] mb-4">Projeksiyon</h3>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={futureChartData}>
                    <defs>
                      <linearGradient id="colorOptimistic" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#FFB833" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#FFB833" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorBase" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#00D4AA" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#00D4AA" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorPessimistic" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8892A4" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#8892A4" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis 
                      dataKey="year" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#4E5A6B', fontSize: 12 }}
                    />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#4E5A6B', fontSize: 12 }}
                      tickFormatter={(value) => `₺${(value / 1000000).toFixed(1)}M`}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0E1117',
                        border: '1px solid rgba(255,255,255,0.1)',
                        borderRadius: '8px',
                        color: '#F0F2F7',
                      }}
                      formatter={(value: number, name: string) => [
                        formatCurrency(value),
                        name === "optimistic" ? "İyimser" : name === "base" ? "Baz" : "Kötümser"
                      ]}
                    />
                    {/* Milestone lines */}
                    <ReferenceLine y={1000000} stroke="#4E5A6B" strokeDasharray="3 3" label={{ value: '1M', fill: '#4E5A6B', fontSize: 10 }} />
                    <ReferenceLine y={2000000} stroke="#4E5A6B" strokeDasharray="3 3" label={{ value: '2M', fill: '#4E5A6B', fontSize: 10 }} />
                    <Area
                      type="monotone"
                      dataKey="optimistic"
                      stroke="#FFB833"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorOptimistic)"
                    />
                    <Area
                      type="monotone"
                      dataKey="base"
                      stroke="#00D4AA"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorBase)"
                    />
                    <Area
                      type="monotone"
                      dataKey="pessimistic"
                      stroke="#8892A4"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorPessimistic)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Kriz Senaryosu */}
      {activeTab === "crisis" && (
        <div className="space-y-6">
          <div className="finos-card p-6">
            <div className="flex items-center gap-3 mb-4">
              <AlertTriangle className="w-6 h-6 text-[#FF4757]" />
              <h2 className="text-xl font-semibold text-[#F0F2F7]">
                {"Portföyün Krizlere Karşı Ne Kadar Dayanıklı?"}
              </h2>
            </div>
            
            {/* Scenario Selection */}
            <div className="grid grid-cols-4 gap-4 mb-6">
              {crisisScenarios.map((scenario) => (
                <button
                  key={scenario.id}
                  onClick={() => setSelectedCrisis(scenario)}
                  className={`p-4 rounded-xl border text-left transition-all ${
                    selectedCrisis.id === scenario.id
                      ? 'border-[#FF4757] bg-[rgba(255,71,87,0.08)]'
                      : 'border-[rgba(255,255,255,0.06)] hover:border-[rgba(255,255,255,0.1)]'
                  }`}
                >
                  <span className="text-sm font-medium text-[#F0F2F7] block mb-1">
                    {scenario.name}
                  </span>
                  <span className="text-xs text-[#4E5A6B]">{scenario.description}</span>
                </button>
              ))}
            </div>

            {/* Custom Slider */}
            <div className="finos-card-inner p-4 mb-6">
              <label className="flex items-center justify-between text-sm text-[#8892A4] mb-2">
                <span>Özel Etki</span>
                <span className="font-mono text-[#FF4757]">%{customImpact}</span>
              </label>
              <input
                type="range"
                min="-80"
                max="0"
                value={customImpact}
                onChange={(e) => setCustomImpact(parseInt(e.target.value))}
                className="w-full h-2 bg-[#151A23] rounded-lg appearance-none cursor-pointer accent-[#FF4757]"
              />
            </div>
          </div>

          {/* Impact Results */}
          <div className="grid grid-cols-3 gap-6">
            <div className="finos-card p-6">
              <div className="flex items-center gap-2 mb-4">
                <CircleDot className="w-5 h-5 text-[#4B9EFF]" />
                <span className="text-sm text-[#8892A4]">Kriz Öncesi</span>
              </div>
              <p className="text-3xl font-semibold font-mono text-[#F0F2F7]">
                {formatCurrency(crisisImpact.before)}
              </p>
            </div>

            <div className="finos-card p-6 glow-red">
              <div className="flex items-center gap-2 mb-4">
                <TrendingDown className="w-5 h-5 text-[#FF4757]" />
                <span className="text-sm text-[#8892A4]">Kriz Sonrası</span>
              </div>
              <p className="text-3xl font-semibold font-mono text-[#FF4757]">
                {formatCurrency(crisisImpact.after)}
              </p>
            </div>

            <div className="finos-card p-6">
              <div className="flex items-center gap-2 mb-4">
                <Zap className="w-5 h-5 text-[#FF4757]" />
                <span className="text-sm text-[#8892A4]">Hasar</span>
              </div>
              <p className="text-3xl font-semibold font-mono text-[#FF4757]">
                -{formatCurrency(crisisImpact.damage)}
              </p>
              <p className="text-lg font-mono text-[#FF4757]">
                (-%{crisisImpact.damagePercent.toFixed(1)})
              </p>
            </div>
          </div>

          {/* Recovery Info */}
          <div className="finos-card p-6">
            <div className="flex items-center gap-3 mb-4">
              <Clock className="w-5 h-5 text-[#4B9EFF]" />
              <h3 className="text-lg font-semibold text-[#F0F2F7]">Toparlanma Süresi</h3>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex-1 h-4 bg-[#151A23] rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-[#FF4757] via-[#FFB833] to-[#00D4AA] rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, (crisisImpact.recoveryMonths / 36) * 100)}%` }}
                />
              </div>
              <span className="text-lg font-semibold font-mono text-[#F0F2F7]">
                {crisisImpact.recoveryMonths} ay
              </span>
            </div>
            <p className="text-sm text-[#8892A4] mt-2">
              Bu krizden çıkmak tarihsel olarak {crisisImpact.recoveryMonths} ay sürmüştür
            </p>
          </div>

          {/* Asset Breakdown */}
          <div className="finos-card p-6">
            <h3 className="text-lg font-semibold text-[#F0F2F7] mb-4">Varlık Bazlı Etki</h3>
            <div className="grid grid-cols-4 gap-4">
              {Object.entries(selectedCrisis.impact).map(([asset, impact]) => (
                <div key={asset} className="finos-card-inner p-4">
                  <span className="text-sm text-[#8892A4] capitalize block mb-2">
                    {asset === "crypto" ? "Kripto" : asset === "stock" ? "Hisse" : asset === "bond" ? "Tahvil" : "Altın"}
                  </span>
                  <p className={`text-xl font-semibold font-mono ${impact >= 0 ? "text-[#00D4AA]" : "text-[#FF4757]"}`}>
                    {impact >= 0 ? "+" : ""}{impact}%
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Hayat Senaryosu */}
      {activeTab === "life" && (
        <div className="space-y-6">
          {/* Scenario Selection */}
          <div className="grid grid-cols-4 gap-4">
            {lifeScenarios.map((scenario) => {
              const Icon = scenario.icon
              return (
                <button
                  key={scenario.id}
                  onClick={() => setSelectedLifeScenario(scenario)}
                  className={`finos-card p-6 text-center transition-all ${
                    selectedLifeScenario.id === scenario.id
                      ? 'border-[#A78BFA] glow-purple'
                      : ''
                  }`}
                >
                  <div className={`w-12 h-12 mx-auto mb-3 rounded-xl flex items-center justify-center ${
                    selectedLifeScenario.id === scenario.id
                      ? 'bg-[rgba(167,139,250,0.2)]'
                      : 'bg-[#151A23]'
                  }`}>
                    <Icon className={`w-6 h-6 ${
                      selectedLifeScenario.id === scenario.id
                        ? 'text-[#A78BFA]'
                        : 'text-[#8892A4]'
                    }`} />
                  </div>
                  <span className={`text-sm font-medium ${
                    selectedLifeScenario.id === scenario.id
                      ? 'text-[#F0F2F7]'
                      : 'text-[#8892A4]'
                  }`}>
                    {scenario.name}
                  </span>
                </button>
              )
            })}
          </div>

          <div className="grid grid-cols-2 gap-6">
            {/* Impact Summary */}
            <div className="space-y-4">
              <div className="finos-card p-6">
                <h3 className="text-lg font-semibold text-[#F0F2F7] mb-4">Etki Özeti</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-[#151A23] rounded-xl">
                    <span className="text-sm text-[#8892A4]">Aylık Gider Değişimi</span>
                    <span className={`text-lg font-semibold font-mono ${
                      lifeImpact.monthlyExpenseChange >= 0 ? "text-[#FF4757]" : "text-[#00D4AA]"
                    }`}>
                      {lifeImpact.monthlyExpenseChange >= 0 ? "+" : ""}{formatCurrency(lifeImpact.monthlyExpenseChange)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-[#151A23] rounded-xl">
                    <span className="text-sm text-[#8892A4]">FIRE Yaşı Etkisi</span>
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-semibold font-mono text-[#4B9EFF]">
                        {lifeImpact.currentFireAge}
                      </span>
                      <ChevronRight className="w-4 h-4 text-[#4E5A6B]" />
                      <span className={`text-lg font-semibold font-mono ${
                        lifeImpact.newFireAge > lifeImpact.currentFireAge ? "text-[#FF4757]" : "text-[#00D4AA]"
                      }`}>
                        {lifeImpact.newFireAge} yaş
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Scenario specific inputs */}
              {selectedLifeScenario.id === "baby" && (
                <div className="finos-card p-6">
                  <h3 className="text-sm font-medium text-[#8892A4] mb-4">Senaryo Detayları</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs text-[#4E5A6B] mb-2">Çocuk Yaşı Hedefi</label>
                      <input
                        type="number"
                        defaultValue={0}
                        className="w-full px-3 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm font-mono text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-[#4E5A6B] mb-2">Ekstra Aylık Gider</label>
                      <p className="text-lg font-mono text-[#FF4757]">+₺8.000</p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Comparison Chart */}
            <div className="finos-card p-6">
              <h3 className="text-lg font-semibold text-[#F0F2F7] mb-4">5 Yıllık Servet Projeksiyonu</h3>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart>
                    <defs>
                      <linearGradient id="colorBefore" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#4B9EFF" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#4B9EFF" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorAfter" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#A78BFA" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#A78BFA" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis 
                      dataKey="year" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#4E5A6B', fontSize: 12 }}
                      data={lifeImpact.beforeProjection}
                    />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#4E5A6B', fontSize: 12 }}
                      tickFormatter={(value) => `₺${(value / 1000000).toFixed(1)}M`}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0E1117',
                        border: '1px solid rgba(255,255,255,0.1)',
                        borderRadius: '8px',
                        color: '#F0F2F7',
                      }}
                      formatter={(value: number) => [formatCurrency(value)]}
                    />
                    <Area
                      data={lifeImpact.beforeProjection}
                      type="monotone"
                      dataKey="value"
                      stroke="#4B9EFF"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorBefore)"
                      name="Önce"
                    />
                    <Area
                      data={lifeImpact.afterProjection}
                      type="monotone"
                      dataKey="value"
                      stroke="#A78BFA"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorAfter)"
                      name="Sonra"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="flex items-center justify-center gap-6 mt-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-[#4B9EFF]" />
                  <span className="text-sm text-[#8892A4]">Mevcut Plan</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-[#A78BFA]" />
                  <span className="text-sm text-[#8892A4]">{selectedLifeScenario.name}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  )
}
