"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { 
  FileDown, FileUp, Cloud, Moon, LayoutGrid, Sparkles, Bell, BellOff, 
  Mail, Shield, Trash2, Crown, Plus, Edit2, X, Check, ChevronDown,
  Bitcoin, Coins, AlertTriangle, Calendar
} from "lucide-react"

// Toggle component
function Toggle({ enabled, onChange, disabled = false }: { enabled: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <button
      onClick={() => !disabled && onChange(!enabled)}
      className={`
        relative w-11 h-6 rounded-full transition-all duration-200
        ${enabled ? "bg-[#00D4AA]" : "bg-[#2A3142]"}
        ${disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}
      `}
    >
      <div className={`
        absolute top-1 w-4 h-4 rounded-full bg-white shadow-md transition-transform duration-200
        ${enabled ? "translate-x-6" : "translate-x-1"}
      `} />
    </button>
  )
}

// Color Swatch component
function ColorSwatch({ color, selected, onClick }: { color: string; selected: boolean; onClick: () => void }) {
  const colors: Record<string, string> = {
    teal: "#00D4AA",
    blue: "#3B82F6",
    purple: "#8B5CF6",
    gold: "#F59E0B"
  }
  
  return (
    <button
      onClick={onClick}
      className={`
        w-8 h-8 rounded-full transition-all duration-200
        ${selected ? "ring-2 ring-offset-2 ring-offset-[#0D1117] ring-white scale-110" : "hover:scale-105"}
      `}
      style={{ backgroundColor: colors[color] }}
    >
      {selected && <Check className="w-4 h-4 text-white mx-auto" />}
    </button>
  )
}

// Section Title component
function SectionTitle({ children, icon }: { children: React.ReactNode; icon?: React.ReactNode }) {
  return (
    <div className="flex items-center gap-2 mb-4">
      {icon}
      <h2 className="text-lg font-semibold text-[#F0F2F7]">{children}</h2>
    </div>
  )
}

// Setting Row component
function SettingRow({ label, description, children }: { label: string; description?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between py-3 border-b border-[#1E2530] last:border-0">
      <div>
        <p className="text-[#F0F2F7] font-medium">{label}</p>
        {description && <p className="text-[#4E5A6B] text-sm mt-0.5">{description}</p>}
      </div>
      {children}
    </div>
  )
}

export default function SettingsPage() {
  // Gorunum state
  const [darkMode, setDarkMode] = useState(true)
  const [compactView, setCompactView] = useState(false)
  const [animations, setAnimations] = useState(true)
  const [accentColor, setAccentColor] = useState("teal")
  
  // Bolgesel ayarlar
  const [mainCurrency, setMainCurrency] = useState("TRY")
  const [secondaryCurrency, setSecondaryCurrency] = useState("USD")
  const [language, setLanguage] = useState("tr")
  const [inflationSource, setInflationSource] = useState("tuik")
  
  // Bildirimler
  const [priceAlerts, setPriceAlerts] = useState(false)
  const [portfolioUpdates, setPortfolioUpdates] = useState(false)
  const [budgetAlerts, setBudgetAlerts] = useState(true)
  const [monthlyReport, setMonthlyReport] = useState(false)
  
  // Gizlilik
  const [hideNumbers, setHideNumbers] = useState(false)
  const [dataSharing, setDataSharing] = useState(false)
  
  // Fiyat alarmlari
  const [alarms, setAlarms] = useState([
    { id: 1, asset: "BTC", name: "Bitcoin", condition: "above", price: 3000000, active: true },
    { id: 2, asset: "ALTIN", name: "Altin", condition: "below", price: 5000, active: false }
  ])
  const [showAlarmModal, setShowAlarmModal] = useState(false)
  
  // DCA planlari
  const [dcaPlans, setDcaPlans] = useState([
    { id: 1, asset: "BTC", name: "Bitcoin", amount: 5000, frequency: "monthly", nextDate: "1 Haz 2026", active: true }
  ])
  const [showDcaModal, setShowDcaModal] = useState(false)

  const handleDeleteAlarm = (id: number) => {
    setAlarms(alarms.filter(a => a.id !== id))
  }

  const handleToggleAlarm = (id: number) => {
    setAlarms(alarms.map(a => a.id === id ? { ...a, active: !a.active } : a))
  }

  const handleDeleteDca = (id: number) => {
    setDcaPlans(dcaPlans.filter(p => p.id !== id))
  }

  const handleToggleDca = (id: number) => {
    setDcaPlans(dcaPlans.map(p => p.id === id ? { ...p, active: !p.active } : p))
  }

  return (
    <DashboardLayout>
      <div className="p-6 max-w-5xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-[#F0F2F7]">Ayarlar</h1>
          <p className="text-[#8892A4] mt-1">Uygulama tercihlerinizi yonetin</p>
        </div>

        {/* YEDEKLEME */}
        <section>
          <SectionTitle icon={<Cloud className="w-5 h-5 text-[#00D4AA]" />}>Yedekleme</SectionTitle>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* JSON Yedek Al */}
            <div className="finos-card p-5 space-y-3">
              <div className="w-10 h-10 rounded-lg bg-[#151A23] flex items-center justify-center">
                <FileDown className="w-5 h-5 text-[#00D4AA]" />
              </div>
              <h3 className="font-semibold text-[#F0F2F7]">JSON Yedek Al</h3>
              <p className="text-sm text-[#8892A4]">Tum varlik, islem, gelir ve gider verilerini tek JSON dosyasina aktar</p>
              <button className="w-full py-2 px-4 bg-[#00D4AA] hover:bg-[#00B894] text-[#0D1117] font-medium rounded-lg transition-colors">
                JSON Indir
              </button>
            </div>

            {/* JSON Yedek Yukle */}
            <div className="finos-card p-5 space-y-3">
              <div className="w-10 h-10 rounded-lg bg-[#151A23] flex items-center justify-center">
                <FileUp className="w-5 h-5 text-[#3B82F6]" />
              </div>
              <h3 className="font-semibold text-[#F0F2F7]">JSON Yedek Yukle</h3>
              <p className="text-sm text-[#8892A4]">Daha once alinan JSON yedegini ice aktararak verileri geri yukle</p>
              <button className="w-full py-2 px-4 bg-[#1E2530] hover:bg-[#2A3142] text-[#F0F2F7] font-medium rounded-lg transition-colors border border-[#2A3142]">
                JSON Yukle
              </button>
            </div>

            {/* Bulut Depolama */}
            <div className="finos-card p-5 space-y-3">
              <div className="w-10 h-10 rounded-lg bg-[#151A23] flex items-center justify-center">
                <Cloud className="w-5 h-5 text-[#8B5CF6]" />
              </div>
              <h3 className="font-semibold text-[#F0F2F7]">Bulut Depolama</h3>
              <p className="text-sm text-[#8892A4]">Neon PostgreSQL bulut veri tabani — verileriniz her zaman guvende</p>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#00D4AA] animate-pulse" />
                <span className="text-sm text-[#00D4AA] font-medium">Bagli ve Aktif</span>
              </div>
            </div>
          </div>
        </section>

        {/* GORUNUM */}
        <section>
          <SectionTitle icon={<Moon className="w-5 h-5 text-[#8B5CF6]" />}>Gorunum</SectionTitle>
          <div className="finos-card p-5">
            <SettingRow label="Karanlik Mod" description="Koyu tema kullan">
              <Toggle enabled={darkMode} onChange={setDarkMode} />
            </SettingRow>
            <SettingRow label="Kompakt Gorunum" description="Daha yogun bilgi gosterimi">
              <Toggle enabled={compactView} onChange={setCompactView} />
            </SettingRow>
            <SettingRow label="Animasyonlar" description="Gecis efektlerini etkinlestir">
              <Toggle enabled={animations} onChange={setAnimations} />
            </SettingRow>
            <div className="pt-4">
              <p className="text-[#F0F2F7] font-medium mb-3">Renk Aksani</p>
              <div className="flex items-center gap-4">
                {["teal", "blue", "purple", "gold"].map(color => (
                  <ColorSwatch 
                    key={color} 
                    color={color} 
                    selected={accentColor === color}
                    onClick={() => setAccentColor(color)}
                  />
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* BOLGESEL AYARLAR */}
        <section>
          <SectionTitle icon={<Coins className="w-5 h-5 text-[#F59E0B]" />}>Bolgesel Ayarlar</SectionTitle>
          <div className="finos-card p-5">
            <SettingRow label="Ana Para Birimi">
              <select 
                value={mainCurrency} 
                onChange={(e) => setMainCurrency(e.target.value)}
                className="bg-[#151A23] border border-[#2A3142] rounded-lg px-3 py-2 text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]"
              >
                <option value="TRY">Turk Lirasi (TL)</option>
                <option value="USD">Dolar ($)</option>
                <option value="EUR">Euro (EUR)</option>
              </select>
            </SettingRow>
            <SettingRow label="Ikincil Para Birimi">
              <select 
                value={secondaryCurrency} 
                onChange={(e) => setSecondaryCurrency(e.target.value)}
                className="bg-[#151A23] border border-[#2A3142] rounded-lg px-3 py-2 text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]"
              >
                <option value="USD">Dolar ($)</option>
                <option value="EUR">Euro (EUR)</option>
                <option value="TRY">Turk Lirasi (TL)</option>
              </select>
            </SettingRow>
            <SettingRow label="Dil">
              <select 
                value={language} 
                onChange={(e) => setLanguage(e.target.value)}
                className="bg-[#151A23] border border-[#2A3142] rounded-lg px-3 py-2 text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]"
              >
                <option value="tr">Turkce</option>
                <option value="en">English</option>
              </select>
            </SettingRow>
            <div className="pt-4">
              <p className="text-[#F0F2F7] font-medium mb-3">Enflasyon Veri Kaynagi</p>
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="radio" 
                    name="inflation" 
                    checked={inflationSource === "tuik"}
                    onChange={() => setInflationSource("tuik")}
                    className="w-4 h-4 accent-[#00D4AA]"
                  />
                  <span className="text-[#F0F2F7]">TUIK</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="radio" 
                    name="inflation" 
                    checked={inflationSource === "enag"}
                    onChange={() => setInflationSource("enag")}
                    className="w-4 h-4 accent-[#00D4AA]"
                  />
                  <span className="text-[#F0F2F7]">ENAG</span>
                </label>
              </div>
            </div>
          </div>
        </section>

        {/* BILDIRIMLER */}
        <section>
          <SectionTitle icon={<Bell className="w-5 h-5 text-[#3B82F6]" />}>Bildirimler</SectionTitle>
          <div className="finos-card p-5">
            <SettingRow label="Fiyat Uyarilari" description="Varlik fiyat degisimlerinde bildirim al">
              <Toggle enabled={priceAlerts} onChange={setPriceAlerts} />
            </SettingRow>
            <SettingRow label="Portfolyo Guncellemeleri" description="Gunluk portfolyo ozetleri">
              <Toggle enabled={portfolioUpdates} onChange={setPortfolioUpdates} />
            </SettingRow>
            <SettingRow label="Butce Uyarilari" description="Butce asimlarinda uyari">
              <Toggle enabled={budgetAlerts} onChange={setBudgetAlerts} />
            </SettingRow>
            <SettingRow label="Aylik Rapor E-postasi" description="Her ay sonunda detayli rapor">
              <Toggle enabled={monthlyReport} onChange={setMonthlyReport} />
            </SettingRow>
          </div>
        </section>

        {/* FIYAT ALARMLARI */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <SectionTitle icon={<AlertTriangle className="w-5 h-5 text-[#FF4757]" />}>Fiyat Alarmlari</SectionTitle>
            <button 
              onClick={() => setShowAlarmModal(true)}
              className="flex items-center gap-2 px-3 py-1.5 bg-[#00D4AA] hover:bg-[#00B894] text-[#0D1117] font-medium rounded-lg transition-colors text-sm"
            >
              <Plus className="w-4 h-4" />
              Alarm Ekle
            </button>
          </div>
          <div className="finos-card divide-y divide-[#1E2530]">
            {alarms.map(alarm => (
              <div key={alarm.id} className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#151A23] flex items-center justify-center">
                    {alarm.asset === "BTC" ? (
                      <Bitcoin className="w-5 h-5 text-[#F7931A]" />
                    ) : (
                      <Coins className="w-5 h-5 text-[#FFD700]" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-[#F0F2F7]">{alarm.name}</p>
                    <p className="text-sm text-[#8892A4]">
                      Fiyat {alarm.price.toLocaleString("tr-TR")} TL {alarm.condition === "above" ? "ustune cikinca" : "altina dusunce"}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`flex items-center gap-1 text-sm font-medium ${alarm.active ? "text-[#00D4AA]" : "text-[#4E5A6B]"}`}>
                    {alarm.active ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
                    {alarm.active ? "Aktif" : "Pasif"}
                  </span>
                  <Toggle enabled={alarm.active} onChange={() => handleToggleAlarm(alarm.id)} />
                  <button 
                    onClick={() => handleDeleteAlarm(alarm.id)}
                    className="p-2 hover:bg-[#1E2530] rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4 text-[#FF4757]" />
                  </button>
                </div>
              </div>
            ))}
            {alarms.length === 0 && (
              <div className="p-8 text-center text-[#4E5A6B]">
                Henuz alarm eklenmedi
              </div>
            )}
          </div>
        </section>

        {/* DCA PLANLARI */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <SectionTitle icon={<Calendar className="w-5 h-5 text-[#00D4AA]" />}>DCA Planlari</SectionTitle>
            <button 
              onClick={() => setShowDcaModal(true)}
              className="flex items-center gap-2 px-3 py-1.5 bg-[#00D4AA] hover:bg-[#00B894] text-[#0D1117] font-medium rounded-lg transition-colors text-sm"
            >
              <Plus className="w-4 h-4" />
              Plan Ekle
            </button>
          </div>
          <div className="finos-card divide-y divide-[#1E2530]">
            {dcaPlans.map(plan => (
              <div key={plan.id} className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#151A23] flex items-center justify-center">
                    <Bitcoin className="w-5 h-5 text-[#F7931A]" />
                  </div>
                  <div>
                    <p className="font-medium text-[#F0F2F7]">{plan.name}</p>
                    <p className="text-sm text-[#8892A4]">
                      Her ay {plan.amount.toLocaleString("tr-TR")} TL — Sonraki: {plan.nextDate}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Toggle enabled={plan.active} onChange={() => handleToggleDca(plan.id)} />
                  <button className="p-2 hover:bg-[#1E2530] rounded-lg transition-colors">
                    <Edit2 className="w-4 h-4 text-[#8892A4]" />
                  </button>
                  <button 
                    onClick={() => handleDeleteDca(plan.id)}
                    className="p-2 hover:bg-[#1E2530] rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4 text-[#FF4757]" />
                  </button>
                </div>
              </div>
            ))}
            {dcaPlans.length === 0 && (
              <div className="p-8 text-center text-[#4E5A6B]">
                Henuz DCA plani eklenmedi
              </div>
            )}
          </div>
        </section>

        {/* GIZLILIK */}
        <section>
          <SectionTitle icon={<Shield className="w-5 h-5 text-[#8B5CF6]" />}>Gizlilik</SectionTitle>
          <div className="finos-card p-5">
            <SettingRow label="Numara Gizleme" description="Ana sayfada rakamlari gizle">
              <Toggle enabled={hideNumbers} onChange={setHideNumbers} />
            </SettingRow>
            <SettingRow label="Veri Paylasimi" description="Anonim istatistiklere katil">
              <Toggle enabled={dataSharing} onChange={setDataSharing} />
            </SettingRow>
            <div className="pt-6">
              <button className="px-4 py-2 bg-[#FF4757] hover:bg-[#EE3545] text-white font-medium rounded-lg transition-colors flex items-center gap-2">
                <Trash2 className="w-4 h-4" />
                Hesabi Sil
              </button>
            </div>
          </div>
        </section>

        {/* PREMIUM */}
        <section>
          <div className="finos-card p-6 border-[#F59E0B]/30 bg-gradient-to-br from-[#1E2530] to-[#1A1F2A]">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#F59E0B] to-[#D97706] flex items-center justify-center">
                <Crown className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-[#F0F2F7]">FinOS Premium</h3>
                <p className="text-[#8892A4]">Mevcut plan: <span className="text-[#F59E0B] font-medium">Ucretsiz Plan</span></p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
              {/* Free */}
              <div className="p-4 rounded-xl bg-[#151A23] border border-[#2A3142]">
                <h4 className="font-semibold text-[#F0F2F7] mb-3">Ucretsiz</h4>
                <ul className="space-y-2 text-sm text-[#8892A4]">
                  <li>5 varlik</li>
                  <li>50 islem/ay</li>
                  <li>5 AI mesaj/gun</li>
                </ul>
              </div>

              {/* Premium */}
              <div className="p-4 rounded-xl bg-[#151A23] border border-[#F59E0B]/50 relative">
                <span className="absolute -top-2 right-3 px-2 py-0.5 bg-[#F59E0B] text-[#0D1117] text-xs font-bold rounded">POPULER</span>
                <h4 className="font-semibold text-[#F0F2F7] mb-1">Premium</h4>
                <p className="text-[#F59E0B] font-bold mb-3">149 TL/ay</p>
                <ul className="space-y-2 text-sm text-[#8892A4]">
                  <li>Sinirsiz varlik</li>
                  <li>AI kocu</li>
                  <li>PDF raporlar</li>
                  <li>FIRE hesabi</li>
                </ul>
              </div>

              {/* Pro */}
              <div className="p-4 rounded-xl bg-[#151A23] border border-[#8B5CF6]/50">
                <h4 className="font-semibold text-[#F0F2F7] mb-1">Pro</h4>
                <p className="text-[#8B5CF6] font-bold mb-3">299 TL/ay</p>
                <ul className="space-y-2 text-sm text-[#8892A4]">
                  <li>Tum Premium ozellikler</li>
                  <li>Vergi hesabi</li>
                  <li>API erisimi</li>
                  <li>Oncelikli destek</li>
                </ul>
              </div>
            </div>

            <button className="w-full mt-6 py-3 bg-gradient-to-r from-[#F59E0B] to-[#D97706] hover:from-[#D97706] hover:to-[#B45309] text-white font-bold rounded-xl transition-all shadow-lg shadow-[#F59E0B]/20">
              Premium&apos;a Yukselt
            </button>
          </div>
        </section>

        {/* Alarm Ekle Modal */}
        {showAlarmModal && (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
            <div className="finos-card p-6 w-full max-w-md">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-[#F0F2F7]">Yeni Alarm Ekle</h3>
                <button onClick={() => setShowAlarmModal(false)} className="p-1 hover:bg-[#1E2530] rounded">
                  <X className="w-5 h-5 text-[#8892A4]" />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-[#8892A4] mb-2">Varlik</label>
                  <select className="w-full bg-[#151A23] border border-[#2A3142] rounded-lg px-3 py-2 text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]">
                    <option>Bitcoin (BTC)</option>
                    <option>Altin</option>
                    <option>THYAO</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-[#8892A4] mb-2">Kosul</label>
                  <select className="w-full bg-[#151A23] border border-[#2A3142] rounded-lg px-3 py-2 text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]">
                    <option>Ustune cikinca</option>
                    <option>Altina dusunce</option>
                    <option>% degisimde</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-[#8892A4] mb-2">Fiyat (TL)</label>
                  <input 
                    type="number" 
                    placeholder="3000000"
                    className="w-full bg-[#151A23] border border-[#2A3142] rounded-lg px-3 py-2 text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]"
                  />
                </div>
                <div>
                  <label className="block text-sm text-[#8892A4] mb-2">Bildirim Yontemi</label>
                  <div className="flex items-center gap-4">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" defaultChecked className="w-4 h-4 accent-[#00D4AA]" />
                      <span className="text-[#F0F2F7] text-sm">E-posta</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" className="w-4 h-4 accent-[#00D4AA]" />
                      <span className="text-[#F0F2F7] text-sm">Push</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" className="w-4 h-4 accent-[#00D4AA]" />
                      <span className="text-[#F0F2F7] text-sm">SMS</span>
                    </label>
                  </div>
                </div>
              </div>
              <div className="flex gap-3 mt-6">
                <button 
                  onClick={() => setShowAlarmModal(false)}
                  className="flex-1 py-2 bg-[#1E2530] hover:bg-[#2A3142] text-[#F0F2F7] font-medium rounded-lg transition-colors"
                >
                  Iptal
                </button>
                <button 
                  onClick={() => setShowAlarmModal(false)}
                  className="flex-1 py-2 bg-[#00D4AA] hover:bg-[#00B894] text-[#0D1117] font-medium rounded-lg transition-colors"
                >
                  Kaydet
                </button>
              </div>
            </div>
          </div>
        )}

        {/* DCA Plan Ekle Modal */}
        {showDcaModal && (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
            <div className="finos-card p-6 w-full max-w-md">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-[#F0F2F7]">Yeni DCA Plani Ekle</h3>
                <button onClick={() => setShowDcaModal(false)} className="p-1 hover:bg-[#1E2530] rounded">
                  <X className="w-5 h-5 text-[#8892A4]" />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-[#8892A4] mb-2">Varlik</label>
                  <select className="w-full bg-[#151A23] border border-[#2A3142] rounded-lg px-3 py-2 text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]">
                    <option>Bitcoin (BTC)</option>
                    <option>Ethereum (ETH)</option>
                    <option>Altin</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-[#8892A4] mb-2">Miktar (TL)</label>
                  <input 
                    type="number" 
                    placeholder="5000"
                    className="w-full bg-[#151A23] border border-[#2A3142] rounded-lg px-3 py-2 text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]"
                  />
                </div>
                <div>
                  <label className="block text-sm text-[#8892A4] mb-2">Sıklık</label>
                  <select className="w-full bg-[#151A23] border border-[#2A3142] rounded-lg px-3 py-2 text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]">
                    <option>Her hafta</option>
                    <option>Her 2 hafta</option>
                    <option>Her ay</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-[#8892A4] mb-2">Baslangic Tarihi</label>
                  <input 
                    type="date" 
                    className="w-full bg-[#151A23] border border-[#2A3142] rounded-lg px-3 py-2 text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]"
                  />
                </div>
              </div>
              <div className="flex gap-3 mt-6">
                <button 
                  onClick={() => setShowDcaModal(false)}
                  className="flex-1 py-2 bg-[#1E2530] hover:bg-[#2A3142] text-[#F0F2F7] font-medium rounded-lg transition-colors"
                >
                  Iptal
                </button>
                <button 
                  onClick={() => setShowDcaModal(false)}
                  className="flex-1 py-2 bg-[#00D4AA] hover:bg-[#00B894] text-[#0D1117] font-medium rounded-lg transition-colors"
                >
                  Kaydet
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
