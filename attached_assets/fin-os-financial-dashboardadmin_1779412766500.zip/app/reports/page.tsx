"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { formatCurrency, formatNumber, MetricBadge } from "@/components/ui/finos-components"
import { portfolioSummary, holdings, assetAllocation, incomeVsExpense } from "@/lib/mock-data"
import {
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts"
import { FileText, FileSpreadsheet, Mail, ChevronDown, TrendingUp, TrendingDown, Bitcoin, BarChart3, Gem, Coins } from "lucide-react"

// Asset class data
const assetClasses = [
  { name: "Hisse Senetleri", value: 0, count: 0, icon: TrendingUp, color: "#00D4AA" },
  { name: "ETF'ler", value: 0, count: 0, icon: BarChart3, color: "#3B82F6" },
  { name: "Kripto Paralar", value: 3891094.61, count: 1, icon: Bitcoin, color: "#FFB833" },
  { name: "Emtia", value: 0, count: 0, icon: Gem, color: "#A855F7" },
]

// Benchmark comparison data (12 months)
const benchmarkData = [
  { month: "Haz", portfolio: 0, gold: 0, xu100: 0, btc: 0 },
  { month: "Tem", portfolio: 5, gold: 2, xu100: 3, btc: 8 },
  { month: "Agu", portfolio: 12, gold: 5, xu100: 7, btc: 15 },
  { month: "Eyl", portfolio: 8, gold: 8, xu100: 5, btc: -5 },
  { month: "Eki", portfolio: 15, gold: 10, xu100: 12, btc: 22 },
  { month: "Kas", portfolio: 22, gold: 12, xu100: 15, btc: 35 },
  { month: "Ara", portfolio: 18, gold: 15, xu100: 10, btc: 28 },
  { month: "Oca", portfolio: 25, gold: 18, xu100: 18, btc: 40 },
  { month: "Sub", portfolio: 20, gold: 20, xu100: 15, btc: 25 },
  { month: "Mar", portfolio: 28, gold: 22, xu100: 20, btc: 45 },
  { month: "Nis", portfolio: 32, gold: 25, xu100: 22, btc: 38 },
  { month: "May", portfolio: 3.09, gold: 28, xu100: 18, btc: 3.09 },
]

// Heatmap data
const heatmapData = [
  { symbol: "BTC", name: "Bitcoin", value: 3891094.61, change: 3.09, weight: 100 },
]

// Monthly comparison data
const monthlyComparison = [
  { category: "Gelir", thisMay: 95000, lastMonth: 88000 },
  { category: "Gider", thisMay: 58000, lastMonth: 51000 },
  { category: "Birikim", thisMay: 37000, lastMonth: 37000 },
  { category: "Yatirim Getirisi", thisMay: 116633, lastMonth: 85000 },
]

// Real return data
const realReturnHistory = [
  { month: "Oca", nominal: 5, real: 2.5 },
  { month: "Sub", nominal: 8, real: 5 },
  { month: "Mar", nominal: 12, real: 8 },
  { month: "Nis", nominal: 10, real: 6 },
  { month: "May", nominal: 3.09, real: 0.8 },
]

export default function ReportsPage() {
  const [selectedMonth, setSelectedMonth] = useState("Mayis 2026")
  const [activeTab, setActiveTab] = useState("kripto")
  const [inflationSource, setInflationSource] = useState<"tuik" | "enag">("tuik")

  const tabs = [
    { id: "hisse", label: "Hisse" },
    { id: "etf", label: "ETF" },
    { id: "kripto", label: "Kripto" },
    { id: "emtia", label: "Emtia" },
  ]

  const inflationRate = inflationSource === "tuik" ? 2.3 : 4.1
  const nominalReturn = 3.09
  const realReturn = inflationSource === "tuik" ? 0.8 : -1.0

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-[#F0F2F7]">Raporlar</h1>
            <p className="text-[#8892A4] text-sm mt-1">Detayli portfoy analizi ve raporlama</p>
          </div>
        </div>

        {/* Top Stats - 4 Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {assetClasses.map((asset) => (
            <div
              key={asset.name}
              className={`finos-card p-5 ${asset.value > 0 ? "border-l-4" : ""}`}
              style={{ borderLeftColor: asset.value > 0 ? asset.color : undefined }}
            >
              <div className="flex items-start justify-between mb-3">
                <span className="text-[#8892A4] text-sm font-medium">{asset.name}</span>
                <div
                  className="w-9 h-9 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: `${asset.color}20` }}
                >
                  <asset.icon className="w-5 h-5" style={{ color: asset.color }} />
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-2xl font-semibold font-mono text-[#F0F2F7]">
                  {formatCurrency(asset.value)}
                </p>
                <p className="text-sm text-[#4E5A6B]">{asset.count} varlik</p>
              </div>
            </div>
          ))}
        </div>

        {/* Action Buttons Row */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap gap-3">
            <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#FF4757] hover:bg-[#FF4757]/90 text-white font-medium transition-colors">
              <FileText className="w-4 h-4" />
              PDF Rapor Indir
            </button>
            <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#00D4AA] hover:bg-[#00D4AA]/90 text-[#0A0E14] font-medium transition-colors">
              <FileSpreadsheet className="w-4 h-4" />
              Excel&apos;e Aktar
            </button>
            <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#3B82F6] hover:bg-[#3B82F6]/90 text-white font-medium transition-colors">
              <Mail className="w-4 h-4" />
              Raporu E-posta Gonder
            </button>
          </div>
          <div className="relative">
            <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#151A23] border border-[#2A3441] text-[#F0F2F7] font-medium hover:bg-[#1C222D] transition-colors">
              {selectedMonth}
              <ChevronDown className="w-4 h-4 text-[#8892A4]" />
            </button>
          </div>
        </div>

        {/* Two Column: Pie + Benchmark */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Asset Distribution Pie */}
          <div className="finos-card p-5">
            <h3 className="text-lg font-semibold text-[#F0F2F7] mb-4">Varlik Sinifi Dagilimi</h3>
            <div className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={280}>
                <PieChart>
                  <Pie
                    data={assetClasses.filter(a => a.value > 0)}
                    cx="50%"
                    cy="50%"
                    innerRadius={70}
                    outerRadius={100}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {assetClasses.filter(a => a.value > 0).map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload
                        return (
                          <div className="bg-[#1C222D] border border-[#2A3441] rounded-lg p-3 shadow-lg">
                            <p className="text-[#F0F2F7] font-medium">{data.name}</p>
                            <p className="text-[#00D4AA] font-mono">{formatCurrency(data.value)}</p>
                            <p className="text-[#8892A4] text-sm">{((data.value / portfolioSummary.totalAsset) * 100).toFixed(1)}%</p>
                          </div>
                        )
                      }
                      return null
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 space-y-2">
              {assetClasses.map((asset) => (
                <div key={asset.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: asset.color }} />
                    <span className="text-[#8892A4] text-sm">{asset.name}</span>
                  </div>
                  <span className="text-[#F0F2F7] font-mono text-sm">
                    {asset.value > 0 ? `${((asset.value / portfolioSummary.totalAsset) * 100).toFixed(1)}%` : "0%"}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Benchmark Comparison */}
          <div className="finos-card p-5">
            <div className="mb-4">
              <h3 className="text-lg font-semibold text-[#F0F2F7]">Benchmark Kiyaslamasi</h3>
              <p className="text-[#8892A4] text-sm">Portfolyo vs BIST100 / Altin / Bitcoin - 12 aylik kumulatif % getiri</p>
            </div>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={benchmarkData}>
                <XAxis
                  dataKey="month"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#4E5A6B", fontSize: 12 }}
                />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "#4E5A6B", fontSize: 12 }}
                  tickFormatter={(value) => `${value}%`}
                  domain={[-50, 50]}
                />
                <Tooltip
                  content={({ active, payload, label }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-[#1C222D] border border-[#2A3441] rounded-lg p-3 shadow-lg">
                          <p className="text-[#8892A4] text-sm mb-2">{label}</p>
                          {payload.map((entry: { name: string; value: number; color: string }, i: number) => (
                            <div key={i} className="flex items-center justify-between gap-4">
                              <span className="text-[#8892A4] text-sm">{entry.name}</span>
                              <span className="font-mono text-sm" style={{ color: entry.color }}>
                                {entry.value > 0 ? "+" : ""}{entry.value}%
                              </span>
                            </div>
                          ))}
                        </div>
                      )
                    }
                    return null
                  }}
                />
                <Legend
                  verticalAlign="top"
                  height={36}
                  formatter={(value: string) => <span className="text-[#8892A4] text-xs">{value}</span>}
                />
                <Line type="monotone" dataKey="portfolio" name="Portfolyum" stroke="#3B82F6" strokeWidth={2} dot={{ fill: "#3B82F6", r: 3 }} />
                <Line type="monotone" dataKey="gold" name="Altin" stroke="#FFB833" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="xu100" name="XU100" stroke="#8892A4" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="btc" name="Bitcoin" stroke="#F97316" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Detailed Asset Breakdown */}
        <div className="finos-card p-5">
          <h3 className="text-lg font-semibold text-[#F0F2F7] mb-4">Detayli Varlik Dokumu</h3>
          
          {/* Tabs */}
          <div className="flex gap-1 p-1 bg-[#151A23] rounded-lg w-fit mb-6">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeTab === tab.id
                    ? "bg-[#2A3441] text-[#F0F2F7]"
                    : "text-[#8892A4] hover:text-[#F0F2F7]"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Table */}
          {activeTab === "kripto" && holdings.filter(h => h.type === "Kripto").length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#2A3441]">
                    <th className="text-left py-3 px-4 text-[#8892A4] text-sm font-medium">Varlik</th>
                    <th className="text-right py-3 px-4 text-[#8892A4] text-sm font-medium">Miktar</th>
                    <th className="text-right py-3 px-4 text-[#8892A4] text-sm font-medium">Ort. Maliyet</th>
                    <th className="text-right py-3 px-4 text-[#8892A4] text-sm font-medium">Guncel Fiyat</th>
                    <th className="text-right py-3 px-4 text-[#8892A4] text-sm font-medium">Toplam Deger</th>
                    <th className="text-right py-3 px-4 text-[#8892A4] text-sm font-medium">Kar/Zarar</th>
                    <th className="text-right py-3 px-4 text-[#8892A4] text-sm font-medium">ROI</th>
                    <th className="text-right py-3 px-4 text-[#8892A4] text-sm font-medium">Reel ROI</th>
                  </tr>
                </thead>
                <tbody>
                  {holdings.filter(h => h.type === "Kripto").map((holding) => (
                    <tr key={holding.symbol} className="border-b border-[#2A3441]/50 hover:bg-[#151A23]/50">
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-[#FFB833]/20 flex items-center justify-center">
                            <Bitcoin className="w-5 h-5 text-[#FFB833]" />
                          </div>
                          <div>
                            <p className="text-[#F0F2F7] font-medium">{holding.name}</p>
                            <p className="text-[#4E5A6B] text-sm">{holding.symbol}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-4 text-right font-mono text-[#F0F2F7]">{holding.quantity}</td>
                      <td className="py-4 px-4 text-right font-mono text-[#F0F2F7]">${formatNumber(holding.avgCost)}</td>
                      <td className="py-4 px-4 text-right font-mono text-[#F0F2F7]">${formatNumber(holding.currentPrice)}</td>
                      <td className="py-4 px-4 text-right font-mono text-[#F0F2F7]">{formatCurrency(holding.totalValue * 45.6)}</td>
                      <td className="py-4 px-4 text-right">
                        <span className="font-mono text-[#00D4AA]">+{formatCurrency(holding.pnl * 45.6)}</span>
                      </td>
                      <td className="py-4 px-4 text-right">
                        <MetricBadge value={holding.change} trend="up" />
                      </td>
                      <td className="py-4 px-4 text-right">
                        <span className="font-mono text-[#FFB833] text-sm px-2 py-0.5 rounded bg-[#FFB833]/10">+%0.8</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-12 text-[#4E5A6B]">
              Bu kategoride varlik bulunmuyor
            </div>
          )}
        </div>

        {/* Portfolio Heatmap */}
        <div className="finos-card p-5">
          <h3 className="text-lg font-semibold text-[#F0F2F7] mb-4">Portfolyo Isi Haritasi</h3>
          <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-2">
            {heatmapData.map((item) => {
              const intensity = Math.min(Math.abs(item.change) / 10, 1)
              const bgColor = item.change >= 0
                ? `rgba(0, 212, 170, ${0.2 + intensity * 0.6})`
                : `rgba(255, 71, 87, ${0.2 + intensity * 0.6})`
              
              return (
                <div
                  key={item.symbol}
                  className="col-span-4 md:col-span-6 lg:col-span-8 p-6 rounded-lg cursor-pointer transition-transform hover:scale-[1.02]"
                  style={{ backgroundColor: bgColor }}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[#F0F2F7] font-semibold text-lg">{item.symbol}</p>
                      <p className="text-[#8892A4] text-sm">{item.name}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[#F0F2F7] font-mono">{formatCurrency(item.value)}</p>
                      <p className={`font-mono ${item.change >= 0 ? "text-[#00D4AA]" : "text-[#FF4757]"}`}>
                        {item.change >= 0 ? "+" : ""}{item.change}%
                      </p>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
          <div className="flex items-center justify-center gap-4 mt-4">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: "rgba(255, 71, 87, 0.8)" }} />
              <span className="text-[#8892A4] text-xs">Dusus</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: "rgba(78, 90, 107, 0.5)" }} />
              <span className="text-[#8892A4] text-xs">Notr</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: "rgba(0, 212, 170, 0.8)" }} />
              <span className="text-[#8892A4] text-xs">Artis</span>
            </div>
          </div>
        </div>

        {/* Monthly Comparison Chart */}
        <div className="finos-card p-5">
          <h3 className="text-lg font-semibold text-[#F0F2F7] mb-4">Aylik Karsilastirma</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={monthlyComparison} barGap={8}>
              <XAxis
                dataKey="category"
                axisLine={false}
                tickLine={false}
                tick={{ fill: "#8892A4", fontSize: 12 }}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fill: "#4E5A6B", fontSize: 12 }}
                tickFormatter={(value) => `${(value / 1000).toFixed(0)}K`}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-[#1C222D] border border-[#2A3441] rounded-lg p-3 shadow-lg">
                        <p className="text-[#F0F2F7] font-medium mb-2">{label}</p>
                        {payload.map((entry: { name: string; value: number; color: string }, i: number) => (
                          <div key={i} className="flex items-center justify-between gap-4">
                            <span className="text-[#8892A4] text-sm">{entry.name}</span>
                            <span className="font-mono text-sm" style={{ color: entry.color }}>
                              {formatCurrency(entry.value)}
                            </span>
                          </div>
                        ))}
                      </div>
                    )
                  }
                  return null
                }}
              />
              <Legend
                verticalAlign="top"
                height={36}
                formatter={(value: string) => <span className="text-[#8892A4] text-xs">{value}</span>}
              />
              <Bar dataKey="thisMay" name="Bu Ay" fill="#00D4AA" radius={[4, 4, 0, 0]} />
              <Bar dataKey="lastMonth" name="Gecen Ay" fill="#3B82F6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Real Return Analysis */}
        <div className="finos-card p-5">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-[#F0F2F7]">Reel Kar/Zarar Analizi</h3>
              <p className="text-[#8892A4] text-sm">Enflasyondan Arindirilmis Gercek Getiri</p>
            </div>
            <div className="flex gap-1 p-1 bg-[#151A23] rounded-lg">
              <button
                onClick={() => setInflationSource("tuik")}
                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                  inflationSource === "tuik"
                    ? "bg-[#2A3441] text-[#F0F2F7]"
                    : "text-[#8892A4] hover:text-[#F0F2F7]"
                }`}
              >
                TUIK
              </button>
              <button
                onClick={() => setInflationSource("enag")}
                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                  inflationSource === "enag"
                    ? "bg-[#2A3441] text-[#F0F2F7]"
                    : "text-[#8892A4] hover:text-[#F0F2F7]"
                }`}
              >
                ENAG
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="p-6 bg-[#151A23] rounded-xl text-center">
              <p className="text-[#8892A4] text-sm mb-2">Nominal Getiri</p>
              <p className="text-4xl font-bold font-mono text-[#00D4AA]">+%{nominalReturn}</p>
            </div>
            <div className="p-6 bg-[#151A23] rounded-xl text-center">
              <p className="text-[#8892A4] text-sm mb-2">Reel Getiri (enfl. duzeltilmis)</p>
              <p className={`text-4xl font-bold font-mono ${realReturn >= 0 ? "text-[#FFB833]" : "text-[#FF4757]"}`}>
                {realReturn >= 0 ? "+" : ""}%{realReturn}
              </p>
            </div>
          </div>

          <p className="text-[#8892A4] text-sm mb-6 text-center">
            {inflationSource === "tuik" ? "TUIK" : "ENAG"} enflasyonu (%{inflationRate}) dusuldukten sonra gercek getiri
          </p>

          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={realReturnHistory}>
              <XAxis
                dataKey="month"
                axisLine={false}
                tickLine={false}
                tick={{ fill: "#4E5A6B", fontSize: 12 }}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fill: "#4E5A6B", fontSize: 12 }}
                tickFormatter={(value) => `${value}%`}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-[#1C222D] border border-[#2A3441] rounded-lg p-3 shadow-lg">
                        <p className="text-[#8892A4] text-sm mb-2">{label}</p>
                        {payload.map((entry: { name: string; value: number; color: string }, i: number) => (
                          <div key={i} className="flex items-center justify-between gap-4">
                            <span className="text-[#8892A4] text-sm">{entry.name}</span>
                            <span className="font-mono text-sm" style={{ color: entry.color }}>
                              {entry.value > 0 ? "+" : ""}{entry.value}%
                            </span>
                          </div>
                        ))}
                      </div>
                    )
                  }
                  return null
                }}
              />
              <Line type="monotone" dataKey="nominal" name="Nominal" stroke="#00D4AA" strokeWidth={2} dot={{ fill: "#00D4AA", r: 3 }} />
              <Line type="monotone" dataKey="real" name="Reel" stroke="#FFB833" strokeWidth={2} dot={{ fill: "#FFB833", r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </DashboardLayout>
  )
}
