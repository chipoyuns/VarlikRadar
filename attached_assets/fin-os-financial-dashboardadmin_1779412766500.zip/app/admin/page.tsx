"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { GlassCard } from "@/components/ui/finos-components"
import {
  Shield, Users, CreditCard, TrendingUp, FileBarChart, Database, Lock, Settings, Sparkles,
  Clock, LogOut, Eye, AlertTriangle, X, Activity, DollarSign, UserMinus, ArrowUp, ArrowDown,
  ChevronRight, Mail, Download, Plus, Search, Filter, MoreHorizontal, Edit, Trash2,
  CheckCircle, XCircle, Pause, Play, RefreshCw, Send, Bell, Globe, Cpu, HardDrive, Wifi,
  Server, Zap, AlertCircle, ExternalLink, Copy, Key, Upload, Trash, ToggleLeft, ToggleRight,
  Star, MessageSquare, ThumbsUp, Calendar, UserPlus, Receipt, Percent, Tag, Gift,
} from "lucide-react"
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, Legend,
} from "recharts"

// Mock Data
const mockKpiData = {
  totalUsers: 12847,
  newUsersThisMonth: 234,
  activeToday: 3421,
  mrr: 284750,
  mrrGrowth: 12.4,
  activeSubscriptions: 1923,
  freeUsers: 10924,
  premiumUsers: 1456,
  proUsers: 467,
  churnRate: 2.3,
  churnCount: 52,
  arpu: 22.14,
}

const mockUserGrowthData = [
  { month: "Haz", kayit: 890, ayrilma: 45 },
  { month: "Tem", kayit: 1020, ayrilma: 52 },
  { month: "Agu", kayit: 980, ayrilma: 48 },
  { month: "Eyl", kayit: 1150, ayrilma: 61 },
  { month: "Eki", kayit: 1280, ayrilma: 58 },
  { month: "Kas", kayit: 1340, ayrilma: 64 },
  { month: "Ara", kayit: 1450, ayrilma: 72 },
  { month: "Oca", kayit: 1380, ayrilma: 68 },
  { month: "Sub", kayit: 1520, ayrilma: 71 },
  { month: "Mar", kayit: 1680, ayrilma: 78 },
  { month: "Nis", kayit: 1720, ayrilma: 82 },
  { month: "May", kayit: 1890, ayrilma: 89 },
]

const mockRevenueData = [
  { month: "Ara", free: 0, premium: 168000, pro: 98000 },
  { month: "Oca", free: 0, premium: 178000, pro: 105000 },
  { month: "Sub", free: 0, premium: 189000, pro: 112000 },
  { month: "Mar", free: 0, premium: 198000, pro: 121000 },
  { month: "Nis", free: 0, premium: 208000, pro: 128000 },
  { month: "May", free: 0, premium: 216944, pro: 139633 },
]

const mockActivityFeed = [
  { type: "signup", text: "yeni_kullanici_847 kayit oldu", time: "2 dk once", color: "#00D4AA" },
  { type: "upgrade", text: "mehmet_k Premium'a yukseltildi", time: "5 dk once", color: "#FFB833" },
  { type: "cancel", text: "zeynep_a aboneligini iptal etti", time: "8 dk once", color: "#FF4757" },
  { type: "login", text: "admin giris yapti: ip 185.34.x.x", time: "12 dk once", color: "#4B9EFF" },
  { type: "warning", text: "Basarisiz giris (5x): user_test@...", time: "15 dk once", color: "#FF4757" },
  { type: "support", text: "ahmet_y destek talebi acti #1847", time: "18 dk once", color: "#4B9EFF" },
]

const mockSystemStatus = [
  { name: "API Sunucusu", status: "active", detail: "124ms" },
  { name: "Veritabani", status: "active", detail: "8ms query" },
  { name: "Odeme Sistemi", status: "active", detail: "Stripe" },
  { name: "Email Servisi", status: "slow", detail: "4.2s" },
  { name: "AI Servisi", status: "active", detail: "1.2s avg" },
  { name: "CDN", status: "active", detail: "98ms" },
]

const mockUsers = [
  { id: 1001, name: "Mehmet Kaya", email: "mehmet.kaya@gmail.com", plan: "Premium", status: "active", registered: "12 Nis 2025", lastLogin: "Bugun 14:21", spent: 1788 },
  { id: 1002, name: "Zeynep Aydin", email: "zeynep.a@outlook.com", plan: "Pro", status: "online", registered: "3 Mar 2025", lastLogin: "Su an online", spent: 4197 },
  { id: 1003, name: "Ali Vural", email: "ali.vural@icloud.com", plan: "Free", status: "suspended", registered: "28 Oca 2025", lastLogin: "3 gun once", spent: 149 },
  { id: 1004, name: "Ayse Demir", email: "ayse.d@gmail.com", plan: "Free", status: "inactive", registered: "15 Ara 2024", lastLogin: "89 gun once", spent: 0 },
  { id: 1005, name: "Can Ozturk", email: "can.o@yahoo.com", plan: "Premium", status: "deleted", registered: "8 Tem 2024", lastLogin: "Silindi", spent: 447 },
]

const mockCoupons = [
  { code: "WELCOME20", discount: "%20", used: 847, limit: 1000, expiry: "Suresiz", status: "active" },
  { code: "STUDENT50", discount: "%50", used: 234, limit: 500, expiry: "31 Ara 2026", status: "active" },
  { code: "BLACKFRIDAY", discount: "%40", used: 1250, limit: 1000, expiry: "Sona Erdi", status: "inactive" },
]

const mockTickets = [
  { id: 1847, user: "Mehmet K", plan: "Premium", subject: "BTC fiyati guncellenmiyor", category: "Teknik", priority: "high", status: "open", time: "2 saat once" },
  { id: 1846, user: "Zeynep A", plan: "Free", subject: "Premium'a gecmek istiyorum", category: "Satis", priority: "medium", status: "open", time: "4 saat once" },
  { id: 1845, user: "Ali V", plan: "Pro", subject: "Fatura indirme sorunu", category: "Fatura", priority: "low", status: "pending", time: "1 gun once" },
]

const mockFeatureRequests = [
  { title: "Kripto tax raporu", votes: 342, status: "planned" },
  { title: "Mobil uygulama", votes: 287, status: "inprogress" },
  { title: "Otomatik DCA", votes: 198, status: "review" },
  { title: "Bank baglantisi", votes: 176, status: "backlog" },
]

const adminTabs = [
  { id: "overview", label: "Genel Bakis", icon: Eye },
  { id: "users", label: "Kullanicilar", icon: Users },
  { id: "subscriptions", label: "Uyeler", icon: CreditCard },
  { id: "analytics", label: "Istatistikler", icon: TrendingUp },
  { id: "content", label: "Icerik", icon: FileBarChart },
  { id: "system", label: "Sistem", icon: Database },
  { id: "security", label: "Guvenlik", icon: Lock },
  { id: "settings", label: "Ayarlar", icon: Settings },
  { id: "support", label: "Destek", icon: Sparkles },
]

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState("overview")
  const [showWarningBanner, setShowWarningBanner] = useState(true)
  const [currentTime, setCurrentTime] = useState(new Date())
  const [previewMode, setPreviewMode] = useState(false)

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY', maximumFractionDigits: 0 }).format(value)
  }

  const formatNumber = (value: number) => {
    return new Intl.NumberFormat('tr-TR').format(value)
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Admin Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-[rgba(255,71,87,0.15)] flex items-center justify-center">
              <Shield className="w-7 h-7 text-[#FF4757]" />
            </div>
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-2xl font-semibold text-[#F0F2F7]">Admin Paneli</h1>
                <span className="px-2 py-1 text-xs font-bold bg-[#FF4757] text-white rounded">ADMIN</span>
              </div>
              <p className="text-xs text-[#4E5A6B] mt-1">
                Son giris: Bugun 14:32 - IP: 185.34.12.89 - Chrome / macOS
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm">
              <span className="w-2 h-2 bg-[#00D4AA] rounded-full animate-pulse" />
              <span className="text-[#00D4AA]">Sistem Aktif</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 bg-[#151A23] rounded-lg border border-[rgba(255,255,255,0.06)]">
              <Clock className="w-4 h-4 text-[#8892A4]" />
              <span className="font-mono text-sm text-[#F0F2F7]">
                {currentTime.toLocaleTimeString('tr-TR')}
              </span>
            </div>
            <button
              onClick={() => setPreviewMode(!previewMode)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-colors ${
                previewMode 
                  ? "bg-[rgba(0,212,170,0.1)] border-[#00D4AA] text-[#00D4AA]" 
                  : "bg-[#151A23] border-[rgba(255,255,255,0.06)] text-[#8892A4]"
              }`}
            >
              <Eye className="w-4 h-4" />
              <span className="text-sm">Onizleme</span>
            </button>
            <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[#FF4757] text-[#FF4757] hover:bg-[rgba(255,71,87,0.1)] transition-colors">
              <LogOut className="w-4 h-4" />
              <span className="text-sm">Cikis</span>
            </button>
          </div>
        </div>

        {/* Warning Banner */}
        {showWarningBanner && (
          <div className="flex items-center justify-between px-4 py-3 bg-[rgba(255,71,87,0.1)] border border-[rgba(255,71,87,0.2)] rounded-xl">
            <div className="flex items-center gap-3">
              <Lock className="w-5 h-5 text-[#FF4757]" />
              <span className="text-sm text-[#F0F2F7]">
                Bu sayfa yalnizca yetkili yoneticiler tarafindan goruntulenebilir. Tum islemler kayit altina alinmaktadir.
              </span>
            </div>
            <button onClick={() => setShowWarningBanner(false)} className="text-[#8892A4] hover:text-[#F0F2F7]">
              <X className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* Main Content with Sidebar */}
        <div className="flex gap-6">
          {/* Admin Sidebar Tabs */}
          <div className="w-[220px] flex-shrink-0">
            <GlassCard className="p-2">
              <nav className="space-y-1">
                {adminTabs.map((tab) => {
                  const Icon = tab.icon
                  const isActive = activeTab === tab.id
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 relative ${
                        isActive
                          ? "bg-[rgba(255,71,87,0.08)] text-[#FF4757]"
                          : "text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)] hover:text-[#F0F2F7]"
                      }`}
                    >
                      {isActive && (
                        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-6 bg-[#FF4757] rounded-r-full" />
                      )}
                      <Icon className="w-5 h-5" />
                      <span className="text-sm font-medium">{tab.label}</span>
                      {tab.id === "support" && (
                        <span className="ml-auto px-1.5 py-0.5 text-[10px] font-bold bg-[#FFB833] text-[#080A0F] rounded">
                          12
                        </span>
                      )}
                      {tab.id === "security" && (
                        <span className="ml-auto px-1.5 py-0.5 text-[10px] font-bold bg-[#FF4757] text-white rounded">
                          2
                        </span>
                      )}
                    </button>
                  )
                })}
              </nav>
              <div className="mt-4 pt-4 border-t border-[rgba(255,255,255,0.06)]">
                <p className="text-[10px] text-[#4E5A6B] text-center">v2.4.1</p>
              </div>
            </GlassCard>
          </div>

          {/* Content Area */}
          <div className="flex-1 min-w-0">
            {activeTab === "overview" && <OverviewTab data={mockKpiData} formatCurrency={formatCurrency} formatNumber={formatNumber} />}
            {activeTab === "users" && <UsersTab users={mockUsers} formatCurrency={formatCurrency} />}
            {activeTab === "subscriptions" && <SubscriptionsTab coupons={mockCoupons} formatCurrency={formatCurrency} />}
            {activeTab === "analytics" && <AnalyticsTab />}
            {activeTab === "content" && <ContentTab />}
            {activeTab === "system" && <SystemTab />}
            {activeTab === "security" && <SecurityTab />}
            {activeTab === "settings" && <AdminSettingsTab />}
            {activeTab === "support" && <SupportTab tickets={mockTickets} requests={mockFeatureRequests} />}
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}

// Overview Tab Component
function OverviewTab({ data, formatCurrency, formatNumber }: { data: typeof mockKpiData; formatCurrency: (v: number) => string; formatNumber: (v: number) => string }) {
  return (
    <div className="space-y-6">
      {/* KPI Stats */}
      <div className="grid grid-cols-6 gap-4">
        <GlassCard className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <Users className="w-5 h-5 text-[#4B9EFF]" />
            <span className="text-xs text-[#8892A4]">Toplam Kullanici</span>
          </div>
          <p className="text-2xl font-mono font-semibold text-[#F0F2F7]">{formatNumber(data.totalUsers)}</p>
          <div className="flex items-center gap-1 mt-1">
            <ArrowUp className="w-3 h-3 text-[#00D4AA]" />
            <span className="text-xs text-[#00D4AA]">+{data.newUsersThisMonth} bu ay</span>
          </div>
        </GlassCard>

        <GlassCard className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-5 h-5 text-[#00D4AA]" />
            <span className="text-xs text-[#8892A4]">Aktif Bugun</span>
          </div>
          <p className="text-2xl font-mono font-semibold text-[#F0F2F7]">{formatNumber(data.activeToday)}</p>
          <p className="text-xs text-[#8892A4] mt-1">%26.6 gunluk aktiflik</p>
        </GlassCard>

        <GlassCard className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-5 h-5 text-[#FFB833]" />
            <span className="text-xs text-[#8892A4]">MRR</span>
          </div>
          <p className="text-2xl font-mono font-semibold text-[#FFB833]">{formatCurrency(data.mrr)}</p>
          <div className="flex items-center gap-1 mt-1">
            <ArrowUp className="w-3 h-3 text-[#00D4AA]" />
            <span className="text-xs text-[#00D4AA]">+%{data.mrrGrowth}</span>
          </div>
        </GlassCard>

        <GlassCard className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <CreditCard className="w-5 h-5 text-[#A78BFA]" />
            <span className="text-xs text-[#8892A4]">Abonelikler</span>
          </div>
          <p className="text-2xl font-mono font-semibold text-[#F0F2F7]">{formatNumber(data.activeSubscriptions)}</p>
          <p className="text-xs text-[#8892A4] mt-1">Free: {formatNumber(data.freeUsers)}</p>
        </GlassCard>

        <GlassCard className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <UserMinus className="w-5 h-5 text-[#FF4757]" />
            <span className="text-xs text-[#8892A4]">Churn</span>
          </div>
          <p className="text-2xl font-mono font-semibold text-[#F0F2F7]">%{data.churnRate}</p>
          <p className="text-xs text-[#FF4757] mt-1">{data.churnCount} iptal bu ay</p>
        </GlassCard>

        <GlassCard className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="w-5 h-5 text-[#00D4AA]" />
            <span className="text-xs text-[#8892A4]">ARPU</span>
          </div>
          <p className="text-2xl font-mono font-semibold text-[#F0F2F7]">{formatCurrency(data.arpu)}</p>
          <p className="text-xs text-[#8892A4] mt-1">Kullanici basina gelir</p>
        </GlassCard>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-5 gap-6">
        <div className="col-span-3 space-y-6">
          {/* User Growth Chart */}
          <GlassCard className="p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-[#F0F2F7]">Kullanici Buyume Trendi</h3>
              <div className="flex gap-2">
                {["Gunluk", "Haftalik", "Aylik"].map((period, i) => (
                  <button
                    key={period}
                    className={`px-3 py-1 text-xs rounded-lg transition-colors ${
                      i === 2 ? "bg-[rgba(255,71,87,0.1)] text-[#FF4757]" : "text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)]"
                    }`}
                  >
                    {period}
                  </button>
                ))}
              </div>
            </div>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={mockUserGrowthData}>
                  <defs>
                    <linearGradient id="colorKayit" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#00D4AA" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#00D4AA" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                  <XAxis dataKey="month" tick={{ fill: '#8892A4', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#8892A4', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#151A23', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                    labelStyle={{ color: '#F0F2F7' }}
                  />
                  <Area type="monotone" dataKey="kayit" stroke="#00D4AA" fillOpacity={1} fill="url(#colorKayit)" strokeWidth={2} />
                  <Line type="monotone" dataKey="ayrilma" stroke="#FF4757" strokeWidth={2} dot={false} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </GlassCard>

          {/* Revenue Chart */}
          <GlassCard className="p-4">
            <h3 className="text-sm font-medium text-[#F0F2F7] mb-4">Gelir Dagilimi</h3>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={mockRevenueData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                  <XAxis dataKey="month" tick={{ fill: '#8892A4', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#8892A4', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#151A23', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                    formatter={(value: number) => [`${(value / 1000).toFixed(0)}K TL`, '']}
                  />
                  <Bar dataKey="premium" fill="#A78BFA" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="pro" fill="#FFB833" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </GlassCard>
        </div>

        {/* Activity Feed */}
        <div className="col-span-2">
          <GlassCard className="p-4 h-full">
            <div className="flex items-center gap-2 mb-4">
              <span className="w-2 h-2 bg-[#FF4757] rounded-full animate-pulse" />
              <h3 className="text-sm font-medium text-[#F0F2F7]">Canli Aktivite</h3>
            </div>
            <div className="space-y-3 max-h-[380px] overflow-y-auto finos-scrollbar">
              {mockActivityFeed.map((item, i) => (
                <div key={i} className="flex items-start gap-3 p-2 rounded-lg hover:bg-[rgba(255,255,255,0.02)]">
                  <div className="w-2 h-2 rounded-full mt-1.5" style={{ backgroundColor: item.color }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-[#F0F2F7] truncate">{item.text}</p>
                    <p className="text-xs text-[#4E5A6B]">{item.time}</p>
                  </div>
                </div>
              ))}
            </div>
            <button className="flex items-center gap-1 text-xs text-[#FF4757] mt-4 hover:underline">
              Tumunu Gor <ChevronRight className="w-3 h-3" />
            </button>
          </GlassCard>
        </div>
      </div>

      {/* System Status */}
      <div className="grid grid-cols-3 gap-6">
        <GlassCard className="p-4">
          <h3 className="text-sm font-medium text-[#F0F2F7] mb-4">Sistem Durumu</h3>
          <div className="space-y-3">
            {mockSystemStatus.map((service, i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${
                    service.status === "active" ? "bg-[#00D4AA]" : "bg-[#FFB833] animate-pulse"
                  }`} />
                  <span className="text-sm text-[#F0F2F7]">{service.name}</span>
                </div>
                <span className="text-xs text-[#8892A4]">{service.detail}</span>
              </div>
            ))}
          </div>
          <p className="text-xs text-[#4E5A6B] mt-4">Son kontrol: 30 sn once</p>
        </GlassCard>

        <GlassCard className="p-4">
          <h3 className="text-sm font-medium text-[#F0F2F7] mb-4">Performans</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#8892A4]">API Yanit Suresi</span>
              <span className="font-mono text-sm text-[#00D4AA]">124ms</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#8892A4]">Sayfa Yukleme</span>
              <span className="font-mono text-sm text-[#00D4AA]">1.8s</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#8892A4]">Hata Orani</span>
              <span className="font-mono text-sm text-[#00D4AA]">%0.12</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#8892A4]">Uptime</span>
              <span className="font-mono text-sm text-[#00D4AA]">%99.97</span>
            </div>
          </div>
          <p className="text-xs text-[#4E5A6B] mt-4">32 gundur kesintisiz</p>
        </GlassCard>

        <GlassCard className="p-4">
          <h3 className="text-sm font-medium text-[#F0F2F7] mb-4">Bugunun Ozeti</h3>
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-[#00D4AA]" />
              <span className="text-[#F0F2F7]">234 yeni kayit</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CreditCard className="w-4 h-4 text-[#FFB833]" />
              <span className="text-[#F0F2F7]">18 yeni odeme - 4.218 TL</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <XCircle className="w-4 h-4 text-[#FF4757]" />
              <span className="text-[#F0F2F7]">3 abonelik iptali</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Mail className="w-4 h-4 text-[#4B9EFF]" />
              <span className="text-[#F0F2F7]">847 email gonderildi</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <AlertTriangle className="w-4 h-4 text-[#FFB833]" />
              <span className="text-[#F0F2F7]">2 guvenlik uyarisi</span>
            </div>
          </div>
          <button className="w-full mt-4 px-3 py-2 bg-[#FF4757] text-white text-sm rounded-lg hover:bg-[#e63e4d] transition-colors">
            Gunluk Rapor Indir
          </button>
        </GlassCard>
      </div>
    </div>
  )
}

// Users Tab Component
function UsersTab({ users, formatCurrency }: { users: typeof mockUsers; formatCurrency: (v: number) => string }) {
  const [searchTerm, setSearchTerm] = useState("")
  
  return (
    <div className="space-y-6">
      {/* Action Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h2 className="text-lg font-medium text-[#F0F2F7]">Kullanici Yonetimi</h2>
          <span className="px-2 py-1 text-xs bg-[rgba(255,255,255,0.06)] text-[#8892A4] rounded">12,847 toplam</span>
        </div>
        <div className="flex items-center gap-2">
          <button className="px-3 py-2 text-sm text-[#8892A4] border border-[rgba(255,255,255,0.1)] rounded-lg hover:bg-[rgba(255,255,255,0.04)]">
            <Download className="w-4 h-4 inline mr-1" /> CSV Aktar
          </button>
          <button className="px-3 py-2 text-sm text-[#00D4AA] border border-[#00D4AA] rounded-lg hover:bg-[rgba(0,212,170,0.1)]">
            <Download className="w-4 h-4 inline mr-1" /> Excel
          </button>
          <button className="px-3 py-2 text-sm bg-[#FF4757] text-white rounded-lg hover:bg-[#e63e4d]">
            <Plus className="w-4 h-4 inline mr-1" /> Kullanici Ekle
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <GlassCard className="p-4">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex-1 min-w-[200px] relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8892A4]" />
            <input
              type="text"
              placeholder="Ad, email, ID ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#F0F2F7] placeholder-[#4E5A6B] focus:outline-none focus:border-[#FF4757]"
            />
          </div>
          <select className="px-3 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#F0F2F7]">
            <option>Tum Planlar</option>
            <option>Free</option>
            <option>Premium</option>
            <option>Pro</option>
          </select>
          <select className="px-3 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#F0F2F7]">
            <option>Tum Durumlar</option>
            <option>Aktif</option>
            <option>Pasif</option>
            <option>Askiya Alinmis</option>
          </select>
          <button className="px-4 py-2 bg-[#FF4757] text-white text-sm rounded-lg">Filtrele</button>
          <button className="px-4 py-2 text-[#8892A4] text-sm hover:text-[#F0F2F7]">Temizle</button>
        </div>
      </GlassCard>

      {/* Users Table */}
      <GlassCard className="p-0 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[rgba(255,255,255,0.06)]">
              <th className="p-4 text-left">
                <input type="checkbox" className="rounded border-[rgba(255,255,255,0.2)]" />
              </th>
              <th className="p-4 text-left text-xs font-medium text-[#8892A4]">#</th>
              <th className="p-4 text-left text-xs font-medium text-[#8892A4]">Kullanici</th>
              <th className="p-4 text-left text-xs font-medium text-[#8892A4]">Plan</th>
              <th className="p-4 text-left text-xs font-medium text-[#8892A4]">Durum</th>
              <th className="p-4 text-left text-xs font-medium text-[#8892A4]">Kayit</th>
              <th className="p-4 text-left text-xs font-medium text-[#8892A4]">Son Giris</th>
              <th className="p-4 text-left text-xs font-medium text-[#8892A4]">Harcama</th>
              <th className="p-4 text-left text-xs font-medium text-[#8892A4]">Islemler</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr 
                key={user.id} 
                className={`border-b border-[rgba(255,255,255,0.06)] hover:bg-[rgba(255,71,87,0.04)] transition-colors ${
                  user.status === "deleted" ? "opacity-50" : ""
                } ${user.status === "suspended" ? "border-l-2 border-l-[#FFB833]" : ""}`}
              >
                <td className="p-4">
                  <input type="checkbox" className="rounded border-[rgba(255,255,255,0.2)]" />
                </td>
                <td className="p-4 text-sm text-[#8892A4]">#{user.id}</td>
                <td className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#4B9EFF] to-[#A78BFA] flex items-center justify-center">
                      <span className="text-xs font-semibold text-white">{user.name.split(" ").map(n => n[0]).join("")}</span>
                    </div>
                    <div>
                      <p className={`text-sm font-medium text-[#F0F2F7] ${user.status === "deleted" ? "line-through" : ""}`}>{user.name}</p>
                      <p className={`text-xs text-[#8892A4] ${user.status === "deleted" ? "line-through" : ""}`}>{user.email}</p>
                    </div>
                  </div>
                </td>
                <td className="p-4">
                  <span className={`px-2 py-1 text-xs font-medium rounded ${
                    user.plan === "Premium" ? "bg-[rgba(167,139,250,0.2)] text-[#A78BFA]" :
                    user.plan === "Pro" ? "bg-[rgba(255,184,51,0.2)] text-[#FFB833]" :
                    "bg-[rgba(255,255,255,0.06)] text-[#8892A4]"
                  }`}>
                    {user.plan}
                  </span>
                </td>
                <td className="p-4">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${
                      user.status === "active" ? "bg-[#00D4AA]" :
                      user.status === "online" ? "bg-[#00D4AA] animate-pulse" :
                      user.status === "suspended" ? "bg-[#FFB833]" :
                      user.status === "inactive" ? "bg-[#8892A4]" :
                      "bg-[#FF4757]"
                    }`} />
                    <span className={`text-xs ${
                      user.status === "active" ? "text-[#00D4AA]" :
                      user.status === "online" ? "text-[#00D4AA]" :
                      user.status === "suspended" ? "text-[#FFB833]" :
                      user.status === "inactive" ? "text-[#8892A4]" :
                      "text-[#FF4757]"
                    }`}>
                      {user.status === "active" ? "Aktif" :
                       user.status === "online" ? "Online" :
                       user.status === "suspended" ? "Askida" :
                       user.status === "inactive" ? "Pasif" :
                       "Silindi"}
                    </span>
                  </div>
                </td>
                <td className="p-4 text-sm text-[#8892A4]">{user.registered}</td>
                <td className={`p-4 text-sm ${user.lastLogin.includes("gun once") && parseInt(user.lastLogin) > 30 ? "text-[#FFB833]" : "text-[#8892A4]"}`}>
                  {user.lastLogin}
                </td>
                <td className="p-4 font-mono text-sm text-[#FFB833]">{formatCurrency(user.spent)}</td>
                <td className="p-4">
                  <div className="flex items-center gap-2">
                    <button className="p-1.5 hover:bg-[rgba(255,255,255,0.04)] rounded"><Eye className="w-4 h-4 text-[#8892A4]" /></button>
                    <button className="p-1.5 hover:bg-[rgba(255,255,255,0.04)] rounded"><Edit className="w-4 h-4 text-[#8892A4]" /></button>
                    <button className="p-1.5 hover:bg-[rgba(255,255,255,0.04)] rounded"><MoreHorizontal className="w-4 h-4 text-[#8892A4]" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="flex items-center justify-between p-4 border-t border-[rgba(255,255,255,0.06)]">
          <p className="text-sm text-[#8892A4]">1-5 / 12,847 kullanici gosteriliyor</p>
          <div className="flex items-center gap-2">
            <button className="px-3 py-1 text-sm text-[#8892A4] hover:text-[#F0F2F7]">{"<"}</button>
            <button className="px-3 py-1 text-sm bg-[#FF4757] text-white rounded">1</button>
            <button className="px-3 py-1 text-sm text-[#8892A4] hover:text-[#F0F2F7]">2</button>
            <button className="px-3 py-1 text-sm text-[#8892A4] hover:text-[#F0F2F7]">3</button>
            <span className="text-[#8892A4]">...</span>
            <button className="px-3 py-1 text-sm text-[#8892A4] hover:text-[#F0F2F7]">514</button>
            <button className="px-3 py-1 text-sm text-[#8892A4] hover:text-[#F0F2F7]">{">"}</button>
          </div>
        </div>
      </GlassCard>
    </div>
  )
}

// Subscriptions Tab Component
function SubscriptionsTab({ coupons, formatCurrency }: { coupons: typeof mockCoupons; formatCurrency: (v: number) => string }) {
  return (
    <div className="space-y-6">
      {/* Top Stats */}
      <div className="grid grid-cols-5 gap-4">
        <GlassCard className="p-4">
          <p className="text-xs text-[#8892A4] mb-1">MRR</p>
          <p className="text-2xl font-mono font-semibold text-[#FFB833]">{formatCurrency(284750)}</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs text-[#8892A4] mb-1">ARR</p>
          <p className="text-2xl font-mono font-semibold text-[#F0F2F7]">{formatCurrency(3417000)}</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs text-[#8892A4] mb-1">Aktif Abonelik</p>
          <p className="text-2xl font-mono font-semibold text-[#F0F2F7]">1,923</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs text-[#8892A4] mb-1">Yeni Bu Ay</p>
          <p className="text-2xl font-mono font-semibold text-[#00D4AA]">+156</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs text-[#8892A4] mb-1">Iptal Bu Ay</p>
          <p className="text-2xl font-mono font-semibold text-[#FF4757]">-52</p>
        </GlassCard>
      </div>

      {/* Plan Cards */}
      <div className="grid grid-cols-3 gap-6">
        <GlassCard className="p-6 border-[rgba(255,255,255,0.06)]">
          <p className="text-lg font-semibold text-[#8892A4] mb-2">FREE</p>
          <p className="text-3xl font-mono font-bold text-[#F0F2F7] mb-4">{formatCurrency(0)}<span className="text-sm font-normal">/ay</span></p>
          <p className="text-2xl font-mono text-[#F0F2F7] mb-2">10,924</p>
          <div className="w-full h-2 bg-[rgba(255,255,255,0.06)] rounded-full overflow-hidden mb-4">
            <div className="h-full bg-[#8892A4] rounded-full" style={{ width: "85%" }} />
          </div>
          <p className="text-xs text-[#8892A4] mb-4">%85 toplam kullanici</p>
          <button className="w-full px-4 py-2 border border-[rgba(255,255,255,0.1)] text-[#8892A4] text-sm rounded-lg hover:bg-[rgba(255,255,255,0.04)]">
            Plani Duzenle
          </button>
        </GlassCard>

        <GlassCard className="p-6 border-[#A78BFA] border-2 relative">
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-[#A78BFA] text-white text-xs font-bold rounded">
            EN POPULER
          </div>
          <div className="flex items-center gap-2 mb-2">
            <Star className="w-5 h-5 text-[#A78BFA]" />
            <p className="text-lg font-semibold text-[#A78BFA]">PREMIUM</p>
          </div>
          <p className="text-3xl font-mono font-bold text-[#F0F2F7] mb-4">{formatCurrency(149)}<span className="text-sm font-normal">/ay</span></p>
          <p className="text-2xl font-mono text-[#F0F2F7] mb-2">1,456</p>
          <p className="text-xs text-[#8892A4] mb-4">Aylik gelir: {formatCurrency(216944)}</p>
          <button className="w-full px-4 py-2 bg-[#A78BFA] text-white text-sm rounded-lg hover:bg-[#9171e8]">
            Plani Duzenle
          </button>
        </GlassCard>

        <GlassCard className="p-6 border-[#FFB833] border">
          <div className="flex items-center gap-2 mb-2">
            <Crown className="w-5 h-5 text-[#FFB833]" />
            <p className="text-lg font-semibold text-[#FFB833]">PRO</p>
          </div>
          <p className="text-3xl font-mono font-bold text-[#F0F2F7] mb-4">{formatCurrency(299)}<span className="text-sm font-normal">/ay</span></p>
          <p className="text-2xl font-mono text-[#F0F2F7] mb-2">467</p>
          <p className="text-xs text-[#8892A4] mb-4">Aylik gelir: {formatCurrency(139633)}</p>
          <button className="w-full px-4 py-2 bg-[#FFB833] text-[#080A0F] text-sm font-semibold rounded-lg hover:bg-[#e6a52e]">
            Plani Duzenle
          </button>
        </GlassCard>
      </div>

      {/* Coupons */}
      <GlassCard className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-medium text-[#F0F2F7]">Kupon Kodlari</h3>
          <button className="px-3 py-1.5 text-sm bg-[#FF4757] text-white rounded-lg">
            <Plus className="w-4 h-4 inline mr-1" /> Yeni Kupon
          </button>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b border-[rgba(255,255,255,0.06)]">
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Kod</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Indirim</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Kullanim</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Gecerlilik</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Durum</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Islem</th>
            </tr>
          </thead>
          <tbody>
            {coupons.map((coupon, i) => (
              <tr key={i} className="border-b border-[rgba(255,255,255,0.06)]">
                <td className="p-3 font-mono text-sm text-[#F0F2F7]">{coupon.code}</td>
                <td className="p-3 text-sm text-[#00D4AA]">{coupon.discount}</td>
                <td className="p-3 text-sm text-[#8892A4]">
                  {coupon.used}/{coupon.limit}
                  {coupon.used > coupon.limit && <AlertTriangle className="w-4 h-4 text-[#FFB833] inline ml-1" />}
                </td>
                <td className="p-3 text-sm text-[#8892A4]">{coupon.expiry}</td>
                <td className="p-3">
                  <span className={`px-2 py-1 text-xs rounded ${
                    coupon.status === "active" ? "bg-[rgba(0,212,170,0.2)] text-[#00D4AA]" : "bg-[rgba(255,71,87,0.2)] text-[#FF4757]"
                  }`}>
                    {coupon.status === "active" ? "Aktif" : "Pasif"}
                  </span>
                </td>
                <td className="p-3">
                  <div className="flex items-center gap-2">
                    <button className="p-1 hover:bg-[rgba(255,255,255,0.04)] rounded"><Edit className="w-4 h-4 text-[#8892A4]" /></button>
                    <button className="p-1 hover:bg-[rgba(255,255,255,0.04)] rounded"><Trash2 className="w-4 h-4 text-[#FF4757]" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </GlassCard>
    </div>
  )
}

// Analytics Tab Component
function AnalyticsTab() {
  const funnelData = [
    { name: "Ziyaretci", value: 50000, rate: "100%" },
    { name: "Kayit Sayfasi", value: 8400, rate: "16.8%" },
    { name: "Kayit Tamamlandi", value: 4200, rate: "50%" },
    { name: "Ilk Varlik Ekledi", value: 2800, rate: "67%" },
    { name: "Premium Gecis", value: 420, rate: "15%" },
  ]

  return (
    <div className="space-y-6">
      {/* Date Range */}
      <GlassCard className="p-4">
        <div className="flex items-center gap-4 flex-wrap">
          {["Bugun", "Bu Hafta", "Bu Ay", "Son 3 Ay", "Bu Yil", "Tumu"].map((period, i) => (
            <button
              key={period}
              className={`px-3 py-1.5 text-sm rounded-lg transition-colors ${
                i === 2 ? "bg-[#FF4757] text-white" : "text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)]"
              }`}
            >
              {period}
            </button>
          ))}
          <div className="ml-auto flex items-center gap-2">
            <button className="px-4 py-2 bg-[#FF4757] text-white text-sm rounded-lg">Rapor Olustur</button>
          </div>
        </div>
      </GlassCard>

      {/* Metrics */}
      <div className="grid grid-cols-3 gap-6">
        <GlassCard className="p-4">
          <p className="text-xs text-[#8892A4] mb-2">Toplam Sayfa Goruntuleme</p>
          <p className="text-3xl font-mono font-semibold text-[#F0F2F7]">2,847,291</p>
          <p className="text-xs text-[#00D4AA] mt-1">+%23 gecen aya gore</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs text-[#8892A4] mb-2">Ort. Oturum Suresi</p>
          <p className="text-3xl font-mono font-semibold text-[#F0F2F7]">18dk 42sn</p>
          <p className="text-xs text-[#00D4AA] mt-1">+2dk gecen aya gore</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs text-[#8892A4] mb-2">Kullanici Tutma</p>
          <div className="flex items-center gap-4 mt-2">
            <div>
              <span className="text-lg font-mono text-[#00D4AA]">D1: %68</span>
            </div>
            <div>
              <span className="text-lg font-mono text-[#FFB833]">D7: %42</span>
            </div>
            <div>
              <span className="text-lg font-mono text-[#FF4757]">D30: %28</span>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* Funnel */}
      <GlassCard className="p-4">
        <h3 className="text-sm font-medium text-[#F0F2F7] mb-4">Kayit Donusum Hunisi</h3>
        <div className="space-y-3">
          {funnelData.map((step, i) => (
            <div key={i} className="flex items-center gap-4">
              <div className="w-32 text-sm text-[#8892A4]">{step.name}</div>
              <div className="flex-1 h-8 bg-[rgba(255,255,255,0.06)] rounded-lg overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-[#FF4757] to-[#00D4AA] rounded-lg flex items-center justify-end pr-3"
                  style={{ width: `${(step.value / 50000) * 100}%` }}
                >
                  <span className="text-xs font-mono text-white">{step.value.toLocaleString()}</span>
                </div>
              </div>
              <div className="w-16 text-sm text-[#8892A4] text-right">{step.rate}</div>
            </div>
          ))}
        </div>
      </GlassCard>

      {/* Geographic */}
      <GlassCard className="p-4">
        <h3 className="text-sm font-medium text-[#F0F2F7] mb-4">Kullanici Dagilimi - Turkiye</h3>
        <div className="space-y-3">
          {[
            { city: "Istanbul", count: 5847, percent: 45.5 },
            { city: "Ankara", count: 2341, percent: 18.2 },
            { city: "Izmir", count: 1567, percent: 12.2 },
            { city: "Bursa", count: 678, percent: 5.3 },
            { city: "Diger", count: 2414, percent: 18.8 },
          ].map((city, i) => (
            <div key={i} className="flex items-center gap-4">
              <div className="w-20 text-sm text-[#F0F2F7]">{city.city}</div>
              <div className="flex-1 h-4 bg-[rgba(255,255,255,0.06)] rounded-full overflow-hidden">
                <div 
                  className="h-full bg-[#FF4757] rounded-full"
                  style={{ width: `${city.percent}%` }}
                />
              </div>
              <div className="w-24 text-sm text-[#8892A4] text-right">{city.count.toLocaleString()} (%{city.percent})</div>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  )
}

// Content Tab Component
function ContentTab() {
  return (
    <div className="space-y-6">
      {/* Tabs */}
      <GlassCard className="p-2">
        <div className="flex gap-2">
          {["Bildirimler", "Email Kampanyalari", "Push Bildirimleri", "Segmentasyon"].map((tab, i) => (
            <button
              key={tab}
              className={`px-4 py-2 text-sm rounded-lg transition-colors ${
                i === 0 ? "bg-[#FF4757] text-white" : "text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)]"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </GlassCard>

      {/* New Notification */}
      <GlassCard className="p-4">
        <h3 className="text-sm font-medium text-[#F0F2F7] mb-4">Yeni Bildirim Gonder</h3>
        <div className="space-y-4">
          <div className="flex gap-4">
            <select className="flex-1 px-3 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#F0F2F7]">
              <option>Tumu (12,847)</option>
              <option>Premium kullanicilar</option>
              <option>Pro kullanicilar</option>
              <option>Free kullanicilar</option>
            </select>
            <div className="flex gap-2">
              {["In-app", "Email", "Push", "SMS"].map((channel, i) => (
                <label key={channel} className="flex items-center gap-2 px-3 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg cursor-pointer">
                  <input type="checkbox" defaultChecked={i < 2} className="rounded" />
                  <span className="text-sm text-[#F0F2F7]">{channel}</span>
                </label>
              ))}
            </div>
          </div>
          <input
            type="text"
            placeholder="Baslik (max 80 karakter)"
            className="w-full px-4 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#F0F2F7] placeholder-[#4E5A6B]"
          />
          <textarea
            placeholder="Mesajinizi yazin..."
            rows={4}
            className="w-full px-4 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#F0F2F7] placeholder-[#4E5A6B] resize-none"
          />
          <div className="flex justify-end gap-2">
            <button className="px-4 py-2 text-sm text-[#8892A4] border border-[rgba(255,255,255,0.1)] rounded-lg">Taslak Kaydet</button>
            <button className="px-4 py-2 text-sm bg-[#FF4757] text-white rounded-lg">Gonder</button>
          </div>
        </div>
      </GlassCard>

      {/* Sent Notifications */}
      <GlassCard className="p-4">
        <h3 className="text-sm font-medium text-[#F0F2F7] mb-4">Gonderilen Bildirimler</h3>
        <table className="w-full">
          <thead>
            <tr className="border-b border-[rgba(255,255,255,0.06)]">
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Baslik</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Hedef</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Gonderildi</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Acilma</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Tiklama</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Durum</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b border-[rgba(255,255,255,0.06)]">
              <td className="p-3 text-sm text-[#F0F2F7]">Mayis Portfolyo Ozeti</td>
              <td className="p-3 text-sm text-[#8892A4]">Premium</td>
              <td className="p-3 text-sm text-[#8892A4]">1,456</td>
              <td className="p-3 text-sm text-[#00D4AA]">%62</td>
              <td className="p-3 text-sm text-[#FFB833]">%18</td>
              <td className="p-3"><span className="px-2 py-1 text-xs bg-[rgba(0,212,170,0.2)] text-[#00D4AA] rounded">Gonderildi</span></td>
            </tr>
            <tr className="border-b border-[rgba(255,255,255,0.06)]">
              <td className="p-3 text-sm text-[#F0F2F7]">Yeni Simulator Ozelligi</td>
              <td className="p-3 text-sm text-[#8892A4]">Tumu</td>
              <td className="p-3 text-sm text-[#8892A4]">12,847</td>
              <td className="p-3 text-sm text-[#00D4AA]">%41</td>
              <td className="p-3 text-sm text-[#FFB833]">%12</td>
              <td className="p-3"><span className="px-2 py-1 text-xs bg-[rgba(0,212,170,0.2)] text-[#00D4AA] rounded">Gonderildi</span></td>
            </tr>
          </tbody>
        </table>
      </GlassCard>
    </div>
  )
}

// System Tab Component
function SystemTab() {
  return (
    <div className="space-y-6">
      {/* Gauges */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "CPU", value: 34, color: "#00D4AA" },
          { label: "RAM", value: 58, color: "#FFB833" },
          { label: "Disk", value: 41, color: "#00D4AA" },
          { label: "Bant Genisligi", value: 23, color: "#00D4AA" },
        ].map((gauge) => (
          <GlassCard key={gauge.label} className="p-4">
            <p className="text-xs text-[#8892A4] mb-2">{gauge.label}</p>
            <div className="relative w-20 h-20 mx-auto">
              <svg className="w-20 h-20 transform -rotate-90">
                <circle cx="40" cy="40" r="32" stroke="rgba(255,255,255,0.06)" strokeWidth="8" fill="none" />
                <circle 
                  cx="40" cy="40" r="32" 
                  stroke={gauge.color} 
                  strokeWidth="8" 
                  fill="none"
                  strokeDasharray={`${gauge.value * 2.01} 201`}
                  strokeLinecap="round"
                />
              </svg>
              <span className="absolute inset-0 flex items-center justify-center text-lg font-mono text-[#F0F2F7]">
                %{gauge.value}
              </span>
            </div>
          </GlassCard>
        ))}
      </div>

      {/* Services */}
      <GlassCard className="p-4">
        <h3 className="text-sm font-medium text-[#F0F2F7] mb-4">Servis Durumu</h3>
        <div className="grid grid-cols-3 gap-4">
          {[
            { name: "API Gateway", status: "active", detail: "124ms | %99.99 uptime" },
            { name: "PostgreSQL DB", status: "active", detail: "8ms query | 2.3M satir" },
            { name: "Redis Cache", status: "active", detail: "Hit rate %94" },
            { name: "AI Servisi", status: "active", detail: "1.2s avg response" },
            { name: "Email (Resend)", status: "slow", detail: "4.2s delivery" },
            { name: "CDN (Cloudflare)", status: "active", detail: "98ms global avg" },
          ].map((service, i) => (
            <div key={i} className="p-3 bg-[#151A23] rounded-lg border border-[rgba(255,255,255,0.06)]">
              <div className="flex items-center gap-2 mb-2">
                <span className={`w-2 h-2 rounded-full ${service.status === "active" ? "bg-[#00D4AA]" : "bg-[#FFB833] animate-pulse"}`} />
                <span className="text-sm text-[#F0F2F7]">{service.name}</span>
              </div>
              <p className="text-xs text-[#8892A4]">{service.detail}</p>
            </div>
          ))}
        </div>
      </GlassCard>

      {/* Logs */}
      <GlassCard className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-medium text-[#F0F2F7]">Log Goruntuleyici</h3>
          <div className="flex gap-2">
            {["Error", "Warning", "Info"].map((level, i) => (
              <button
                key={level}
                className={`px-2 py-1 text-xs rounded ${
                  i === 0 ? "bg-[rgba(255,71,87,0.2)] text-[#FF4757]" :
                  i === 1 ? "bg-[rgba(255,184,51,0.2)] text-[#FFB833]" :
                  "bg-[rgba(75,158,255,0.2)] text-[#4B9EFF]"
                }`}
              >
                {level}
              </button>
            ))}
          </div>
        </div>
        <div className="bg-[#080A0F] rounded-lg p-3 font-mono text-xs space-y-1 max-h-[200px] overflow-y-auto">
          <p><span className="text-[#FF4757]">[14:32:01] ERROR:</span> <span className="text-[#F0F2F7]">Payment failed user#1847 — Stripe card_declined</span></p>
          <p><span className="text-[#FFB833]">[14:31:58] WARN:</span> <span className="text-[#F0F2F7]">Rate limit approaching user#2341 — 89/100</span></p>
          <p><span className="text-[#4B9EFF]">[14:31:45] INFO:</span> <span className="text-[#F0F2F7]">AI session started user#1092 — 1.2s</span></p>
          <p><span className="text-[#4B9EFF]">[14:31:23] INFO:</span> <span className="text-[#F0F2F7]">New signup: user#12847 — mehmet@...</span></p>
        </div>
      </GlassCard>
    </div>
  )
}

// Security Tab Component
function SecurityTab() {
  return (
    <div className="space-y-6">
      {/* Security Score */}
      <div className="grid grid-cols-3 gap-6">
        <GlassCard className="p-4">
          <h3 className="text-sm font-medium text-[#F0F2F7] mb-4">Guvenlik Skoru</h3>
          <div className="relative w-32 h-32 mx-auto mb-4">
            <svg className="w-32 h-32 transform -rotate-90">
              <circle cx="64" cy="64" r="56" stroke="rgba(255,255,255,0.06)" strokeWidth="12" fill="none" />
              <circle 
                cx="64" cy="64" r="56" 
                stroke="#00D4AA" 
                strokeWidth="12" 
                fill="none"
                strokeDasharray="307 352"
                strokeLinecap="round"
              />
            </svg>
            <span className="absolute inset-0 flex items-center justify-center text-3xl font-mono text-[#00D4AA]">87</span>
          </div>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between"><span className="text-[#8892A4]">Sifre politikasi</span><span className="text-[#00D4AA]">95/100</span></div>
            <div className="flex justify-between"><span className="text-[#8892A4]">2FA benimseme</span><span className="text-[#FFB833]">72/100</span></div>
            <div className="flex justify-between"><span className="text-[#8892A4]">Veri sifreleme</span><span className="text-[#00D4AA]">100/100</span></div>
          </div>
        </GlassCard>

        <GlassCard className="p-4 border-[#FF4757] border">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-5 h-5 text-[#FF4757]" />
            <h3 className="text-sm font-medium text-[#FF4757]">2 Aktif Uyari</h3>
          </div>
          <div className="space-y-3">
            <div className="p-3 bg-[rgba(255,71,87,0.1)] rounded-lg">
              <p className="text-sm text-[#F0F2F7]">5x basarisiz giris: test@mail.com</p>
              <p className="text-xs text-[#8892A4] mt-1">IP: 95.134.12.x</p>
              <button className="mt-2 px-3 py-1 text-xs bg-[#FF4757] text-white rounded">Incele</button>
            </div>
            <div className="p-3 bg-[rgba(255,71,87,0.1)] rounded-lg">
              <p className="text-sm text-[#F0F2F7]">Olagandisi konum: user#4521</p>
              <p className="text-xs text-[#8892A4] mt-1">Romanya</p>
              <button className="mt-2 px-3 py-1 text-xs bg-[#FF4757] text-white rounded">Incele</button>
            </div>
          </div>
        </GlassCard>

        <GlassCard className="p-4">
          <h3 className="text-sm font-medium text-[#F0F2F7] mb-4">2FA Durumu</h3>
          <div className="h-32 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={[{ name: "Aktif", value: 28 }, { name: "Pasif", value: 72 }]}
                  cx="50%"
                  cy="50%"
                  innerRadius={35}
                  outerRadius={50}
                  dataKey="value"
                >
                  <Cell fill="#00D4AA" />
                  <Cell fill="rgba(255,255,255,0.1)" />
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-4 text-xs">
            <span className="text-[#00D4AA]">%28 Aktif</span>
            <span className="text-[#8892A4]">%72 Pasif</span>
          </div>
          <button className="w-full mt-4 px-3 py-2 text-sm bg-[#FF4757] text-white rounded-lg">2FA Zorunlu Kil</button>
        </GlassCard>
      </div>

      {/* IP Blacklist */}
      <GlassCard className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-medium text-[#F0F2F7]">Supheli Aktivite</h3>
          <button className="px-3 py-1.5 text-sm bg-[#FF4757] text-white rounded-lg">IP Engelle</button>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b border-[rgba(255,255,255,0.06)]">
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">IP</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Ulke</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Deneme</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Risk</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Aksiyon</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b border-[rgba(255,255,255,0.06)]">
              <td className="p-3 font-mono text-sm text-[#F0F2F7]">95.134.12.89</td>
              <td className="p-3 text-sm text-[#8892A4]">Rusya</td>
              <td className="p-3 text-sm text-[#FF4757]">847</td>
              <td className="p-3"><span className="px-2 py-1 text-xs bg-[rgba(255,71,87,0.2)] text-[#FF4757] rounded">YUKSEK</span></td>
              <td className="p-3">
                <button className="px-2 py-1 text-xs bg-[#FF4757] text-white rounded">Engelle</button>
              </td>
            </tr>
            <tr className="border-b border-[rgba(255,255,255,0.06)]">
              <td className="p-3 font-mono text-sm text-[#F0F2F7]">103.21.x.x</td>
              <td className="p-3 text-sm text-[#8892A4]">Cin</td>
              <td className="p-3 text-sm text-[#FFB833]">234</td>
              <td className="p-3"><span className="px-2 py-1 text-xs bg-[rgba(255,184,51,0.2)] text-[#FFB833] rounded">ORTA</span></td>
              <td className="p-3">
                <button className="px-2 py-1 text-xs bg-[#FF4757] text-white rounded">Engelle</button>
              </td>
            </tr>
          </tbody>
        </table>
      </GlassCard>
    </div>
  )
}

// Admin Settings Tab Component
function AdminSettingsTab() {
  const [maintenanceMode, setMaintenanceMode] = useState(false)
  
  return (
    <div className="space-y-6">
      {/* Platform Settings */}
      <GlassCard className="p-4">
        <h3 className="text-sm font-medium text-[#F0F2F7] mb-4">Platform Ayarlari</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs text-[#8892A4] mb-1 block">Platform Adi</label>
            <input type="text" defaultValue="FinOS" className="w-full px-3 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#F0F2F7]" />
          </div>
          <div>
            <label className="text-xs text-[#8892A4] mb-1 block">Tagline</label>
            <input type="text" defaultValue="Kisisel Finansal Isletim Sistemi" className="w-full px-3 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#F0F2F7]" />
          </div>
        </div>
      </GlassCard>

      {/* Integrations */}
      <GlassCard className="p-4">
        <h3 className="text-sm font-medium text-[#F0F2F7] mb-4">Entegrasyonlar</h3>
        <div className="grid grid-cols-3 gap-4">
          {[
            { name: "Stripe", connected: true, detail: "Son islem: 14:21" },
            { name: "Resend", connected: true, detail: "Email servisi" },
            { name: "Google Analytics", connected: false, detail: "" },
            { name: "Slack", connected: false, detail: "" },
            { name: "Intercom", connected: false, detail: "" },
          ].map((int, i) => (
            <div key={i} className="p-3 bg-[#151A23] rounded-lg border border-[rgba(255,255,255,0.06)]">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-[#F0F2F7]">{int.name}</span>
                <span className={`w-2 h-2 rounded-full ${int.connected ? "bg-[#00D4AA]" : "bg-[#8892A4]"}`} />
              </div>
              {int.connected ? (
                <p className="text-xs text-[#8892A4]">{int.detail}</p>
              ) : (
                <button className="text-xs text-[#FF4757]">Bagla</button>
              )}
            </div>
          ))}
        </div>
      </GlassCard>

      {/* Backup */}
      <GlassCard className="p-4">
        <h3 className="text-sm font-medium text-[#F0F2F7] mb-4">Yedekleme</h3>
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-sm text-[#F0F2F7]">Son basarili yedek</p>
            <p className="text-xs text-[#8892A4]">Bugun 02:00 — 2.3 GB</p>
          </div>
          <button className="px-4 py-2 bg-[#FF4757] text-white text-sm rounded-lg">Manuel Yedek Al</button>
        </div>
        <div className="flex gap-4 text-xs text-[#8892A4]">
          <span>Gunluk 02:00</span>
          <span>Haftalik Pazar</span>
          <span>Aylik 1.</span>
        </div>
      </GlassCard>

      {/* Maintenance Mode */}
      <GlassCard className={`p-4 ${maintenanceMode ? "border-[#FF4757] border-2" : ""}`}>
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-medium text-[#F0F2F7]">Bakim Modu</h3>
            <p className="text-xs text-[#8892A4]">Aktif edildiginde kullanicilar siteye erisemez</p>
          </div>
          <button
            onClick={() => setMaintenanceMode(!maintenanceMode)}
            className={`relative w-12 h-6 rounded-full transition-colors ${maintenanceMode ? "bg-[#FF4757]" : "bg-[rgba(255,255,255,0.1)]"}`}
          >
            <span className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${maintenanceMode ? "left-7" : "left-1"}`} />
          </button>
        </div>
        {maintenanceMode && (
          <div className="mt-4 p-3 bg-[rgba(255,71,87,0.1)] rounded-lg">
            <p className="text-sm text-[#FF4757] font-medium">BAKIM MODU AKTIF</p>
          </div>
        )}
      </GlassCard>

      {/* Danger Zone */}
      <GlassCard className="p-4 border-[#FF4757] border">
        <h3 className="text-sm font-medium text-[#FF4757] mb-4 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4" /> Tehlikeli Bolge
        </h3>
        <div className="flex gap-4">
          <button className="px-4 py-2 text-sm border border-[#FF4757] text-[#FF4757] rounded-lg hover:bg-[rgba(255,71,87,0.1)]">
            Tum Verileri Sifirla
          </button>
          <button className="px-4 py-2 text-sm border border-[#FF4757] text-[#FF4757] rounded-lg hover:bg-[rgba(255,71,87,0.1)]">
            Test Verisi Yukle
          </button>
        </div>
      </GlassCard>
    </div>
  )
}

// Support Tab Component
function SupportTab({ tickets, requests }: { tickets: typeof mockTickets; requests: typeof mockFeatureRequests }) {
  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-5 gap-4">
        <GlassCard className="p-4">
          <p className="text-xs text-[#8892A4]">Acik Talepler</p>
          <p className="text-2xl font-mono text-[#FFB833]">12</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs text-[#8892A4]">Bu Hafta Cozulen</p>
          <p className="text-2xl font-mono text-[#00D4AA]">47</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs text-[#8892A4]">Ort. Yanit Suresi</p>
          <p className="text-2xl font-mono text-[#F0F2F7]">2.3 saat</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs text-[#8892A4]">Memnuniyet</p>
          <p className="text-2xl font-mono text-[#FFB833]">4.6/5</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs text-[#8892A4]">SLA Uyumu</p>
          <p className="text-2xl font-mono text-[#00D4AA]">%94</p>
        </GlassCard>
      </div>

      {/* Tickets */}
      <GlassCard className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-medium text-[#F0F2F7]">Destek Talepleri</h3>
          <div className="flex gap-2">
            {["Tumu", "Acik", "Beklemede", "Cozuldu"].map((filter, i) => (
              <button
                key={filter}
                className={`px-3 py-1 text-xs rounded ${i === 0 ? "bg-[#FF4757] text-white" : "text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)]"}`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b border-[rgba(255,255,255,0.06)]">
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">ID</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Kullanici</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Konu</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Oncelik</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Durum</th>
              <th className="p-3 text-left text-xs font-medium text-[#8892A4]">Islem</th>
            </tr>
          </thead>
          <tbody>
            {tickets.map((ticket) => (
              <tr key={ticket.id} className="border-b border-[rgba(255,255,255,0.06)]">
                <td className="p-3 text-sm text-[#8892A4]">#{ticket.id}</td>
                <td className="p-3">
                  <span className="text-sm text-[#F0F2F7]">{ticket.user}</span>
                  <span className={`ml-2 px-1.5 py-0.5 text-[10px] rounded ${
                    ticket.plan === "Premium" ? "bg-[rgba(167,139,250,0.2)] text-[#A78BFA]" :
                    ticket.plan === "Pro" ? "bg-[rgba(255,184,51,0.2)] text-[#FFB833]" :
                    "bg-[rgba(255,255,255,0.06)] text-[#8892A4]"
                  }`}>{ticket.plan}</span>
                </td>
                <td className="p-3 text-sm text-[#F0F2F7]">{ticket.subject}</td>
                <td className="p-3">
                  <span className={`text-sm ${
                    ticket.priority === "high" ? "text-[#FF4757]" :
                    ticket.priority === "medium" ? "text-[#FFB833]" :
                    "text-[#00D4AA]"
                  }`}>
                    {ticket.priority === "high" ? "Yuksek" : ticket.priority === "medium" ? "Orta" : "Dusuk"}
                  </span>
                </td>
                <td className="p-3">
                  <span className={`px-2 py-1 text-xs rounded ${
                    ticket.status === "open" ? "bg-[rgba(255,71,87,0.2)] text-[#FF4757]" :
                    "bg-[rgba(255,184,51,0.2)] text-[#FFB833]"
                  }`}>
                    {ticket.status === "open" ? "Acik" : "Beklemede"}
                  </span>
                </td>
                <td className="p-3">
                  <button className="px-3 py-1 text-xs bg-[#FF4757] text-white rounded">Ac</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </GlassCard>

      {/* Feature Requests */}
      <GlassCard className="p-4">
        <h3 className="text-sm font-medium text-[#F0F2F7] mb-4">Ozellik Istekleri</h3>
        <div className="grid grid-cols-2 gap-4">
          {requests.map((req, i) => (
            <div key={i} className="p-4 bg-[#151A23] rounded-lg border border-[rgba(255,255,255,0.06)]">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-[#F0F2F7]">{req.title}</span>
                <span className={`px-2 py-1 text-xs rounded ${
                  req.status === "planned" ? "bg-[rgba(255,184,51,0.2)] text-[#FFB833]" :
                  req.status === "inprogress" ? "bg-[rgba(75,158,255,0.2)] text-[#4B9EFF]" :
                  req.status === "review" ? "bg-[rgba(167,139,250,0.2)] text-[#A78BFA]" :
                  "bg-[rgba(255,255,255,0.06)] text-[#8892A4]"
                }`}>
                  {req.status === "planned" ? "Planlandi" :
                   req.status === "inprogress" ? "Yapiliyor" :
                   req.status === "review" ? "Degerlendirilir" :
                   "Backlog"}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <ThumbsUp className="w-4 h-4 text-[#00D4AA]" />
                <span className="text-sm font-mono text-[#00D4AA]">{req.votes} oy</span>
              </div>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  )
}
