"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { formatCurrency } from "@/components/ui/finos-components"
import { 
  CreditCard, 
  Car,
  User,
  Building2,
  TrendingDown,
  Calendar,
  Percent,
  Target,
  Zap,
  Sparkles,
  Snowflake,
  Mountain,
  Plus,
  Clock,
  CheckCircle2,
} from "lucide-react"

// Debt data based on YAML spec
const debts = [
  {
    id: 1,
    name: "Garanti Kredi Kartı",
    type: "credit",
    icon: CreditCard,
    total: 24000,
    remaining: 24000,
    paid: 0,
    interestRate: 4.5,
    monthlyPayment: 1200,
    dueDay: 12,
    daysLeft: 8,
    payoffMonths: 28,
    bankLogo: "🏦",
  },
  {
    id: 2,
    name: "Taşıt Kredisi",
    type: "auto",
    icon: Car,
    total: 250000,
    remaining: 180000,
    paid: 70000,
    interestRate: 1.89,
    monthlyPayment: 3800,
    dueDay: 15,
    daysLeft: 11,
    endDate: "Haziran 2028",
    bankLogo: "🚗",
  },
  {
    id: 3,
    name: "Arkadaş Borcu",
    type: "personal",
    icon: User,
    total: 5000,
    remaining: 5000,
    paid: 0,
    interestRate: 0,
    monthlyPayment: 0,
    note: "Mehmet Yılmaz'a borçlu",
    bankLogo: "👤",
  },
  {
    id: 4,
    name: "İhtiyaç Kredisi",
    type: "loan",
    icon: Building2,
    total: 100000,
    remaining: 75000,
    paid: 25000,
    interestRate: 2.1,
    monthlyPayment: 2420,
    dueDay: 20,
    daysLeft: 16,
    bankLogo: "🏛️",
  },
]

const typeColors: Record<string, string> = {
  credit: "#FF4757",
  auto: "#A78BFA",
  personal: "#4B9EFF",
  loan: "#FFB833",
}

export default function DebtsPage() {
  const [strategy, setStrategy] = useState<"avalanche" | "snowball">("avalanche")
  
  const totalDebt = debts.reduce((sum, d) => sum + d.remaining, 0)
  const thisMonthPayment = debts.reduce((sum, d) => sum + d.monthlyPayment, 0)
  const avgInterest = debts.filter(d => d.interestRate > 0).reduce((sum, d) => sum + d.interestRate, 0) / debts.filter(d => d.interestRate > 0).length

  // Avalanche: sort by interest rate descending
  // Snowball: sort by remaining amount ascending
  const sortedDebts = strategy === "avalanche" 
    ? [...debts].sort((a, b) => b.interestRate - a.interestRate)
    : [...debts].sort((a, b) => a.remaining - b.remaining)

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-semibold text-[#F0F2F7]">Borç Yönetimi</h1>
          <p className="text-sm text-[#8892A4]">Borçlarınızı takip edin ve ödeme stratejinizi belirleyin</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-[#00D4AA] rounded-lg text-sm font-medium text-[#080A0F] hover:bg-[#00D4AA]/90 transition-colors">
          <Plus className="w-4 h-4" />
          Borç Ekle
        </button>
      </div>

      {/* Top Stats */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="finos-card p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-[rgba(255,71,87,0.1)] flex items-center justify-center">
              <TrendingDown className="w-5 h-5 text-[#FF4757]" />
            </div>
            <span className="text-sm text-[#8892A4]">Toplam Borç</span>
          </div>
          <p className="text-2xl font-semibold font-mono text-[#FF4757]">{formatCurrency(totalDebt)}</p>
        </div>

        <div className="finos-card p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-[rgba(255,184,51,0.1)] flex items-center justify-center">
              <Calendar className="w-5 h-5 text-[#FFB833]" />
            </div>
            <span className="text-sm text-[#8892A4]">Bu Ay Ödenecek</span>
          </div>
          <p className="text-2xl font-semibold font-mono text-[#FFB833]">{formatCurrency(thisMonthPayment)}</p>
        </div>

        <div className="finos-card p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-[rgba(167,139,250,0.1)] flex items-center justify-center">
              <Percent className="w-5 h-5 text-[#A78BFA]" />
            </div>
            <span className="text-sm text-[#8892A4]">Ortalama Faiz</span>
          </div>
          <p className="text-2xl font-semibold font-mono text-[#A78BFA]">%{avgInterest.toFixed(1)}/ay</p>
        </div>

        <div className="finos-card p-5">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-[rgba(0,212,170,0.1)] flex items-center justify-center">
              <Target className="w-5 h-5 text-[#00D4AA]" />
            </div>
            <span className="text-sm text-[#8892A4]">Borçsuz Tarih</span>
          </div>
          <p className="text-2xl font-semibold font-mono text-[#00D4AA]">Ağu 2027</p>
          <p className="text-xs text-[#4E5A6B] mt-1">tahmini</p>
        </div>
      </div>

      {/* Debt Cards */}
      <div className="space-y-4 mb-6">
        {debts.map((debt) => {
          const Icon = debt.icon
          const progress = ((debt.total - debt.remaining) / debt.total) * 100
          const color = typeColors[debt.type]
          
          return (
            <div 
              key={debt.id}
              className="finos-card p-5 hover:border-[rgba(255,255,255,0.1)] transition-all"
            >
              <div className="flex items-start justify-between">
                {/* Left Section */}
                <div className="flex items-start gap-4">
                  <div 
                    className="w-14 h-14 rounded-xl flex items-center justify-center text-2xl"
                    style={{ backgroundColor: `${color}15` }}
                  >
                    {debt.bankLogo}
                  </div>
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <h3 className="text-lg font-semibold text-[#F0F2F7]">{debt.name}</h3>
                      <span 
                        className="px-2 py-0.5 rounded text-xs font-medium"
                        style={{ backgroundColor: `${color}20`, color }}
                      >
                        {debt.type === "credit" ? "Kredi Kartı" : 
                         debt.type === "auto" ? "Taşıt Kredisi" : 
                         debt.type === "personal" ? "Kişisel Borç" : "İhtiyaç Kredisi"}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-6 mt-3">
                      {debt.interestRate > 0 && (
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-[#8892A4]">Faiz:</span>
                          <span className="px-2 py-0.5 rounded bg-[rgba(255,71,87,0.15)] text-[#FF4757] text-xs font-mono font-medium">
                            %{debt.interestRate}/ay
                          </span>
                        </div>
                      )}
                      
                      {debt.monthlyPayment > 0 && (
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-[#8892A4]">Aylık Ödeme:</span>
                          <span className="text-sm font-mono text-[#F0F2F7]">{formatCurrency(debt.monthlyPayment)}</span>
                        </div>
                      )}
                      
                      {debt.dueDay && (
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-[#8892A4]">Vade:</span>
                          <span className="text-sm text-[#F0F2F7]">Her ayın {debt.dueDay}&apos;si</span>
                          {debt.daysLeft && (
                            <span className="px-2 py-0.5 rounded bg-[rgba(255,184,51,0.15)] text-[#FFB833] text-xs font-medium flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {debt.daysLeft} gün kaldı
                            </span>
                          )}
                        </div>
                      )}
                      
                      {debt.note && (
                        <span className="text-sm text-[#8892A4] italic">{debt.note}</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right Section - Amount */}
                <div className="text-right">
                  <p className="text-2xl font-bold font-mono text-[#FF4757]">
                    {formatCurrency(debt.remaining)}
                  </p>
                  <p className="text-xs text-[#4E5A6B]">kaldı</p>
                  {debt.total !== debt.remaining && (
                    <p className="text-sm text-[#8892A4] mt-1">
                      Toplam: {formatCurrency(debt.total)}
                    </p>
                  )}
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mt-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-[#4E5A6B]">Ödenen</span>
                  <span className="text-xs font-mono text-[#8892A4]">{progress.toFixed(0)}%</span>
                </div>
                <div className="h-2 bg-[#151A23] rounded-full overflow-hidden">
                  <div 
                    className="h-full rounded-full transition-all"
                    style={{ 
                      width: `${Math.max(progress, 2)}%`,
                      backgroundColor: progress > 0 ? '#00D4AA' : color
                    }}
                  />
                </div>
                
                {debt.payoffMonths && (
                  <p className="text-xs text-[#8892A4] mt-2">
                    Bu tek borç <span className="text-[#FFB833] font-medium">{debt.payoffMonths} ay</span> sürer
                  </p>
                )}
                
                {debt.endDate && (
                  <p className="text-xs text-[#8892A4] mt-2">
                    <span className="text-[#00D4AA] font-medium">{debt.endDate}</span>&apos;de bitiyor
                  </p>
                )}
              </div>
            </div>
          )
        })}
      </div>

      {/* Borçtan Çıkış Motoru */}
      <div className="finos-card p-6 border-l-4 border-[#00D4AA]">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-[rgba(0,212,170,0.15)] flex items-center justify-center">
            <Zap className="w-5 h-5 text-[#00D4AA]" />
          </div>
          <h2 className="text-xl font-semibold text-[#F0F2F7]">Borçtan Çıkış Motoru</h2>
        </div>

        {/* Strategy Tabs */}
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setStrategy("snowball")}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
              strategy === "snowball"
                ? "bg-[#4B9EFF] text-white"
                : "bg-[#151A23] text-[#8892A4] hover:bg-[#1A1F29]"
            }`}
          >
            <Snowflake className="w-4 h-4" />
            Kartopu (Snowball)
          </button>
          <button
            onClick={() => setStrategy("avalanche")}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
              strategy === "avalanche"
                ? "bg-[#A78BFA] text-white"
                : "bg-[#151A23] text-[#8892A4] hover:bg-[#1A1F29]"
            }`}
          >
            <Mountain className="w-4 h-4" />
            Çığ (Avalanche)
          </button>
        </div>

        {/* Strategy Explanation */}
        <div className="finos-card-inner p-4 mb-6">
          <p className="text-sm text-[#8892A4]">
            {strategy === "avalanche" 
              ? "En yüksek faizli borçtan başla — toplam faiz tasarrufu maximize et"
              : "En küçük borçtan başla — motivasyon için hızlı kazançlar elde et"
            }
          </p>
        </div>

        {/* Monthly Plan Table */}
        <div className="mb-6">
          <h3 className="text-sm font-medium text-[#F0F2F7] mb-3">Aylık Ödeme Planı</h3>
          <div className="space-y-2">
            {strategy === "avalanche" ? (
              <>
                <div className="flex items-center gap-4 p-3 rounded-lg bg-[#151A23]">
                  <div className="w-20 text-xs font-mono text-[#4E5A6B]">Ay 1-8</div>
                  <div className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-[#FF4757]" />
                    <span className="text-sm text-[#F0F2F7]">Garanti Kredi Kartı&apos;na fokus</span>
                  </div>
                  <span className="ml-auto px-2 py-0.5 rounded bg-[rgba(255,71,87,0.15)] text-[#FF4757] text-xs">%4.5 faiz</span>
                </div>
                <div className="flex items-center gap-4 p-3 rounded-lg bg-[#151A23]">
                  <div className="w-20 text-xs font-mono text-[#4E5A6B]">Ay 9-32</div>
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-[#FFB833]" />
                    <span className="text-sm text-[#F0F2F7]">İhtiyaç Kredisi&apos;ne fokus</span>
                  </div>
                  <span className="ml-auto px-2 py-0.5 rounded bg-[rgba(255,184,51,0.15)] text-[#FFB833] text-xs">%2.1 faiz</span>
                </div>
                <div className="flex items-center gap-4 p-3 rounded-lg bg-[#151A23]">
                  <div className="w-20 text-xs font-mono text-[#4E5A6B]">Ay 33+</div>
                  <div className="flex items-center gap-2">
                    <Car className="w-4 h-4 text-[#A78BFA]" />
                    <span className="text-sm text-[#F0F2F7]">Taşıt Kredisi&apos;ne fokus</span>
                  </div>
                  <span className="ml-auto px-2 py-0.5 rounded bg-[rgba(167,139,250,0.15)] text-[#A78BFA] text-xs">%1.89 faiz</span>
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center gap-4 p-3 rounded-lg bg-[#151A23]">
                  <div className="w-20 text-xs font-mono text-[#4E5A6B]">Ay 1-3</div>
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-[#4B9EFF]" />
                    <span className="text-sm text-[#F0F2F7]">Arkadaş Borcu&apos;nu kapat</span>
                  </div>
                  <span className="ml-auto px-2 py-0.5 rounded bg-[rgba(75,158,255,0.15)] text-[#4B9EFF] text-xs">₺5.000</span>
                </div>
                <div className="flex items-center gap-4 p-3 rounded-lg bg-[#151A23]">
                  <div className="w-20 text-xs font-mono text-[#4E5A6B]">Ay 4-12</div>
                  <div className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-[#FF4757]" />
                    <span className="text-sm text-[#F0F2F7]">Garanti Kredi Kartı&apos;na fokus</span>
                  </div>
                  <span className="ml-auto px-2 py-0.5 rounded bg-[rgba(255,71,87,0.15)] text-[#FF4757] text-xs">₺24.000</span>
                </div>
                <div className="flex items-center gap-4 p-3 rounded-lg bg-[#151A23]">
                  <div className="w-20 text-xs font-mono text-[#4E5A6B]">Ay 13+</div>
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-[#FFB833]" />
                    <span className="text-sm text-[#F0F2F7]">Diğer kredilere fokus</span>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Savings Comparison */}
        <div className="finos-card-inner p-4 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Snowflake className="w-4 h-4 text-[#4B9EFF]" />
                <span className="text-sm text-[#8892A4]">Kartopu:</span>
                <span className="text-sm font-mono text-[#F0F2F7]">34 ay</span>
              </div>
              <div className="flex items-center gap-2">
                <Mountain className="w-4 h-4 text-[#A78BFA]" />
                <span className="text-sm text-[#8892A4]">Çığ:</span>
                <span className="text-sm font-mono text-[#F0F2F7]">30 ay</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#00D4AA]" />
              <span className="text-sm text-[#00D4AA] font-medium">
                4 ay erken + ₺12.400 faiz tasarrufu
              </span>
            </div>
          </div>
        </div>

        {/* AI Insight */}
        <div className="finos-card-inner p-4 border-l-4 border-[#A78BFA] mb-6">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-[rgba(167,139,250,0.15)] flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4 text-[#A78BFA]" />
            </div>
            <div>
              <p className="text-xs text-[#A78BFA] font-medium mb-1">AI İçgörü</p>
              <p className="text-sm text-[#8892A4]">
                Önce Garanti kredi kartını kapatırsan toplam <span className="text-[#00D4AA] font-medium">14 ay erken</span> borçsuz olursun 
                ve <span className="text-[#00D4AA] font-medium">₺12.400</span> faiz ödemezsin.
              </p>
            </div>
          </div>
        </div>

        {/* Apply Plan Button */}
        <button className="w-full py-3 bg-[#00D4AA] rounded-lg text-sm font-medium text-[#080A0F] hover:bg-[#00D4AA]/90 transition-colors">
          Planı Uygula
        </button>
      </div>
    </DashboardLayout>
  )
}
