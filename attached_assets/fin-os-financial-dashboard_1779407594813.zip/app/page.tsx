"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { 
  portfolioSummary, 
  riskMetrics, 
  assetAllocation, 
  balancePerformance, 
  holdings, 
  portfolioHealthScore,
  insightMessages 
} from "@/lib/mock-data"
import { 
  Eye, 
  EyeOff, 
  RefreshCw, 
  Plus, 
  TrendingUp, 
  Bitcoin, 
  Flame,
  Zap,
  AlertTriangle,
  Info,
  Lightbulb,
  Search,
  Edit2,
  Trash2,
  Package
} from "lucide-react"
import { useState } from "react"
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

type TabType = "Tümü" | "Hisse Senedi" | "Kripto" | "ETF" | "Madeni Para"
type PeriodType = "Günlük" | "Haftalık" | "Aylık"

export default function PortfolioPage() {
  const [showNumbers, setShowNumbers] = useState(true)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [activeTab, setActiveTab] = useState<TabType>("Tümü")
  const [activePeriod, setActivePeriod] = useState<PeriodType>("Aylık")
  const [searchQuery, setSearchQuery] = useState("")

  const handleRefresh = () => {
    setIsRefreshing(true)
    setTimeout(() => setIsRefreshing(false), 2000)
  }

  const formatCurrency = (value: number, currency: string = "TRY") => {
    if (!showNumbers) return "••••••"
    return new Intl.NumberFormat('tr-TR', {
      style: 'currency',
      currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value).replace(currency === "TRY" ? "₺" : "$", currency === "TRY" ? "₺" : "$")
  }

  const formatNumber = (value: number, decimals: number = 2) => {
    if (!showNumbers) return "••••"
    return new Intl.NumberFormat('tr-TR', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(value)
  }

  const tabs: TabType[] = ["Tümü", "Hisse Senedi", "Kripto", "ETF", "Madeni Para"]
  const periods: PeriodType[] = ["Günlük", "Haftalık", "Aylık"]

  const filteredHoldings = holdings.filter(h => {
    if (activeTab === "Tümü") return true
    if (activeTab === "Kripto") return h.type === "Kripto"
    return false
  }).filter(h => {
    if (!searchQuery) return true
    return h.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
           h.symbol.toLowerCase().includes(searchQuery.toLowerCase())
  })

  return (
    <DashboardLayout>
      {/* Top Bar */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <h1 className="text-[28px] font-semibold text-[#F0F2F7]">Portföyüm</h1>
          <button 
            onClick={() => setShowNumbers(!showNumbers)}
            className="p-2 rounded-lg hover:bg-[rgba(255,255,255,0.04)] transition-colors"
          >
            {showNumbers ? (
              <Eye className="w-5 h-5 text-[#8892A4]" />
            ) : (
              <EyeOff className="w-5 h-5 text-[#8892A4]" />
            )}
          </button>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={handleRefresh}
            className="flex items-center gap-2 px-4 py-2 text-sm text-[#8892A4] hover:text-[#F0F2F7] hover:bg-[rgba(255,255,255,0.04)] rounded-lg transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            Fiyatları Güncelle
          </button>
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium bg-[#00D4AA] text-[#080A0F] rounded-lg hover:bg-[#00C49A] transition-colors">
            <Plus className="w-4 h-4" />
            Varlık Ekle
          </button>
        </div>
      </div>

      {/* Top Stats Row - 3 Cards */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {/* Net Varlık Card */}
        <div className="finos-card p-5 border-l-[3px] border-l-[#00D4AA] relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-[rgba(0,212,170,0.05)] to-transparent pointer-events-none" />
          <div className="relative">
            <p className="text-[11px] uppercase tracking-widest text-[#4E5A6B] mb-2">NET VARLIK</p>
            <p className="text-[42px] font-mono font-semibold text-[#F0F2F7] leading-none mb-2">
              {showNumbers ? "₺3.891.094,61" : "••••••••"}
            </p>
            <div className="flex items-center gap-2 text-[#00D4AA] mb-4">
              <TrendingUp className="w-4 h-4" />
              <span className="text-sm font-mono">+₺116.633 toplam</span>
            </div>
            <div className="flex items-center gap-4 text-xs text-[#8892A4]">
              <span>Toplam ROI: <span className="text-[#00D4AA] font-mono">+%{formatNumber(portfolioSummary.totalROI)}</span></span>
              <span className="text-[#4E5A6B]">|</span>
              <span>Toplam Varlık: <span className="font-mono">{showNumbers ? "₺3.891.094" : "••••"}</span></span>
              <span className="text-[#4E5A6B]">|</span>
              <span>Toplam Borç: <span className="font-mono">₺0</span></span>
            </div>
          </div>
        </div>

        {/* Günlük PNL Card */}
        <div className="finos-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <p className="text-[11px] uppercase tracking-widest text-[#4E5A6B]">GÜNLÜK PNL</p>
            <TrendingUp className="w-4 h-4 text-[#00D4AA]" />
          </div>
          <p className="text-[36px] font-mono font-semibold text-[#00D4AA] leading-none mb-1">
            {showNumbers ? "+₺0,00" : "••••"}
          </p>
          <p className="text-sm text-[#8892A4] mb-3">+%0.00 ortalama</p>
          <p className="text-xs text-[#4E5A6B]">Hisse/ETF varlığı bulunamadı</p>
        </div>

        {/* Kripto PNL Card */}
        <div className="finos-card p-5">
          <div className="flex items-center gap-2 mb-2">
            <p className="text-[11px] uppercase tracking-widest text-[#4E5A6B]">KRİPTO PNL</p>
            <Bitcoin className="w-4 h-4 text-[#FFB833]" />
          </div>
          <p className="text-[36px] font-mono font-semibold text-[#00D4AA] leading-none mb-1">
            {showNumbers ? "+₺116.633,08" : "••••"}
          </p>
          <p className="text-sm text-[#8892A4] mb-3">+%3.09 ortalama</p>
          <p className="text-xs text-[#4E5A6B]">En iyi performans: <span className="text-[#00D4AA]">BTC +%3.09</span></p>
        </div>
      </div>

      {/* Risk Banner */}
      <div className="finos-card p-4 mb-4 bg-[rgba(255,71,87,0.05)] border-[rgba(255,71,87,0.2)]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <Flame className="w-5 h-5 text-[#FF4757]" />
              <span className="text-[11px] uppercase tracking-widest text-[#8892A4]">RİSK SEVİYESİ</span>
              <span className="text-sm font-semibold text-[#FF4757]">{riskMetrics.level}</span>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-xs text-[#8892A4]">Risk Skoru:</span>
              <span className="text-sm font-mono font-semibold text-[#FF4757]">{riskMetrics.score}/{riskMetrics.maxScore}</span>
              <div className="flex items-center gap-0.5">
                {Array.from({ length: 10 }).map((_, i) => (
                  <div 
                    key={i} 
                    className="risk-dash"
                    style={{ backgroundColor: i < riskMetrics.score ? '#FF4757' : '#1a1f2a' }}
                  />
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-[#8892A4]">Kripto Ağırlığı:</span>
              <span className="px-2 py-0.5 text-xs font-mono font-semibold text-[#FF4757] bg-[rgba(255,71,87,0.15)] rounded">
                %{riskMetrics.cryptoWeight}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-[#8892A4]">Volatilite:</span>
              <span className="text-sm font-mono text-[#F0F2F7]">{riskMetrics.volatility}%</span>
              <span className="text-xs text-[#4E5A6B]">Ortalama değişim</span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-[#8892A4]">Konsantrasyon:</span>
              <span className="text-sm font-mono text-[#F0F2F7]">%{riskMetrics.concentration}</span>
              <span className="text-xs text-[#4E5A6B]">En büyük pozisyon</span>
            </div>
          </div>

          <div className="flex items-center gap-2 text-[#FF4757]">
            <Flame className="w-4 h-4" />
            <span className="text-sm font-medium">Yüksek risk profili</span>
          </div>
        </div>
      </div>

      {/* Insight Ticker */}
      <div className="bg-[#0A0C12] border-y border-[rgba(255,255,255,0.06)] py-3 mb-6 overflow-hidden">
        <div className="flex items-center gap-4">
          <div className="flex-shrink-0 px-3 py-1 bg-[#00D4AA] rounded-full flex items-center gap-1.5 ml-4">
            <Zap className="w-3 h-3 text-[#080A0F]" />
            <span className="text-xs font-semibold text-[#080A0F]">INSIGHT</span>
          </div>
          <div className="flex-1 overflow-hidden">
            <div className="flex items-center gap-8 animate-marquee whitespace-nowrap">
              {[...insightMessages, ...insightMessages].map((msg, i) => (
                <span key={i} className="text-sm text-[#8892A4]">
                  {msg} <span className="text-[#4E5A6B] mx-2">•</span>
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Two Column Section */}
      <div className="grid grid-cols-2 gap-6 mb-6">
        {/* Varlık Dağılımı */}
        <div className="finos-card p-5">
          <h2 className="text-xl font-semibold text-[#F0F2F7] mb-4">Varlık Dağılımı</h2>
          <div className="flex items-center gap-6">
            <div className="relative w-[180px] h-[180px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={assetAllocation}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={85}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {assetAllocation.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0E1117',
                      border: '1px solid rgba(255,255,255,0.1)',
                      borderRadius: '8px',
                      color: '#F0F2F7',
                    }}
                    formatter={(value: number) => [`%${value}`, "Oran"]}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-2xl font-semibold text-[#F0F2F7]">%100</span>
              </div>
            </div>
            <div className="flex-1 space-y-3">
              {assetAllocation.map((asset) => (
                <div key={asset.name} className="flex items-center gap-3">
                  <div 
                    className="w-3 h-3 rounded-sm" 
                    style={{ backgroundColor: asset.color }}
                  />
                  <span className="text-sm text-[#8892A4]">{asset.name}</span>
                  <span className="text-sm font-mono text-[#F0F2F7] ml-auto">(%{asset.value})</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bütçe Bakiyesi Performansı */}
        <div className="finos-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-[#F0F2F7]">Bütçe Bakiyesi Performansı</h2>
            <div className="flex items-center gap-2">
              <span className="text-sm text-[#8892A4]">Toplam Bakiye:</span>
              <span className="text-sm font-mono font-semibold text-[#00D4AA]">
                {showNumbers ? "₺123.633" : "••••"}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2 mb-4">
            {periods.map((period) => (
              <button
                key={period}
                onClick={() => setActivePeriod(period)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  activePeriod === period
                    ? "bg-[#00D4AA] text-[#080A0F]"
                    : "text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)]"
                }`}
              >
                {period}
              </button>
            ))}
          </div>
          <div className="h-[160px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={balancePerformance}>
                <defs>
                  <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00D4AA" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#00D4AA" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis 
                  dataKey="month" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#4E5A6B', fontSize: 11 }}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#4E5A6B', fontSize: 11 }}
                  tickFormatter={(value) => value === 0 ? '0' : `${(value / 1000).toFixed(0)}K`}
                  domain={[0, 140000]}
                  ticks={[0, 35000, 70000, 105000, 140000]}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0E1117',
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '8px',
                    color: '#F0F2F7',
                  }}
                  formatter={(value: number) => [`₺${value.toLocaleString('tr-TR')}`, "Bakiye"]}
                />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke="#00D4AA"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorBalance)"
                  dot={{ fill: '#00D4AA', strokeWidth: 0, r: 3 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Varlıklarım Section */}
      <div className="finos-card mb-6 overflow-hidden">
        <div className="p-5 border-b border-[rgba(255,255,255,0.06)]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h2 className="text-xl font-semibold text-[#F0F2F7]">Varlıklarım</h2>
              <div className="flex items-center gap-1">
                {tabs.map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                      activeTab === tab
                        ? "bg-[rgba(255,255,255,0.08)] text-[#F0F2F7]"
                        : "text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)]"
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#4E5A6B]" />
              <input
                type="text"
                placeholder="Varlık adı, sembol..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-64 pl-10 pr-4 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#F0F2F7] placeholder:text-[#4E5A6B] focus:outline-none focus:border-[#00D4AA] transition-colors"
              />
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[rgba(255,255,255,0.06)]">
                <th className="text-left p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Varlık</th>
                <th className="text-left p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Tip</th>
                <th className="text-left p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Borsa</th>
                <th className="text-right p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Miktar</th>
                <th className="text-right p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Ort. Fiyat</th>
                <th className="text-right p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Güncel Fiyat</th>
                <th className="text-right p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Toplam Değer</th>
                <th className="text-right p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Değişim</th>
                <th className="text-right p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Kar/Zarar</th>
                <th className="text-right p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">İşlemler</th>
              </tr>
            </thead>
            <tbody>
              {filteredHoldings.length > 0 ? (
                filteredHoldings.map((holding) => (
                  <tr 
                    key={holding.symbol}
                    className="border-b border-[rgba(255,255,255,0.03)] hover:bg-[rgba(255,255,255,0.03)] transition-colors"
                  >
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-[#FFB833] flex items-center justify-center">
                          <Bitcoin className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-[#F0F2F7]">{holding.name}</p>
                          <p className="text-xs text-[#4E5A6B]">{holding.symbol} · {holding.avgCostCurrency}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="px-2 py-1 text-xs font-medium bg-[rgba(75,158,255,0.15)] text-[#4B9EFF] rounded">
                        {holding.type}
                      </span>
                    </td>
                    <td className="p-4 text-sm text-[#8892A4]">{holding.exchange}</td>
                    <td className="p-4 text-right">
                      <span className="text-sm font-mono text-[#F0F2F7]">{formatNumber(holding.quantity, 1)}</span>
                    </td>
                    <td className="p-4 text-right">
                      <span className="text-sm font-mono text-[#8892A4]">${formatNumber(holding.avgCost)}</span>
                    </td>
                    <td className="p-4 text-right">
                      <span className="text-sm font-mono text-[#F0F2F7]">${formatNumber(holding.currentPrice)}</span>
                    </td>
                    <td className="p-4 text-right">
                      <span className="text-sm font-mono font-medium text-[#F0F2F7]">
                        {showNumbers ? `₺${formatNumber(holding.totalValue)}` : "••••"}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <span className={`text-sm font-mono font-medium flex items-center justify-end gap-1 ${holding.change >= 0 ? 'text-[#00D4AA]' : 'text-[#FF4757]'}`}>
                        <TrendingUp className="w-3 h-3" />
                        +%{formatNumber(holding.change)}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <span className={`text-sm font-mono font-medium ${holding.pnl >= 0 ? 'text-[#00D4AA]' : 'text-[#FF4757]'}`}>
                        {showNumbers ? `+₺${formatNumber(holding.pnl)}` : "••••"}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button className="p-1.5 rounded-lg hover:bg-[rgba(255,255,255,0.06)] transition-colors">
                          <Edit2 className="w-4 h-4 text-[#8892A4]" />
                        </button>
                        <button className="p-1.5 rounded-lg hover:bg-[rgba(255,71,87,0.1)] transition-colors">
                          <Trash2 className="w-4 h-4 text-[#8892A4] hover:text-[#FF4757]" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={10} className="p-12 text-center">
                    <Package className="w-12 h-12 text-[#4E5A6B] mx-auto mb-3" />
                    <p className="text-sm text-[#4E5A6B]">Bu kategoride varlık bulunmamaktadır</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Portföy Sağlık Puanı */}
      <div className="finos-card p-6">
        <h2 className="text-xl font-semibold text-[#F0F2F7] mb-6">Portföy Sağlık Puanı</h2>
        <div className="flex items-start gap-8">
          {/* Circular Score */}
          <div className="flex flex-col items-center">
            <div className="relative w-32 h-32">
              <svg className="w-full h-full progress-ring" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  fill="none"
                  stroke="#151A23"
                  strokeWidth="8"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  fill="none"
                  stroke="#FFB833"
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={`${(portfolioHealthScore.overall / 100) * 283} 283`}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-semibold text-[#F0F2F7]">{portfolioHealthScore.overall}</span>
                <span className="text-sm text-[#4E5A6B]">/ {portfolioHealthScore.maxScore}</span>
              </div>
            </div>
          </div>

          {/* Sub-scores */}
          <div className="flex-1 space-y-4">
            {portfolioHealthScore.subscores.map((subscore) => (
              <div key={subscore.name} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-[#8892A4]">{subscore.name}</span>
                  <span className="text-sm font-mono text-[#F0F2F7]">{subscore.score}/{subscore.maxScore}</span>
                </div>
                <div className="h-2 bg-[#151A23] rounded-full overflow-hidden">
                  <div 
                    className="h-full rounded-full transition-all duration-500"
                    style={{ 
                      width: `${(subscore.score / subscore.maxScore) * 100}%`,
                      backgroundColor: subscore.color
                    }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Recommendations */}
          <div className="w-80 space-y-3">
            {portfolioHealthScore.recommendations.map((rec, idx) => (
              <div 
                key={idx}
                className="p-3 rounded-lg bg-[#151A23] border border-[rgba(255,255,255,0.06)]"
              >
                <div className="flex items-start gap-3">
                  {rec.type === 'warning' && <AlertTriangle className="w-4 h-4 text-[#FFB833] flex-shrink-0 mt-0.5" />}
                  {rec.type === 'info' && <Info className="w-4 h-4 text-[#4B9EFF] flex-shrink-0 mt-0.5" />}
                  {rec.type === 'tip' && <Lightbulb className="w-4 h-4 text-[#00D4AA] flex-shrink-0 mt-0.5" />}
                  <div>
                    <p className="text-sm font-medium text-[#F0F2F7]">{rec.title}</p>
                    <p className="text-xs text-[#8892A4] mt-0.5">{rec.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
