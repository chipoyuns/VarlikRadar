"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { formatCurrency, formatNumber } from "@/components/ui/finos-components"
import { simulatorScenarios, portfolioSummary } from "@/lib/mock-data"
import { 
  TrendingUp, 
  Calculator,
  Target,
  Clock,
  Play,
  Pause,
  RotateCcw,
} from "lucide-react"
import { useState, useEffect } from "react"
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer,
} from "recharts"

export default function SimulatorPage() {
  const [selectedScenario, setSelectedScenario] = useState(simulatorScenarios[1])
  const [years, setYears] = useState(20)
  const [monthlyContribution, setMonthlyContribution] = useState(10000)
  const [initialAmount, setInitialAmount] = useState(portfolioSummary.totalValue)
  const [isRunning, setIsRunning] = useState(false)
  const [currentYear, setCurrentYear] = useState(0)

  // Calculate projection
  const calculateProjection = () => {
    const data = []
    let value = initialAmount
    const monthlyRate = selectedScenario.annualReturn / 100 / 12

    for (let year = 0; year <= years; year++) {
      data.push({
        year: `${new Date().getFullYear() + year}`,
        value: Math.round(value),
        contributions: initialAmount + (monthlyContribution * 12 * year),
      })
      
      // Compound monthly for the year
      for (let month = 0; month < 12; month++) {
        value = value * (1 + monthlyRate) + monthlyContribution
      }
    }
    
    return data
  }

  const projectionData = calculateProjection()
  const finalValue = projectionData[projectionData.length - 1].value
  const totalContributions = initialAmount + (monthlyContribution * 12 * years)
  const totalGain = finalValue - totalContributions

  // Animation effect
  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isRunning && currentYear < years) {
      interval = setInterval(() => {
        setCurrentYear(prev => {
          if (prev >= years) {
            setIsRunning(false)
            return prev
          }
          return prev + 1
        })
      }, 200)
    }
    return () => clearInterval(interval)
  }, [isRunning, currentYear, years])

  const reset = () => {
    setCurrentYear(0)
    setIsRunning(false)
  }

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-semibold text-[#F0F2F7]">Simülatör</h1>
          <p className="text-sm text-[#8892A4]">Yatırım senaryolarını test edin</p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setIsRunning(!isRunning)}
            className="flex items-center gap-2 px-4 py-2 bg-[#00D4AA] rounded-lg text-sm font-medium text-[#080A0F] hover:bg-[#00D4AA]/90 transition-colors"
          >
            {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            {isRunning ? "Durdur" : "Başlat"}
          </button>
          <button 
            onClick={reset}
            className="p-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-[#8892A4] hover:text-[#F0F2F7] hover:border-[rgba(255,255,255,0.1)] transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-3 gap-6">
        {/* Controls */}
        <div className="space-y-4">
          {/* Scenario Selection */}
          <div className="finos-card p-5">
            <h3 className="text-sm font-medium text-[#8892A4] mb-3">Senaryo Seç</h3>
            <div className="space-y-2">
              {simulatorScenarios.map((scenario) => (
                <button
                  key={scenario.name}
                  onClick={() => setSelectedScenario(scenario)}
                  className={`w-full p-3 rounded-lg border text-left transition-all ${
                    selectedScenario.name === scenario.name
                      ? 'border-[#00D4AA] bg-[rgba(0,212,170,0.08)]'
                      : 'border-[rgba(255,255,255,0.06)] hover:border-[rgba(255,255,255,0.1)]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-[#F0F2F7]">{scenario.name}</span>
                    <span className={`text-xs px-2 py-0.5 rounded ${
                      scenario.risk === "Yüksek" 
                        ? 'bg-[rgba(255,71,87,0.1)] text-[#FF4757]'
                        : scenario.risk === "Orta"
                        ? 'bg-[rgba(255,184,51,0.1)] text-[#FFB833]'
                        : 'bg-[rgba(0,212,170,0.1)] text-[#00D4AA]'
                    }`}>
                      {scenario.risk} Risk
                    </span>
                  </div>
                  <p className="text-xs text-[#4E5A6B]">Yıllık getiri: %{scenario.annualReturn}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Parameters */}
          <div className="finos-card p-5">
            <h3 className="text-sm font-medium text-[#8892A4] mb-4">Parametreler</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-[#4E5A6B] mb-2">Başlangıç Tutarı</label>
                <input
                  type="text"
                  value={formatCurrency(initialAmount)}
                  onChange={(e) => {
                    const value = parseInt(e.target.value.replace(/[^0-9]/g, '')) || 0
                    setInitialAmount(value)
                  }}
                  className="w-full px-3 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm font-mono text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]"
                />
              </div>

              <div>
                <label className="block text-xs text-[#4E5A6B] mb-2">
                  Aylık Katkı: {formatCurrency(monthlyContribution)}
                </label>
                <input
                  type="range"
                  min="0"
                  max="50000"
                  step="1000"
                  value={monthlyContribution}
                  onChange={(e) => setMonthlyContribution(parseInt(e.target.value))}
                  className="w-full h-2 bg-[#151A23] rounded-lg appearance-none cursor-pointer accent-[#00D4AA]"
                />
              </div>

              <div>
                <label className="block text-xs text-[#4E5A6B] mb-2">
                  Süre: {years} yıl
                </label>
                <input
                  type="range"
                  min="5"
                  max="40"
                  value={years}
                  onChange={(e) => setYears(parseInt(e.target.value))}
                  className="w-full h-2 bg-[#151A23] rounded-lg appearance-none cursor-pointer accent-[#00D4AA]"
                />
              </div>
            </div>
          </div>

          {/* Allocation */}
          <div className="finos-card p-5">
            <h3 className="text-sm font-medium text-[#8892A4] mb-3">Varlık Dağılımı</h3>
            <div className="space-y-2">
              {Object.entries(selectedScenario.allocation).map(([key, value]) => (
                <div key={key} className="flex items-center justify-between">
                  <span className="text-sm text-[#8892A4] capitalize">
                    {key === "stock" ? "Hisse" : key === "crypto" ? "Kripto" : key === "bond" ? "Tahvil" : "Altın"}
                  </span>
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-2 bg-[#151A23] rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-[#00D4AA] rounded-full"
                        style={{ width: `${value}%` }}
                      />
                    </div>
                    <span className="text-xs font-mono text-[#F0F2F7] w-8">%{value}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Chart & Results */}
        <div className="col-span-2 space-y-4">
          {/* Results Summary */}
          <div className="grid grid-cols-4 gap-4">
            <div className="finos-card p-4">
              <div className="flex items-center gap-2 mb-2">
                <Calculator className="w-4 h-4 text-[#4B9EFF]" />
                <span className="text-xs text-[#4E5A6B]">Başlangıç</span>
              </div>
              <p className="text-lg font-semibold font-mono text-[#F0F2F7]">
                {formatCurrency(initialAmount)}
              </p>
            </div>
            <div className="finos-card p-4">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-4 h-4 text-[#A78BFA]" />
                <span className="text-xs text-[#4E5A6B]">Katkılar</span>
              </div>
              <p className="text-lg font-semibold font-mono text-[#A78BFA]">
                {formatCurrency(totalContributions - initialAmount)}
              </p>
            </div>
            <div className="finos-card p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-[#00D4AA]" />
                <span className="text-xs text-[#4E5A6B]">Kazanç</span>
              </div>
              <p className="text-lg font-semibold font-mono text-[#00D4AA]">
                {formatCurrency(totalGain)}
              </p>
            </div>
            <div className="finos-card p-4 glow-green">
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-4 h-4 text-[#00D4AA]" />
                <span className="text-xs text-[#4E5A6B]">Final Değer</span>
              </div>
              <p className="text-lg font-semibold font-mono text-[#00D4AA]">
                {formatCurrency(finalValue)}
              </p>
            </div>
          </div>

          {/* Projection Chart */}
          <div className="finos-card p-5">
            <h3 className="text-lg font-semibold text-[#F0F2F7] mb-4">Projeksiyon</h3>
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={projectionData.slice(0, currentYear + 1 || projectionData.length)}>
                  <defs>
                    <linearGradient id="colorProjection" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#00D4AA" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#00D4AA" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorContributions" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#A78BFA" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#A78BFA" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis 
                    dataKey="year" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: '#4E5A6B', fontSize: 12 }}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: '#4E5A6B', fontSize: 12 }}
                    tickFormatter={(value) => `₺${(value / 1000000).toFixed(1)}M`}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0E1117',
                      border: '1px solid rgba(255,255,255,0.1)',
                      borderRadius: '8px',
                      color: '#F0F2F7',
                    }}
                    formatter={(value: number, name: string) => [
                      formatCurrency(value), 
                      name === "value" ? "Toplam Değer" : "Katkılar"
                    ]}
                  />
                  <Area
                    type="monotone"
                    dataKey="contributions"
                    stroke="#A78BFA"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#colorContributions)"
                  />
                  <Area
                    type="monotone"
                    dataKey="value"
                    stroke="#00D4AA"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#colorProjection)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Year Progress */}
          <div className="finos-card p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-[#8892A4]">Simülasyon İlerlemesi</span>
              <span className="text-sm font-mono text-[#F0F2F7]">{currentYear} / {years} yıl</span>
            </div>
            <div className="h-2 bg-[#151A23] rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-[#00D4AA] to-[#00F5C4] rounded-full transition-all duration-200"
                style={{ width: `${(currentYear / years) * 100}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
