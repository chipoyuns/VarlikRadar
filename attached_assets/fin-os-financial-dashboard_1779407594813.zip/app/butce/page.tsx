"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { formatCurrency } from "@/components/ui/finos-components"
import { 
  Wallet, 
  TrendingUp, 
  TrendingDown,
  BarChart3,
  Database,
  Pencil,
  Plus,
  ShoppingCart,
  Utensils,
  Car,
  Zap,
  Gamepad2,
  AlertTriangle,
  Sparkles,
  CreditCard,
  Home,
  Calendar,
  Trash2,
  Edit2,
} from "lucide-react"
import { 
  PieChart, 
  Pie, 
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
} from "recharts"

// Mock data for budget page
const topStats = {
  toplamKasa: 7000,
  toplamGelir: 0,
  toplamGider: 0,
  portfoyKarZarar: 116633.08,
  toplamBakiye: 123633.08,
}

const gelirData: { name: string; value: number; color: string }[] = []

const giderData = [
  { name: "Market", value: 3420, color: "#4B9EFF" },
  { name: "Yemek", value: 1850, color: "#FF8C42" },
  { name: "Ulaşım", value: 920, color: "#A78BFA" },
  { name: "Faturalar", value: 1200, color: "#FFB833" },
  { name: "Eğlence", value: 680, color: "#FF6B9D" },
]

const envelopes = [
  { id: 1, emoji: "🛒", name: "Market", spent: 3420, limit: 4000, daysLeft: 3 },
  { id: 2, emoji: "🍽️", name: "Yemek", spent: 1850, limit: 2500, daysLeft: 3 },
  { id: 3, emoji: "🚗", name: "Ulaşım", spent: 920, limit: 1500, daysLeft: 3 },
  { id: 4, emoji: "⚡", name: "Faturalar", spent: 1200, limit: 1500, daysLeft: 3 },
  { id: 5, emoji: "🎮", name: "Eğlence", spent: 680, limit: 1000, daysLeft: 3 },
  { id: 6, emoji: "🏠", name: "Kira", spent: 8500, limit: 8500, daysLeft: 3 },
  { id: 7, emoji: "💊", name: "Sağlık", spent: 450, limit: 1000, daysLeft: 3 },
  { id: 8, emoji: "📚", name: "Eğitim", spent: 250, limit: 500, daysLeft: 3 },
]

const incomeCategories = ["Maaş", "Kira Geliri", "Temettü", "Freelance", "Diğer"]

const incomeHistory = [
  { id: 1, category: "Maaş", description: "Ocak maaşı", amount: 45000, date: "2024-01-15" },
  { id: 2, category: "Temettü", description: "THYAO temettü", amount: 2350, date: "2024-01-10" },
  { id: 3, category: "Freelance", description: "Web projesi", amount: 8500, date: "2024-01-08" },
]

const subscriptions = [
  { id: 1, name: "Netflix", logo: "N", color: "#E50914", price: 149, billingDate: "15 Haz", unused: false },
  { id: 2, name: "Spotify", logo: "S", color: "#1DB954", price: 49, billingDate: "20 Haz", unused: false },
  { id: 3, name: "iCloud 200GB", logo: "☁️", color: "#007AFF", price: 19, billingDate: "1 Haz", unused: false },
  { id: 4, name: "YouTube Premium", logo: "▶", color: "#FF0000", price: 79, billingDate: "25 Haz", unused: true },
  { id: 5, name: "Amazon Prime", logo: "P", color: "#FF9900", price: 39, billingDate: "5 Haz", unused: true },
  { id: 6, name: "ChatGPT Plus", logo: "◯", color: "#10A37F", price: 314, billingDate: "10 Haz", unused: false },
]

const cashFlowEvents = [
  { id: 1, name: "Maaş günü", type: "income", amount: 45000, date: "1 Haz" },
  { id: 2, name: "Kira ödeme", type: "expense", amount: 8500, date: "5 Haz" },
  { id: 3, name: "Kredi kartı", type: "expense", amount: 12500, date: "15 Haz" },
  { id: 4, name: "Fatura", type: "expense", amount: 1200, date: "20 Haz" },
]

const aiInsights = [
  { icon: Utensils, text: "Bu ay dışarıda yemek harcaman %47 arttı", type: "warning" },
  { icon: CreditCard, text: "Son 90 günde kahveye ₺8.420 harcadın", type: "info" },
  { icon: AlertTriangle, text: "Bu hızla devam edersen ay sonu ₺2.100 açık verirsin", type: "danger" },
]

export default function BudgetPage() {
  const [activeTab, setActiveTab] = useState<"gelirler" | "giderler">("gelirler")
  const [editingKasa, setEditingKasa] = useState(false)
  const [kasaValue, setKasaValue] = useState(topStats.toplamKasa)
  const [newIncome, setNewIncome] = useState({
    category: "",
    description: "",
    amount: "",
    date: "",
  })

  const monthlySubscription = subscriptions.reduce((sum, s) => sum + s.price, 0)
  const yearlySubscription = monthlySubscription * 12
  const netFreeCash = 13500

  const getProgressColor = (percent: number) => {
    if (percent < 60) return "#00D4AA"
    if (percent < 80) return "#FFB833"
    return "#FF4757"
  }

  return (
    <DashboardLayout>
      {/* Top Stats Row - 5 cards */}
      <div className="grid grid-cols-5 gap-4 mb-6">
        {/* Toplam Kasa */}
        <div className="finos-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <Wallet className="w-4 h-4 text-[#4B9EFF]" />
            <span className="text-xs text-[#8892A4]">Toplam Kasa</span>
          </div>
          <div className="flex items-center gap-2">
            {editingKasa ? (
              <input
                type="number"
                value={kasaValue}
                onChange={(e) => setKasaValue(Number(e.target.value))}
                onBlur={() => setEditingKasa(false)}
                onKeyDown={(e) => e.key === "Enter" && setEditingKasa(false)}
                className="w-full bg-[#151A23] border border-[rgba(255,255,255,0.1)] rounded px-2 py-1 text-lg font-semibold font-mono text-[#F0F2F7] focus:outline-none focus:border-[#4B9EFF]"
                autoFocus
              />
            ) : (
              <>
                <span className="text-lg font-semibold font-mono text-[#F0F2F7]">
                  {formatCurrency(kasaValue)}
                </span>
                <button 
                  onClick={() => setEditingKasa(true)}
                  className="p-1 hover:bg-[rgba(255,255,255,0.05)] rounded transition-colors"
                >
                  <Pencil className="w-3 h-3 text-[#4E5A6B] hover:text-[#8892A4]" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Toplam Gelir */}
        <div className="finos-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-[#00D4AA]" />
            <span className="text-xs text-[#8892A4]">Toplam Gelir</span>
          </div>
          <span className="text-lg font-semibold font-mono text-[#00D4AA]">
            {formatCurrency(topStats.toplamGelir)}
          </span>
        </div>

        {/* Toplam Gider */}
        <div className="finos-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingDown className="w-4 h-4 text-[#FF4757]" />
            <span className="text-xs text-[#8892A4]">Toplam Gider</span>
          </div>
          <span className="text-lg font-semibold font-mono text-[#FF4757]">
            {formatCurrency(topStats.toplamGider)}
          </span>
        </div>

        {/* Portföy Kar/Zarar */}
        <div className="finos-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <BarChart3 className="w-4 h-4 text-[#00D4AA]" />
            <span className="text-xs text-[#8892A4]">Portföy Kar/Zarar</span>
          </div>
          <span className="text-lg font-semibold font-mono text-[#00D4AA]">
            +{formatCurrency(topStats.portfoyKarZarar)}
          </span>
        </div>

        {/* Toplam Bakiye */}
        <div className="finos-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <Database className="w-4 h-4 text-[#A78BFA]" />
            <span className="text-xs text-[#8892A4]">Toplam Bakiye</span>
          </div>
          <span className="text-lg font-semibold font-mono text-[#F0F2F7]">
            {formatCurrency(topStats.toplamBakiye)}
          </span>
        </div>
      </div>

      {/* Charts Row - 2 equal cards */}
      <div className="grid grid-cols-2 gap-6 mb-6">
        {/* Gelir Dağılımı */}
        <div className="finos-card p-5">
          <h2 className="text-base font-semibold text-[#F0F2F7] mb-4">Gelir Dağılımı</h2>
          <div className="h-[200px] flex items-center justify-center">
            {gelirData.length === 0 ? (
              <div className="text-center">
                <div className="w-24 h-24 mx-auto mb-3 rounded-full border-2 border-dashed border-[#4E5A6B] flex items-center justify-center">
                  <TrendingUp className="w-8 h-8 text-[#4E5A6B]" />
                </div>
                <p className="text-sm text-[#4E5A6B]">Gelir verisi bulunmamaktadır</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={gelirData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    dataKey="value"
                    paddingAngle={2}
                  >
                    {gelirData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0E1117',
                      border: '1px solid rgba(255,255,255,0.1)',
                      borderRadius: '8px',
                    }}
                    formatter={(value: number) => [formatCurrency(value), ""]}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Gider Dağılımı */}
        <div className="finos-card p-5">
          <h2 className="text-base font-semibold text-[#F0F2F7] mb-4">Gider Dağılımı</h2>
          <div className="h-[200px]">
            {giderData.length === 0 ? (
              <div className="flex items-center justify-center h-full">
                <div className="text-center">
                  <div className="w-24 h-24 mx-auto mb-3 rounded-full border-2 border-dashed border-[#4E5A6B] flex items-center justify-center">
                    <TrendingDown className="w-8 h-8 text-[#4E5A6B]" />
                  </div>
                  <p className="text-sm text-[#4E5A6B]">Gider verisi bulunmamaktadır</p>
                </div>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={giderData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    dataKey="value"
                    paddingAngle={2}
                  >
                    {giderData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0E1117',
                      border: '1px solid rgba(255,255,255,0.1)',
                      borderRadius: '8px',
                    }}
                    formatter={(value: number) => [formatCurrency(value), ""]}
                  />
                  <Legend 
                    formatter={(value) => <span className="text-[#8892A4] text-xs">{value}</span>}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>

      {/* Tab Switcher */}
      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setActiveTab("gelirler")}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            activeTab === "gelirler"
              ? "bg-white text-[#080A0F]"
              : "bg-[#151A23] text-[#8892A4] hover:text-[#F0F2F7]"
          }`}
        >
          Gelirler
        </button>
        <button
          onClick={() => setActiveTab("giderler")}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            activeTab === "giderler"
              ? "bg-white text-[#080A0F]"
              : "bg-[#151A23] text-[#8892A4] hover:text-[#F0F2F7]"
          }`}
        >
          Giderler
        </button>
      </div>

      {/* Zarflama Sistemi - Envelope Cards */}
      <div className="finos-card p-5 mb-6">
        <h2 className="text-base font-semibold text-[#F0F2F7] mb-4">Zarflama Sistemi</h2>
        <div className="grid grid-cols-4 gap-4">
          {envelopes.map((envelope) => {
            const percent = (envelope.spent / envelope.limit) * 100
            const progressColor = getProgressColor(percent)
            const isWarning = envelope.daysLeft <= 5 && percent > 70

            return (
              <div
                key={envelope.id}
                className="finos-card-inner p-4 group hover:border-[rgba(255,255,255,0.15)] transition-all cursor-pointer"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{envelope.emoji}</span>
                    <span className="text-sm font-medium text-[#F0F2F7]">{envelope.name}</span>
                  </div>
                  <button className="opacity-0 group-hover:opacity-100 transition-opacity px-2 py-1 text-xs text-[#8892A4] hover:text-[#F0F2F7] hover:bg-[rgba(255,255,255,0.05)] rounded">
                    Düzenle
                  </button>
                </div>

                <p className="text-sm font-mono text-[#8892A4] mb-2">
                  {formatCurrency(envelope.spent)} / {formatCurrency(envelope.limit)}
                </p>

                {/* Progress Bar */}
                <div className="relative h-2 bg-[#0E1117] rounded-full overflow-hidden mb-2">
                  <div
                    className="absolute left-0 top-0 h-full rounded-full transition-all duration-500"
                    style={{ 
                      width: `${Math.min(percent, 100)}%`,
                      backgroundColor: progressColor 
                    }}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <span 
                    className="text-xs font-mono font-medium"
                    style={{ color: progressColor }}
                  >
                    %{percent.toFixed(1)}
                  </span>
                  {isWarning && (
                    <span className="flex items-center gap-1 text-xs text-[#FFB833]">
                      {envelope.daysLeft} gün kaldı
                      <AlertTriangle className="w-3 h-3" />
                    </span>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Gelir Ekle Form */}
      <div className="finos-card p-5 mb-6">
        <h2 className="text-base font-semibold text-[#F0F2F7] mb-4">Gelir Ekle</h2>
        <div className="flex items-end gap-4">
          <div className="flex-1">
            <label className="block text-xs text-[#8892A4] mb-1">Kategori</label>
            <select
              value={newIncome.category}
              onChange={(e) => setNewIncome({ ...newIncome, category: e.target.value })}
              className="w-full bg-[#151A23] border border-[rgba(255,255,255,0.1)] rounded-lg px-3 py-2 text-sm text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]"
            >
              <option value="">Seçin...</option>
              {incomeCategories.map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
          <div className="flex-1">
            <label className="block text-xs text-[#8892A4] mb-1">Açıklama</label>
            <input
              type="text"
              value={newIncome.description}
              onChange={(e) => setNewIncome({ ...newIncome, description: e.target.value })}
              placeholder="Açıklama girin..."
              className="w-full bg-[#151A23] border border-[rgba(255,255,255,0.1)] rounded-lg px-3 py-2 text-sm text-[#F0F2F7] placeholder:text-[#4E5A6B] focus:outline-none focus:border-[#00D4AA]"
            />
          </div>
          <div className="w-40">
            <label className="block text-xs text-[#8892A4] mb-1">Tutar</label>
            <input
              type="number"
              value={newIncome.amount}
              onChange={(e) => setNewIncome({ ...newIncome, amount: e.target.value })}
              placeholder="₺0"
              className="w-full bg-[#151A23] border border-[rgba(255,255,255,0.1)] rounded-lg px-3 py-2 text-sm text-[#F0F2F7] placeholder:text-[#4E5A6B] focus:outline-none focus:border-[#00D4AA] font-mono"
            />
          </div>
          <div className="w-40">
            <label className="block text-xs text-[#8892A4] mb-1">Tarih</label>
            <input
              type="date"
              value={newIncome.date}
              onChange={(e) => setNewIncome({ ...newIncome, date: e.target.value })}
              className="w-full bg-[#151A23] border border-[rgba(255,255,255,0.1)] rounded-lg px-3 py-2 text-sm text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA]"
            />
          </div>
          <button className="flex items-center gap-2 px-4 py-2 bg-[#00D4AA] rounded-lg text-sm font-medium text-[#080A0F] hover:bg-[#00D4AA]/90 transition-colors whitespace-nowrap">
            <Plus className="w-4 h-4" />
            Ekle
          </button>
        </div>
      </div>

      {/* Gelir Geçmişi Table */}
      <div className="finos-card p-5 mb-6">
        <h2 className="text-base font-semibold text-[#F0F2F7] mb-4">Gelir Geçmişi</h2>
        <div className="overflow-x-auto finos-scrollbar">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[rgba(255,255,255,0.05)]">
                <th className="text-left text-xs font-medium text-[#4E5A6B] uppercase tracking-wider py-3 px-4">Tarih</th>
                <th className="text-left text-xs font-medium text-[#4E5A6B] uppercase tracking-wider py-3 px-4">Kategori</th>
                <th className="text-left text-xs font-medium text-[#4E5A6B] uppercase tracking-wider py-3 px-4">Açıklama</th>
                <th className="text-right text-xs font-medium text-[#4E5A6B] uppercase tracking-wider py-3 px-4">Tutar</th>
                <th className="text-right text-xs font-medium text-[#4E5A6B] uppercase tracking-wider py-3 px-4">İşlem</th>
              </tr>
            </thead>
            <tbody>
              {incomeHistory.map((item) => (
                <tr key={item.id} className="border-b border-[rgba(255,255,255,0.03)] hover:bg-[rgba(255,255,255,0.02)] transition-colors">
                  <td className="py-3 px-4 text-sm text-[#8892A4] font-mono">{item.date}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-1 rounded-full text-xs bg-[rgba(0,212,170,0.1)] text-[#00D4AA]">
                      {item.category}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-sm text-[#F0F2F7]">{item.description}</td>
                  <td className="py-3 px-4 text-sm text-[#00D4AA] font-mono text-right">
                    +{formatCurrency(item.amount)}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button className="p-1.5 hover:bg-[rgba(255,255,255,0.05)] rounded transition-colors">
                        <Edit2 className="w-4 h-4 text-[#4E5A6B] hover:text-[#8892A4]" />
                      </button>
                      <button className="p-1.5 hover:bg-[rgba(255,71,87,0.1)] rounded transition-colors">
                        <Trash2 className="w-4 h-4 text-[#4E5A6B] hover:text-[#FF4757]" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Abonelik Takipçisi */}
      <div className="finos-card p-5 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-[#F0F2F7]">Abonelikler</h2>
          <div className="flex items-center gap-4 text-sm">
            <span className="text-[#8892A4]">
              Aylık: <span className="font-mono text-[#F0F2F7]">{formatCurrency(monthlySubscription)}</span>
            </span>
            <span className="text-[#8892A4]">
              Yıllık: <span className="font-mono text-[#F0F2F7]">{formatCurrency(yearlySubscription)}</span>
            </span>
          </div>
        </div>
        <div className="grid grid-cols-6 gap-3">
          {subscriptions.map((sub) => (
            <div
              key={sub.id}
              className="finos-card-inner p-3 group hover:border-[rgba(255,255,255,0.15)] transition-all relative"
            >
              {sub.unused && (
                <div className="absolute -top-2 -right-2 px-2 py-0.5 bg-[#FFB833] rounded-full text-[10px] font-medium text-[#080A0F]">
                  3 aydır kullanılmadı
                </div>
              )}
              <div className="flex flex-col items-center text-center">
                <div 
                  className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold text-lg mb-2"
                  style={{ backgroundColor: sub.color }}
                >
                  {sub.logo}
                </div>
                <span className="text-xs font-medium text-[#F0F2F7] mb-1">{sub.name}</span>
                <span className="text-xs font-mono text-[#8892A4] mb-1">{formatCurrency(sub.price)}/ay</span>
                <span className="text-[10px] text-[#4E5A6B]">{sub.billingDate}</span>
                <button className="mt-2 opacity-0 group-hover:opacity-100 transition-opacity px-2 py-1 text-xs text-[#FF4757] hover:bg-[rgba(255,71,87,0.1)] rounded">
                  İptal
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Row: Cash Flow + AI Analysis */}
      <div className="grid grid-cols-3 gap-6">
        {/* Nakit Akış Projeksiyonu */}
        <div className="col-span-2 finos-card p-5">
          <h2 className="text-base font-semibold text-[#F0F2F7] mb-4">Önümüzdeki 30 Gün</h2>
          <div className="flex items-center gap-4 mb-6 overflow-x-auto finos-scrollbar pb-2">
            {cashFlowEvents.map((event, index) => (
              <div key={event.id} className="flex items-center">
                <div className="flex flex-col items-center min-w-[100px]">
                  <div 
                    className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${
                      event.type === "income" 
                        ? "bg-[rgba(0,212,170,0.1)]" 
                        : "bg-[rgba(255,71,87,0.1)]"
                    }`}
                  >
                    {event.type === "income" ? (
                      <TrendingUp className="w-5 h-5 text-[#00D4AA]" />
                    ) : (
                      <TrendingDown className="w-5 h-5 text-[#FF4757]" />
                    )}
                  </div>
                  <span className="text-xs text-[#F0F2F7] font-medium text-center">{event.name}</span>
                  <span className={`text-xs font-mono ${
                    event.type === "income" ? "text-[#00D4AA]" : "text-[#FF4757]"
                  }`}>
                    {event.type === "income" ? "+" : "-"}{formatCurrency(event.amount)}
                  </span>
                  <span className="text-[10px] text-[#4E5A6B]">{event.date}</span>
                </div>
                {index < cashFlowEvents.length - 1 && (
                  <div className="w-12 h-[2px] bg-[#4E5A6B] mx-2" />
                )}
              </div>
            ))}
          </div>
          <div className="border-t border-[rgba(255,255,255,0.05)] pt-4">
            <span className="text-sm text-[#8892A4]">Net özgür harcanabilir:</span>
            <span className="ml-2 text-2xl font-bold font-mono text-[#00D4AA]">
              {formatCurrency(netFreeCash)}
            </span>
          </div>
        </div>

        {/* AI Bütçe Analizi */}
        <div className="finos-card p-5 bg-[linear-gradient(135deg,rgba(167,139,250,0.05)_0%,rgba(167,139,250,0.02)_100%)] border-[rgba(167,139,250,0.2)]">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="w-5 h-5 text-[#A78BFA]" />
            <h2 className="text-base font-semibold text-[#F0F2F7]">AI Analizi</h2>
          </div>
          <div className="space-y-3">
            {aiInsights.map((insight, index) => {
              const Icon = insight.icon
              const colors = {
                warning: { bg: "rgba(255,184,51,0.1)", text: "#FFB833" },
                info: { bg: "rgba(75,158,255,0.1)", text: "#4B9EFF" },
                danger: { bg: "rgba(255,71,87,0.1)", text: "#FF4757" },
              }
              const color = colors[insight.type as keyof typeof colors]

              return (
                <div 
                  key={index} 
                  className="finos-card-inner p-3 flex items-start gap-3"
                  style={{ borderColor: `${color.text}20` }}
                >
                  <div 
                    className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: color.bg }}
                  >
                    <Icon className="w-4 h-4" style={{ color: color.text }} />
                  </div>
                  <p className="text-sm text-[#8892A4] leading-relaxed">{insight.text}</p>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
