"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { formatCurrency } from "@/components/ui/finos-components"
import { 
  Plus,
  Pencil,
  Trash2,
  Flame,
  Shield,
  Lightbulb,
  PartyPopper,
  AlertTriangle,
  Skull,
} from "lucide-react"

// Goal data
const goals = [
  {
    id: 1,
    title: "EV PEŞİNATI",
    emoji: "🏠",
    current: 180000,
    target: 500000,
    monthlyContribution: 8000,
    estimatedCompletion: "Mart 2028",
    remainingMonths: 33,
    aiInsight: "Katkını ₺10.000'e çıkarsan 8 ay erken tamamlarsın",
    color: "#00D4AA",
  },
  {
    id: 2,
    title: "ACİL DURUM FONU",
    emoji: "🛡️",
    current: 42000,
    target: 70000,
    monthlyContribution: 3000,
    estimatedCompletion: "Aralık 2025",
    remainingMonths: 10,
    subtitle: "6 aylık gider hedefi",
    warning: "Hedefinize ulaşmak için ₺28.000 daha gerekiyor",
    color: "#FFB833",
  },
  {
    id: 3,
    title: "TATİL FONU",
    emoji: "✈️",
    current: 17000,
    target: 20000,
    monthlyContribution: 1500,
    estimatedCompletion: "Temmuz 2026",
    remainingMonths: 2,
    celebration: "Hedefinize çok yakınsınız!",
    color: "#00D4AA",
  },
  {
    id: 4,
    title: "EMEKLİLİK",
    emoji: "🏖️",
    current: 120000,
    target: 1500000,
    monthlyContribution: 5000,
    estimatedCompletion: "2045",
    remainingMonths: 240,
    color: "#FF4757",
  },
]

// FIRE data
const fireData = {
  targetAge: 41,
  fireTarget: 18750000,
  currentNetWorth: 3891094,
  monthlyPassiveIncome: 62500,
  remainingYears: 11,
  remainingMonths: 4,
  progress: 67,
}

// Survival mode data
const survivalData = {
  months: 8,
  monthlyRent: 8500,
  monthlyBills: 1200,
  monthlyFood: 4000,
  totalMonthlyExpense: 13700,
  currentCash: 110000,
}

// Progress Ring Component
function ProgressRing({ 
  progress, 
  size = 120, 
  strokeWidth = 8, 
  color = "#00D4AA" 
}: { 
  progress: number
  size?: number
  strokeWidth?: number
  color?: string
}) {
  const radius = (size - strokeWidth) / 2
  const circumference = radius * 2 * Math.PI
  const offset = circumference - (progress / 100) * circumference

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg className="progress-ring" width={size} height={size}>
        {/* Background circle */}
        <circle
          stroke="#151A23"
          strokeWidth={strokeWidth}
          fill="transparent"
          r={radius}
          cx={size / 2}
          cy={size / 2}
        />
        {/* Progress circle */}
        <circle
          stroke={color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          fill="transparent"
          r={radius}
          cx={size / 2}
          cy={size / 2}
          style={{
            strokeDasharray: circumference,
            strokeDashoffset: offset,
            transition: "stroke-dashoffset 0.5s ease-in-out",
            filter: `drop-shadow(0 0 6px ${color}40)`,
          }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-2xl font-bold font-mono text-[#F0F2F7]">{progress}%</span>
      </div>
    </div>
  )
}

export default function GoalsPage() {
  const activeGoals = goals.filter(g => (g.current / g.target) < 1).length
  const completedGoals = goals.filter(g => (g.current / g.target) >= 1).length
  const totalTarget = goals.reduce((sum, g) => sum + g.target, 0)
  const totalSaved = goals.reduce((sum, g) => sum + g.current, 0)

  return (
    <DashboardLayout>
      {/* Top Stats */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="finos-card p-4">
          <p className="text-xs text-[#8892A4] mb-1">Aktif Hedef</p>
          <p className="text-3xl font-bold font-mono text-[#F0F2F7]">{activeGoals}</p>
        </div>
        <div className="finos-card p-4">
          <p className="text-xs text-[#8892A4] mb-1">Tamamlanan</p>
          <p className="text-3xl font-bold font-mono text-[#00D4AA]">{completedGoals}</p>
        </div>
        <div className="finos-card p-4">
          <p className="text-xs text-[#8892A4] mb-1">Toplam Hedef Tutarı</p>
          <p className="text-xl font-bold font-mono text-[#F0F2F7]">{formatCurrency(totalTarget)}</p>
        </div>
        <div className="finos-card p-4 flex items-center justify-between">
          <div>
            <p className="text-xs text-[#8892A4] mb-1">Toplam Birikim</p>
            <p className="text-xl font-bold font-mono text-[#00D4AA]">{formatCurrency(totalSaved)}</p>
          </div>
          <button className="flex items-center gap-2 px-4 py-2 bg-[#00D4AA] rounded-lg text-sm font-medium text-[#080A0F] hover:bg-[#00D4AA]/90 transition-colors">
            <Plus className="w-4 h-4" />
            Yeni Hedef
          </button>
        </div>
      </div>

      {/* Goal Cards Grid */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        {goals.map((goal) => {
          const progress = Math.round((goal.current / goal.target) * 100)
          const progressColor = progress >= 80 ? "#00D4AA" : progress >= 50 ? "#FFB833" : "#FF4757"

          return (
            <div key={goal.id} className="finos-card p-5 relative group">
              {/* Edit/Delete buttons */}
              <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="p-1.5 rounded-lg bg-[#151A23] hover:bg-[#1a2030] transition-colors">
                  <Pencil className="w-3.5 h-3.5 text-[#8892A4]" />
                </button>
                <button className="p-1.5 rounded-lg bg-[#151A23] hover:bg-[rgba(255,71,87,0.2)] transition-colors">
                  <Trash2 className="w-3.5 h-3.5 text-[#FF4757]" />
                </button>
              </div>

              {/* Header */}
              <div className="flex items-center gap-3 mb-4">
                <span className="text-3xl">{goal.emoji}</span>
                <div>
                  <h3 className="text-lg font-semibold text-[#F0F2F7]">{goal.title}</h3>
                  {goal.subtitle && (
                    <p className="text-xs text-[#8892A4]">{goal.subtitle}</p>
                  )}
                </div>
              </div>

              {/* Progress Ring and Amount */}
              <div className="flex items-center gap-6 mb-4">
                <ProgressRing progress={progress} color={progressColor} />
                <div>
                  <p className="text-2xl font-bold font-mono text-[#F0F2F7]">
                    {formatCurrency(goal.current)}
                  </p>
                  <p className="text-sm text-[#8892A4]">
                    / {formatCurrency(goal.target)}
                  </p>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="relative h-2 bg-[#151A23] rounded-full overflow-hidden mb-3">
                <div 
                  className="absolute left-0 top-0 h-full rounded-full transition-all duration-500"
                  style={{ 
                    width: `${Math.min(progress, 100)}%`,
                    backgroundColor: progressColor,
                    boxShadow: `0 0 8px ${progressColor}60`,
                  }}
                />
              </div>

              {/* Stats */}
              <div className="flex items-center justify-between text-sm mb-3">
                <span className="text-[#8892A4]">
                  Aylık katkı: <span className="font-mono text-[#F0F2F7]">{formatCurrency(goal.monthlyContribution)}</span>
                </span>
                <span className="text-[#8892A4]">
                  Tahmini bitiş: <span className="text-[#F0F2F7]">{goal.estimatedCompletion}</span>
                </span>
              </div>

              {/* Remaining */}
              <p className="text-xs text-[#4E5A6B] mb-3">
                {goal.remainingMonths} ay kaldı
              </p>

              {/* AI Insight */}
              {goal.aiInsight && (
                <div className="p-3 rounded-lg bg-[rgba(167,139,250,0.08)] border border-[rgba(167,139,250,0.2)]">
                  <div className="flex items-start gap-2">
                    <Lightbulb className="w-4 h-4 text-[#A78BFA] flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-[#A78BFA]">{goal.aiInsight}</p>
                  </div>
                </div>
              )}

              {/* Warning */}
              {goal.warning && (
                <div className="p-3 rounded-lg bg-[rgba(255,184,51,0.08)] border border-[rgba(255,184,51,0.2)]">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-[#FFB833] flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-[#FFB833]">{goal.warning}</p>
                  </div>
                </div>
              )}

              {/* Celebration */}
              {goal.celebration && (
                <div className="p-3 rounded-lg bg-[rgba(0,212,170,0.08)] border border-[rgba(0,212,170,0.2)]">
                  <div className="flex items-start gap-2">
                    <PartyPopper className="w-4 h-4 text-[#00D4AA] flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-[#00D4AA]">{goal.celebration}</p>
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>

      {/* FIRE Counter */}
      <div className="finos-card p-6 mb-6 relative overflow-hidden">
        {/* Ember gradient on left edge */}
        <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-[#FF4757] via-[#FFB833] to-[#FF4757]" />
        <div className="absolute left-0 top-0 bottom-0 w-24 bg-gradient-to-r from-[rgba(255,71,87,0.1)] to-transparent" />

        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <Flame className="w-6 h-6 text-[#FF4757]" />
          <h2 className="text-xl font-bold text-[#F0F2F7]">FİNANSAL ÖZGÜRLÜK SAYACI</h2>
        </div>

        {/* Center Content */}
        <div className="flex items-center justify-center gap-12 mb-6">
          <div className="text-center">
            <div className="flex items-baseline justify-center gap-2">
              <span className="text-7xl font-bold font-mono text-[#F0F2F7]" style={{
                textShadow: "0 0 30px rgba(255,184,51,0.5), 0 0 60px rgba(255,184,51,0.3)"
              }}>
                {fireData.targetAge}
              </span>
              <span className="text-xl text-[#8892A4]">yaşında özgürsün</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <ProgressRing progress={fireData.progress} size={100} color="#FFB833" />
            <p className="text-sm text-[#8892A4]">
              Hedefe <span className="text-[#FFB833] font-semibold">%{fireData.progress}</span> yaklaştın
            </p>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-4 gap-6 mb-4">
          <div className="text-center p-4 rounded-lg bg-[#151A23]">
            <p className="text-xs text-[#8892A4] mb-1">FIRE Hedefi</p>
            <p className="text-lg font-bold font-mono text-[#F0F2F7]">{formatCurrency(fireData.fireTarget)}</p>
          </div>
          <div className="text-center p-4 rounded-lg bg-[#151A23]">
            <p className="text-xs text-[#8892A4] mb-1">Mevcut Net Değer</p>
            <p className="text-lg font-bold font-mono text-[#00D4AA]">{formatCurrency(fireData.currentNetWorth)}</p>
          </div>
          <div className="text-center p-4 rounded-lg bg-[#151A23]">
            <p className="text-xs text-[#8892A4] mb-1">{"Aylık Pasif Gelir (FIRE'da)"}</p>
            <p className="text-lg font-bold font-mono text-[#4B9EFF]">{formatCurrency(fireData.monthlyPassiveIncome)}</p>
          </div>
          <div className="text-center p-4 rounded-lg bg-[#151A23]">
            <p className="text-xs text-[#8892A4] mb-1">Kalan Süre</p>
            <p className="text-lg font-bold font-mono text-[#FFB833]">
              {fireData.remainingYears} yıl {fireData.remainingMonths} ay
            </p>
          </div>
        </div>

        {/* Footnote */}
        <p className="text-xs text-[#4E5A6B] text-center">
          {"4% kuralına göre hesaplanmıştır"}
        </p>
      </div>

      {/* Survival Mode */}
      <div className="finos-card p-6 relative overflow-hidden">
        {/* Red tint overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-[rgba(255,71,87,0.05)] to-transparent pointer-events-none" />
        <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#FF4757]" />

        <div className="relative">
          {/* Header */}
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-[rgba(255,71,87,0.15)] flex items-center justify-center">
              <Skull className="w-5 h-5 text-[#FF4757]" />
            </div>
            <h2 className="text-xl font-bold text-[#F0F2F7]">HAYATTA KALMA MODU</h2>
          </div>

          {/* Center Content */}
          <div className="text-center mb-6">
            <p className="text-8xl font-bold font-mono text-[#FF4757]" style={{
              textShadow: "0 0 40px rgba(255,71,87,0.4)"
            }}>
              {survivalData.months} AY
            </p>
            <p className="text-lg text-[#8892A4] mt-2">
              Bugün işini kaybetsen <span className="text-[#FF4757] font-semibold">{survivalData.months} ay</span> hayatta kalabilirsin
            </p>
          </div>

          {/* Breakdown */}
          <div className="grid grid-cols-5 gap-4 mb-6">
            <div className="text-center p-3 rounded-lg bg-[#151A23]">
              <p className="text-xs text-[#8892A4] mb-1">Aylık Kira</p>
              <p className="text-sm font-mono text-[#FF4757]">{formatCurrency(survivalData.monthlyRent)}</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-[#151A23]">
              <p className="text-xs text-[#8892A4] mb-1">Aylık Faturalar</p>
              <p className="text-sm font-mono text-[#FF4757]">{formatCurrency(survivalData.monthlyBills)}</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-[#151A23]">
              <p className="text-xs text-[#8892A4] mb-1">Aylık Yemek</p>
              <p className="text-sm font-mono text-[#FF4757]">{formatCurrency(survivalData.monthlyFood)}</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-[#151A23] border border-[rgba(255,71,87,0.3)]">
              <p className="text-xs text-[#8892A4] mb-1">Toplam Aylık Gider</p>
              <p className="text-sm font-mono font-bold text-[#FF4757]">{formatCurrency(survivalData.totalMonthlyExpense)}</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-[#151A23] border border-[rgba(0,212,170,0.3)]">
              <p className="text-xs text-[#8892A4] mb-1">Mevcut Nakit</p>
              <p className="text-sm font-mono font-bold text-[#00D4AA]">{formatCurrency(survivalData.currentCash)}</p>
            </div>
          </div>

          {/* Progress Blocks */}
          <div className="flex items-center gap-2">
            <p className="text-xs text-[#8892A4] mr-2">Ay:</p>
            {Array.from({ length: 12 }).map((_, i) => (
              <div
                key={i}
                className={`h-8 w-8 rounded flex items-center justify-center text-xs font-mono font-bold transition-all ${
                  i < survivalData.months
                    ? "bg-[#FF4757] text-white"
                    : "bg-[#151A23] text-[#4E5A6B]"
                }`}
                style={{
                  boxShadow: i < survivalData.months ? "0 0 10px rgba(255,71,87,0.4)" : "none"
                }}
              >
                {i + 1}
              </div>
            ))}
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
