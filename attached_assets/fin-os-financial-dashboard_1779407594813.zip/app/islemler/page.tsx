"use client"

import { DashboardLayout } from "@/components/dashboard-layout"
import { formatCurrency } from "@/components/ui/finos-components"
import { 
  Plus,
  Search,
  Calendar,
  ChevronDown,
  FileText,
  FileSpreadsheet,
  Camera,
  Mic,
  Pencil,
  Trash2,
  ChevronLeft,
  ChevronRight,
  X,
  Upload,
} from "lucide-react"
import { useState } from "react"

// Transaction data for İşlemler page
const transactions = [
  { 
    id: 1, 
    date: "2026-05-18", 
    type: "alis", 
    asset: "BTC", 
    assetName: "bitcoin", 
    category: null,
    quantity: 0.1, 
    price: 77000, 
    total: 7700, 
    commission: null,
    notes: null,
    logo: "btc"
  },
  { 
    id: 2, 
    date: "2026-05-01", 
    type: "gelir", 
    asset: "Maas", 
    assetName: "Maaş", 
    category: null,
    quantity: null, 
    price: null, 
    total: 28000, 
    commission: null,
    notes: null,
    logo: "money"
  },
  { 
    id: 3, 
    date: "2026-05-14", 
    type: "gider", 
    asset: "Market", 
    assetName: "Market Alışverişi", 
    category: "Market",
    quantity: null, 
    price: null, 
    total: -842, 
    commission: null,
    notes: null,
    logo: "cart"
  },
  { 
    id: 4, 
    date: "2026-05-12", 
    type: "satis", 
    asset: "ETH", 
    assetName: "ethereum", 
    category: null,
    quantity: 2.5, 
    price: 3200, 
    total: 8000, 
    commission: 12,
    notes: "Kısmi satış",
    logo: "eth"
  },
  { 
    id: 5, 
    date: "2026-05-10", 
    type: "temettu", 
    asset: "THYAO", 
    assetName: "Türk Hava Yolları", 
    category: null,
    quantity: 500, 
    price: 2.80, 
    total: 1400, 
    commission: null,
    notes: "2024 temettü",
    logo: "thy"
  },
  { 
    id: 6, 
    date: "2026-05-08", 
    type: "alis", 
    asset: "GARAN", 
    assetName: "Garanti Bankası", 
    category: null,
    quantity: 100, 
    price: 76.50, 
    total: 7650, 
    commission: 15.30,
    notes: null,
    logo: "garan"
  },
  { 
    id: 7, 
    date: "2026-05-05", 
    type: "gider", 
    asset: "Fatura", 
    assetName: "Elektrik Faturası", 
    category: "Fatura",
    quantity: null, 
    price: null, 
    total: -456, 
    commission: null,
    notes: null,
    logo: "bill"
  },
  { 
    id: 8, 
    date: "2026-05-03", 
    type: "alis", 
    asset: "ASELS", 
    assetName: "Aselsan", 
    category: null,
    quantity: 200, 
    price: 53.40, 
    total: 10680, 
    commission: 21.36,
    notes: "Uzun vadeli",
    logo: "asel"
  },
  { 
    id: 9, 
    date: "2026-04-28", 
    type: "gelir", 
    asset: "Kira", 
    assetName: "Kira Geliri", 
    category: null,
    quantity: null, 
    price: null, 
    total: 8500, 
    commission: null,
    notes: "Nisan kirası",
    logo: "home"
  },
  { 
    id: 10, 
    date: "2026-04-25", 
    type: "gider", 
    asset: "Ulasim", 
    assetName: "Akaryakıt", 
    category: "Ulaşım",
    quantity: null, 
    price: null, 
    total: -620, 
    commission: null,
    notes: null,
    logo: "car"
  },
]

const typeConfig: Record<string, { label: string; color: string; bg: string }> = {
  alis: { label: "alış", color: "#00D4AA", bg: "rgba(0,212,170,0.15)" },
  satis: { label: "satış", color: "#FF4757", bg: "rgba(255,71,87,0.15)" },
  temettu: { label: "temettü", color: "#FFB833", bg: "rgba(255,184,51,0.15)" },
  gelir: { label: "gelir", color: "#00D4AA", bg: "rgba(0,212,170,0.15)" },
  gider: { label: "gider", color: "#FF4757", bg: "rgba(255,71,87,0.15)" },
}

const categoryOptions = ["Tümü", "Market", "Fatura", "Ulaşım", "Eğlence", "Sağlık", "Eğitim", "Diğer"]
const assetOptions = ["Tümü", "BTC", "ETH", "THYAO", "GARAN", "ASELS", "Maaş", "Kira"]
const typeOptions = ["Tümü", "Alış", "Satış", "Temettü", "Gelir", "Gider"]

export default function TransactionsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState("Tümü")
  const [categoryFilter, setCategoryFilter] = useState("Tümü")
  const [assetFilter, setAssetFilter] = useState("Tümü")
  const [startDate, setStartDate] = useState("")
  const [endDate, setEndDate] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [showOcrModal, setShowOcrModal] = useState(false)
  const [showVoiceModal, setShowVoiceModal] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const itemsPerPage = 10

  // Filter transactions
  const filteredTransactions = transactions.filter((t) => {
    const matchesSearch = t.asset.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         t.assetName.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = typeFilter === "Tümü" || 
                       typeConfig[t.type]?.label.toLowerCase() === typeFilter.toLowerCase()
    const matchesCategory = categoryFilter === "Tümü" || t.category === categoryFilter
    const matchesAsset = assetFilter === "Tümü" || t.asset === assetFilter
    
    let matchesDate = true
    if (startDate) {
      matchesDate = matchesDate && new Date(t.date) >= new Date(startDate)
    }
    if (endDate) {
      matchesDate = matchesDate && new Date(t.date) <= new Date(endDate)
    }
    
    return matchesSearch && matchesType && matchesCategory && matchesAsset && matchesDate
  })

  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage)
  const paginatedTransactions = filteredTransactions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  )

  const clearFilters = () => {
    setSearchTerm("")
    setTypeFilter("Tümü")
    setCategoryFilter("Tümü")
    setAssetFilter("Tümü")
    setStartDate("")
    setEndDate("")
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'short', year: 'numeric' })
  }

  return (
    <DashboardLayout>
      {/* TOP BAR */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-semibold text-[#F0F2F7]">Islemler</h1>
          <p className="text-sm text-[#8892A4]">Alim ve satim islemlerinizi goruntuyleyin</p>
        </div>
        <button className="flex items-center gap-2 px-5 py-2.5 bg-[#00D4AA] rounded-lg text-sm font-medium text-[#080A0F] hover:bg-[#00D4AA]/90 transition-colors">
          <Plus className="w-4 h-4" />
          Islem Ekle
        </button>
      </div>

      {/* FILTER BAR */}
      <div className="finos-card p-4 mb-6">
        <div className="flex flex-wrap items-center gap-3">
          {/* Date Range */}
          <div className="flex items-center gap-2">
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#4E5A6B]" />
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                placeholder="Baslangic"
                className="pl-10 pr-3 py-2 w-40 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA] transition-colors"
              />
            </div>
            <span className="text-[#4E5A6B]">→</span>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#4E5A6B]" />
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                placeholder="Bitis"
                className="pl-10 pr-3 py-2 w-40 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA] transition-colors"
              />
            </div>
          </div>

          {/* Type Dropdown */}
          <div className="relative">
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="appearance-none pl-3 pr-8 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA] transition-colors cursor-pointer"
            >
              {typeOptions.map((opt) => (
                <option key={opt} value={opt}>{opt === "Tümü" ? "Tür" : opt}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-[#4E5A6B] pointer-events-none" />
          </div>

          {/* Category Dropdown */}
          <div className="relative">
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="appearance-none pl-3 pr-8 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA] transition-colors cursor-pointer"
            >
              {categoryOptions.map((opt) => (
                <option key={opt} value={opt}>{opt === "Tümü" ? "Kategori" : opt}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-[#4E5A6B] pointer-events-none" />
          </div>

          {/* Asset Dropdown */}
          <div className="relative">
            <select
              value={assetFilter}
              onChange={(e) => setAssetFilter(e.target.value)}
              className="appearance-none pl-3 pr-8 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#F0F2F7] focus:outline-none focus:border-[#00D4AA] transition-colors cursor-pointer"
            >
              {assetOptions.map((opt) => (
                <option key={opt} value={opt}>{opt === "Tümü" ? "Varlık" : opt}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-[#4E5A6B] pointer-events-none" />
          </div>

          {/* Search Input */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#4E5A6B]" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="GARAN, BTC, ETH ara..."
              className="w-full pl-10 pr-4 py-2 bg-[#151A23] border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#F0F2F7] placeholder:text-[#4E5A6B] focus:outline-none focus:border-[#00D4AA] transition-colors"
            />
          </div>

          {/* Filter Buttons */}
          <button className="px-4 py-2 bg-[#00D4AA] rounded-lg text-sm font-medium text-[#080A0F] hover:bg-[#00D4AA]/90 transition-colors">
            Filtrele
          </button>
          <button 
            onClick={clearFilters}
            className="px-4 py-2 bg-transparent border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)] transition-colors"
          >
            Temizle
          </button>
        </div>
      </div>

      {/* ACTION BAR */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <h2 className="text-lg font-semibold text-[#F0F2F7]">Islem Gecmisi</h2>
          <span className="px-2 py-0.5 bg-[rgba(0,212,170,0.15)] text-[#00D4AA] text-xs font-medium rounded-full">
            {filteredTransactions.length}
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-[#4E5A6B]">Disa Aktar:</span>
          <button className="flex items-center gap-1.5 px-3 py-1.5 bg-[rgba(255,71,87,0.15)] rounded-lg text-sm text-[#FF4757] hover:bg-[rgba(255,71,87,0.25)] transition-colors">
            <FileText className="w-4 h-4" />
            PDF
          </button>
          <button className="flex items-center gap-1.5 px-3 py-1.5 bg-[rgba(0,212,170,0.15)] rounded-lg text-sm text-[#00D4AA] hover:bg-[rgba(0,212,170,0.25)] transition-colors">
            <FileSpreadsheet className="w-4 h-4" />
            Excel
          </button>
          <div className="w-px h-6 bg-[rgba(255,255,255,0.06)]" />
          <button 
            onClick={() => setShowOcrModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[rgba(255,184,51,0.15)] rounded-lg text-sm text-[#FFB833] hover:bg-[rgba(255,184,51,0.25)] transition-colors"
          >
            <Camera className="w-4 h-4" />
            Fis Tara
          </button>
          <button 
            onClick={() => setShowVoiceModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[rgba(167,139,250,0.15)] rounded-lg text-sm text-[#A78BFA] hover:bg-[rgba(167,139,250,0.25)] transition-colors"
          >
            <Mic className="w-4 h-4" />
            Sesli Gir
          </button>
        </div>
      </div>

      {/* TABLE */}
      <div className="finos-card overflow-hidden mb-4">
        <div className="overflow-x-auto finos-scrollbar">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[rgba(255,255,255,0.06)]">
                <th className="text-left p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Tarih</th>
                <th className="text-left p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Varlik</th>
                <th className="text-left p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Tur</th>
                <th className="text-right p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Miktar</th>
                <th className="text-right p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Fiyat</th>
                <th className="text-right p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Toplam</th>
                <th className="text-right p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Komisyon</th>
                <th className="text-left p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Notlar</th>
                <th className="text-center p-4 text-xs font-medium text-[#4E5A6B] uppercase tracking-wider">Aksiyon</th>
              </tr>
            </thead>
            <tbody>
              {paginatedTransactions.length > 0 ? (
                paginatedTransactions.map((t) => {
                  const typeInfo = typeConfig[t.type]
                  return (
                    <tr 
                      key={t.id}
                      className="border-b border-[rgba(255,255,255,0.03)] hover:bg-[rgba(255,255,255,0.02)] transition-colors"
                    >
                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-[#4E5A6B]" />
                          <span className="text-sm text-[#8892A4]">{formatDate(t.date)}</span>
                        </div>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-[#151A23] flex items-center justify-center">
                            <span className="text-xs font-bold text-[#F0F2F7]">
                              {t.asset.slice(0, 2).toUpperCase()}
                            </span>
                          </div>
                          <div>
                            <span className="text-sm font-medium text-[#F0F2F7]">{t.asset}</span>
                            <span className="text-xs text-[#4E5A6B] ml-1">— {t.assetName}</span>
                          </div>
                        </div>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <span 
                            className="px-2.5 py-1 text-xs font-medium rounded-md"
                            style={{ color: typeInfo.color, backgroundColor: typeInfo.bg }}
                          >
                            {typeInfo.label}
                          </span>
                          {t.category && (
                            <span className="px-2 py-0.5 text-xs text-[#8892A4] bg-[rgba(255,255,255,0.04)] rounded">
                              {t.category}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="p-4 text-right">
                        <span className="text-sm font-mono text-[#F0F2F7]">
                          {t.quantity !== null ? (t.quantity < 10 ? t.quantity.toFixed(4) : t.quantity.toLocaleString('tr-TR')) : "—"}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <span className="text-sm font-mono text-[#8892A4]">
                          {t.price !== null ? formatCurrency(t.price) : "—"}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <span 
                          className="text-sm font-mono font-medium"
                          style={{ color: t.total < 0 ? "#FF4757" : typeInfo.color }}
                        >
                          {t.total < 0 ? "" : "+"}{formatCurrency(Math.abs(t.total))}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <span className="text-sm font-mono text-[#4E5A6B]">
                          {t.commission !== null ? formatCurrency(t.commission) : "—"}
                        </span>
                      </td>
                      <td className="p-4">
                        <span className="text-sm text-[#8892A4]">
                          {t.notes || "—"}
                        </span>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-center gap-2">
                          <button className="p-1.5 rounded-lg hover:bg-[rgba(255,255,255,0.04)] transition-colors group">
                            <Pencil className="w-4 h-4 text-[#4E5A6B] group-hover:text-[#F0F2F7]" />
                          </button>
                          <button className="p-1.5 rounded-lg hover:bg-[rgba(255,71,87,0.1)] transition-colors group">
                            <Trash2 className="w-4 h-4 text-[#4E5A6B] group-hover:text-[#FF4757]" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                })
              ) : (
                // Skeleton loading rows
                [1, 2, 3].map((i) => (
                  <tr key={i} className="border-b border-[rgba(255,255,255,0.03)]">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((j) => (
                      <td key={j} className="p-4">
                        <div className="h-4 bg-[#151A23] rounded animate-pulse" />
                      </td>
                    ))}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* PAGINATION */}
      <div className="flex items-center justify-between">
        <span className="text-sm text-[#8892A4]">
          {(currentPage - 1) * itemsPerPage + 1}-{Math.min(currentPage * itemsPerPage, filteredTransactions.length)} / {filteredTransactions.length} kayit
        </span>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-2 rounded-lg bg-[#151A23] border border-[rgba(255,255,255,0.06)] text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button 
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="p-2 rounded-lg bg-[#151A23] border border-[rgba(255,255,255,0.06)] text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* OCR MODAL */}
      {showOcrModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <div className="finos-card w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-[#F0F2F7]">Fis Tarama</h3>
              <button 
                onClick={() => setShowOcrModal(false)}
                className="p-1 rounded-lg hover:bg-[rgba(255,255,255,0.04)] transition-colors"
              >
                <X className="w-5 h-5 text-[#8892A4]" />
              </button>
            </div>
            
            <div className="border-2 border-dashed border-[rgba(255,255,255,0.1)] rounded-xl p-8 flex flex-col items-center justify-center mb-4 hover:border-[#FFB833] transition-colors cursor-pointer">
              <div className="w-16 h-16 rounded-full bg-[rgba(255,184,51,0.15)] flex items-center justify-center mb-4">
                <Camera className="w-8 h-8 text-[#FFB833]" />
              </div>
              <p className="text-sm text-[#F0F2F7] mb-1">Fotograf cek veya yukle</p>
              <p className="text-xs text-[#4E5A6B]">PNG, JPG, PDF desteklenir</p>
            </div>
            
            <p className="text-xs text-[#8892A4] text-center mb-6">
              Yapay zeka fisi okuyarak islemi otomatik ekler
            </p>
            
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setShowOcrModal(false)}
                className="flex-1 px-4 py-2.5 bg-transparent border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)] transition-colors"
              >
                Iptal
              </button>
              <button className="flex-1 px-4 py-2.5 bg-[#FFB833] rounded-lg text-sm font-medium text-[#080A0F] hover:bg-[#FFB833]/90 transition-colors">
                Tara
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VOICE INPUT MODAL */}
      {showVoiceModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <div className="finos-card w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-[#F0F2F7]">Sesli Giris</h3>
              <button 
                onClick={() => {
                  setShowVoiceModal(false)
                  setIsRecording(false)
                }}
                className="p-1 rounded-lg hover:bg-[rgba(255,255,255,0.04)] transition-colors"
              >
                <X className="w-5 h-5 text-[#8892A4]" />
              </button>
            </div>
            
            <div className="flex flex-col items-center mb-6">
              {/* Waveform Animation */}
              <div className="flex items-center gap-1 h-16 mb-4">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div 
                    key={i}
                    className={`w-2 bg-[#A78BFA] rounded-full transition-all duration-150 ${
                      isRecording ? 'animate-pulse' : ''
                    }`}
                    style={{ 
                      height: isRecording ? `${20 + Math.random() * 40}px` : '8px',
                      animationDelay: `${i * 100}ms`
                    }}
                  />
                ))}
              </div>
              
              <p className="text-sm text-[#F0F2F7] mb-2">
                {isRecording ? "Dinleniyor..." : "Konusun..."}
              </p>
              <p className="text-xs text-[#4E5A6B]">
                Ornek: &quot;Bugun Migros&apos;ta 340 TL harcadim&quot;
              </p>
            </div>
            
            {/* Live transcript area */}
            <div className="bg-[#151A23] rounded-lg p-4 min-h-[80px] mb-6">
              {isRecording ? (
                <p className="text-sm text-[#8892A4] animate-pulse">Ses algilaniyor...</p>
              ) : (
                <p className="text-sm text-[#4E5A6B]">Transcript burada gorunecek</p>
              )}
            </div>
            
            <div className="flex items-center gap-3">
              <button 
                onClick={() => {
                  setShowVoiceModal(false)
                  setIsRecording(false)
                }}
                className="flex-1 px-4 py-2.5 bg-transparent border border-[rgba(255,255,255,0.06)] rounded-lg text-sm text-[#8892A4] hover:bg-[rgba(255,255,255,0.04)] transition-colors"
              >
                Iptal
              </button>
              <button 
                onClick={() => setIsRecording(!isRecording)}
                className={`flex-1 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isRecording 
                    ? 'bg-[#FF4757] text-white hover:bg-[#FF4757]/90' 
                    : 'bg-[#A78BFA] text-[#080A0F] hover:bg-[#A78BFA]/90'
                }`}
              >
                {isRecording ? "Durdur" : "Basla"}
              </button>
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  )
}
