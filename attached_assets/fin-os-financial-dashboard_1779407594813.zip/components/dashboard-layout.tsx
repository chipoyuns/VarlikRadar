"use client"

import { AppSidebar } from "./app-sidebar"
import { useState, useEffect } from "react"

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  // Listen for sidebar collapse state (you could use context/state management for this)
  useEffect(() => {
    const checkSidebar = () => {
      const sidebar = document.querySelector('aside')
      if (sidebar) {
        setSidebarCollapsed(sidebar.classList.contains('w-[72px]'))
      }
    }
    
    const observer = new MutationObserver(checkSidebar)
    const sidebar = document.querySelector('aside')
    if (sidebar) {
      observer.observe(sidebar, { attributes: true, attributeFilter: ['class'] })
    }
    
    return () => observer.disconnect()
  }, [])

  return (
    <div className="min-h-screen bg-[#080A0F] relative noise-overlay">
      <AppSidebar />
      <main 
        className="transition-all duration-300 min-h-screen"
        style={{ marginLeft: sidebarCollapsed ? '72px' : '200px' }}
      >
        <div className="p-6 relative z-10">
          {children}
        </div>
      </main>
    </div>
  )
}
