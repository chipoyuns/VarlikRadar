import { cn } from "@/lib/utils"

interface StatCardProps {
  title: string
  value: string
  change?: number
  changeLabel?: string
  icon?: React.ReactNode
  trend?: "up" | "down" | "neutral"
  className?: string
}

export function StatCard({ 
  title, 
  value, 
  change, 
  changeLabel, 
  icon, 
  trend = "neutral",
  className 
}: StatCardProps) {
  return (
    <div className={cn("finos-card p-5", className)}>
      <div className="flex items-start justify-between mb-3">
        <span className="text-[#8892A4] text-sm font-medium">{title}</span>
        {icon && (
          <div className="w-9 h-9 rounded-lg bg-[#151A23] flex items-center justify-center">
            {icon}
          </div>
        )}
      </div>
      <div className="space-y-1">
        <p className="text-2xl font-semibold font-mono text-[#F0F2F7]">{value}</p>
        {change !== undefined && (
          <div className="flex items-center gap-2">
            <span
              className={cn(
                "text-sm font-medium font-mono",
                trend === "up" && "text-[#00D4AA]",
                trend === "down" && "text-[#FF4757]",
                trend === "neutral" && "text-[#8892A4]"
              )}
            >
              {trend === "up" && "+"}
              {change.toLocaleString('tr-TR')}%
            </span>
            {changeLabel && (
              <span className="text-xs text-[#4E5A6B]">{changeLabel}</span>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

interface MetricBadgeProps {
  value: number
  suffix?: string
  trend?: "up" | "down"
  size?: "sm" | "md"
}

export function MetricBadge({ value, suffix = "%", trend, size = "md" }: MetricBadgeProps) {
  const isPositive = value >= 0
  const displayTrend = trend ?? (isPositive ? "up" : "down")
  
  return (
    <span
      className={cn(
        "font-mono font-medium inline-flex items-center gap-1 px-2 py-0.5 rounded-md",
        displayTrend === "up" && "text-[#00D4AA] bg-[rgba(0,212,170,0.1)]",
        displayTrend === "down" && "text-[#FF4757] bg-[rgba(255,71,87,0.1)]",
        size === "sm" && "text-xs",
        size === "md" && "text-sm"
      )}
    >
      {isPositive && "+"}
      {value.toLocaleString('tr-TR')}{suffix}
    </span>
  )
}

export function formatCurrency(value: number, currency: string = "TRY"): string {
  return new Intl.NumberFormat('tr-TR', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value)
}

export function formatNumber(value: number, decimals: number = 2): string {
  return new Intl.NumberFormat('tr-TR', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value)
}

export function SkeletonCard({ className }: { className?: string }) {
  return (
    <div className={cn("finos-card p-5", className)}>
      <div className="space-y-3">
        <div className="h-4 w-24 skeleton-shimmer rounded" />
        <div className="h-8 w-32 skeleton-shimmer rounded" />
        <div className="h-3 w-20 skeleton-shimmer rounded" />
      </div>
    </div>
  )
}

export function SkeletonChart({ className }: { className?: string }) {
  return (
    <div className={cn("finos-card p-5", className)}>
      <div className="h-4 w-32 skeleton-shimmer rounded mb-4" />
      <div className="h-[200px] skeleton-shimmer rounded" />
    </div>
  )
}
