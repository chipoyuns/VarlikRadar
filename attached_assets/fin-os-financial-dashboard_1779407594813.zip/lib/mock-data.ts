// Mock data for FinOS dashboard - Portföyüm Page

export const portfolioSummary = {
  netAsset: 3891094.61,
  totalAsset: 3891094.61,
  totalDebt: 0,
  totalROI: 3.09,
  totalProfit: 116633.08,
  dailyPnL: 0,
  dailyPnLPercent: 0,
  cryptoPnL: 116633.08,
  cryptoPnLPercent: 3.09,
  bestPerformer: "BTC",
  bestPerformerChange: 3.09,
}

export const riskMetrics = {
  level: "Agresif",
  score: 10.0,
  maxScore: 10,
  cryptoWeight: 100.0,
  volatility: 3.1,
  concentration: 100.0,
}

export const assetAllocation = [
  { name: "Kripto Paralar", value: 100, amount: 3891094.61, color: "#FFB833" },
]

export const balancePerformance = [
  { month: "Haz", value: 0 },
  { month: "Tem", value: 15000 },
  { month: "Ağu", value: 35000 },
  { month: "Eyl", value: 52000 },
  { month: "Eki", value: 68000 },
  { month: "Kas", value: 85000 },
  { month: "Ara", value: 95000 },
  { month: "Oca", value: 102000 },
  { month: "Şub", value: 108000 },
  { month: "Mar", value: 115000 },
  { month: "Nis", value: 120000 },
  { month: "May", value: 123633 },
]

export const holdings = [
  { 
    symbol: "BTC", 
    name: "bitcoin", 
    type: "Kripto",
    exchange: "Diğer",
    quantity: 1.1, 
    avgCost: 75295.33,
    avgCostCurrency: "USD",
    currentPrice: 77622.00,
    currentPriceCurrency: "USD",
    totalValue: 85384.20,
    totalValueCurrency: "TRY",
    change: 3.09,
    pnl: 2559.34,
    pnlCurrency: "TRY",
    logo: "/btc-logo.png"
  },
]

export const portfolioHealthScore = {
  overall: 42,
  maxScore: 100,
  subscores: [
    { name: "Çeşitlilik", score: 20, maxScore: 100, color: "#FF4757" },
    { name: "Risk Dengesi", score: 30, maxScore: 100, color: "#FF4757" },
    { name: "Nakit Oranı", score: 85, maxScore: 100, color: "#00D4AA" },
    { name: "Borç Durumu", score: 100, maxScore: 100, color: "#00D4AA" },
  ],
  recommendations: [
    { type: "warning", title: "Çeşitlendirme Gerekli", description: "Portföyünüz tek varlık türüne yoğunlaşmış durumda." },
    { type: "info", title: "Hisse Ekleyin", description: "Hisse senedi ekleyerek riskinizi dağıtabilirsiniz." },
    { type: "tip", title: "ETF Önerisi", description: "Pasif gelir için temettü ETF'leri değerlendirin." },
  ]
}

export const insightMessages = [
  "BTC performansı: +%3.1",
  "Konsantrasyon riski: En büyük varlık %100",
  "Kripto günlük kâr: +₺116.633",
  "1 varlık izleniyor",
  "Yüksek risk profili — çeşitlendirme önerilir",
]

// Additional data for other pages
export const recentTransactions = [
  { id: 1, type: "buy", symbol: "BTC", name: "Bitcoin", quantity: 0.5, price: 75000, total: 37500, date: "2024-09-15", currency: "USD" },
  { id: 2, type: "buy", symbol: "BTC", name: "Bitcoin", quantity: 0.3, price: 74500, total: 22350, date: "2024-09-10", currency: "USD" },
  { id: 3, type: "buy", symbol: "BTC", name: "Bitcoin", quantity: 0.3, price: 76000, total: 22800, date: "2024-09-05", currency: "USD" },
]

export const budgetCategories = [
  { name: "Konut", budget: 15000, spent: 14500, icon: "Home" },
  { name: "Market", budget: 8000, spent: 6234, icon: "ShoppingCart" },
  { name: "Ulaşım", budget: 3000, spent: 2890, icon: "Car" },
  { name: "Eğlence", budget: 4000, spent: 3200, icon: "Gamepad2" },
  { name: "Sağlık", budget: 2000, spent: 850, icon: "Heart" },
  { name: "Eğitim", budget: 3500, spent: 3500, icon: "GraduationCap" },
  { name: "Yatırım", budget: 20000, spent: 18500, icon: "TrendingUp" },
  { name: "Diğer", budget: 5000, spent: 2100, icon: "MoreHorizontal" },
]

export const financialGoals = [
  { id: 1, name: "Emeklilik Fonu", target: 5000000, current: 1247832, deadline: "2045", icon: "Umbrella", priority: "high" },
  { id: 2, name: "Ev Peşinatı", target: 800000, current: 320000, deadline: "2026", icon: "Home", priority: "high" },
  { id: 3, name: "Acil Durum Fonu", target: 150000, current: 145000, deadline: "2024", icon: "Shield", priority: "medium" },
  { id: 4, name: "Tatil Fonu", target: 50000, current: 28000, deadline: "2025", icon: "Plane", priority: "low" },
  { id: 5, name: "Araba", target: 600000, current: 180000, deadline: "2027", icon: "Car", priority: "medium" },
]

export const debts = [
  { id: 1, name: "Konut Kredisi", total: 850000, remaining: 620000, monthlyPayment: 12500, interestRate: 1.89, dueDate: "2035-06", type: "mortgage" },
  { id: 2, name: "Taşıt Kredisi", total: 250000, remaining: 85000, monthlyPayment: 5200, interestRate: 2.49, dueDate: "2025-12", type: "auto" },
  { id: 3, name: "Kredi Kartı - Akbank", total: 45000, remaining: 45000, monthlyPayment: 4500, interestRate: 4.25, dueDate: "2024-10", type: "credit" },
  { id: 4, name: "Kredi Kartı - Yapı Kredi", total: 28000, remaining: 28000, monthlyPayment: 2800, interestRate: 4.15, dueDate: "2024-10", type: "credit" },
]

export const incomeVsExpense = [
  { month: "Oca", income: 85000, expense: 52000 },
  { month: "Şub", income: 87000, expense: 48000 },
  { month: "Mar", income: 92000, expense: 55000 },
  { month: "Nis", income: 88000, expense: 51000 },
  { month: "May", income: 95000, expense: 58000 },
  { month: "Haz", income: 102000, expense: 62000 },
  { month: "Tem", income: 98000, expense: 54000 },
  { month: "Ağu", income: 105000, expense: 59000 },
  { month: "Eyl", income: 110000, expense: 56000 },
]

export const aiInsights = [
  {
    id: 1,
    type: "opportunity",
    title: "Yatırım Fırsatı",
    message: "THYAO hissesi momentum göstergelerine göre güçlü bir yükseliş trendinde. Son 3 ayda %32 getiri sağladı.",
    action: "Portföyünüzü %5 artırabilirsiniz",
    confidence: 87,
  },
  {
    id: 2,
    type: "warning",
    title: "Bütçe Uyarısı",
    message: "Eğlence kategorisinde bütçenizin %80'ini harcadınız ve ayın sonuna 12 gün kaldı.",
    action: "Günlük harcama limitini ₺120 olarak ayarlayın",
    confidence: 94,
  },
  {
    id: 3,
    type: "insight",
    title: "Tasarruf Önerisi",
    message: "Mevcut tasarruf oranınız %28. Hedeflerinize ulaşmak için bu oranı %32'ye çıkarmanız önerilir.",
    action: "Aylık ₺3,500 daha tasarruf edin",
    confidence: 91,
  },
  {
    id: 4,
    type: "alert",
    title: "Borç Uyarısı",
    message: "Kredi kartı borcunuz yüksek faiz biriktiriyor. Öncelikli ödeme yapmanız önerilir.",
    action: "Bu ay ₺15,000 ek ödeme yapın",
    confidence: 96,
  },
]

export const simulatorScenarios = [
  { name: "Agresif Büyüme", annualReturn: 15, risk: "Yüksek", allocation: { stock: 70, crypto: 20, bond: 5, gold: 5 } },
  { name: "Dengeli", annualReturn: 10, risk: "Orta", allocation: { stock: 50, crypto: 10, bond: 25, gold: 15 } },
  { name: "Muhafazakar", annualReturn: 6, risk: "Düşük", allocation: { stock: 30, crypto: 5, bond: 45, gold: 20 } },
]

export const marketIndices = [
  { name: "BIST 100", value: 9234.56, change: 1.23 },
  { name: "S&P 500", value: 5432.10, change: 0.45 },
  { name: "BTC/USD", value: 67234.50, change: 3.21 },
  { name: "EUR/TRY", value: 36.45, change: -0.12 },
  { name: "Altın/gr", value: 2845.00, change: 0.87 },
]

export const notifications = [
  { id: 1, type: "price", message: "THYAO hedef fiyata ulaştı: ₺245", time: "5 dk önce" },
  { id: 2, type: "budget", message: "Market bütçenizin %78'i kullanıldı", time: "1 saat önce" },
  { id: 3, type: "goal", message: "Acil Durum Fonu hedefinize %97 ulaştınız!", time: "3 saat önce" },
  { id: 4, type: "dividend", message: "TUPRS temettü ödemesi: ₺1,350", time: "1 gün önce" },
]
