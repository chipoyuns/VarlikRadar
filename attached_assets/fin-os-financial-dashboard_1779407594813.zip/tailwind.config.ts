import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['var(--font-dm-sans)', 'DM Sans', 'system-ui', 'sans-serif'],
        mono: ['var(--font-jetbrains)', 'JetBrains Mono', 'monospace'],
      },
      colors: {
        // FinOS Custom Colors
        finos: {
          bg: {
            deepest: '#080A0F',
            card: '#0E1117',
            inner: '#151A23',
          },
          text: {
            primary: '#F0F2F7',
            secondary: '#8892A4',
            tertiary: '#4E5A6B',
          },
          accent: {
            green: '#00D4AA',
            red: '#FF4757',
            blue: '#4B9EFF',
            gold: '#FFB833',
            purple: '#A78BFA',
          },
        },
      },
      borderRadius: {
        '2xl': '1rem',
        '3xl': '1.5rem',
      },
      animation: {
        'marquee': 'marquee 30s linear infinite',
        'flash-green': 'flash-green 0.5s ease-out',
        'flash-red': 'flash-red 0.5s ease-out',
      },
      keyframes: {
        marquee: {
          '0%': { transform: 'translateX(0%)' },
          '100%': { transform: 'translateX(-50%)' },
        },
        'flash-green': {
          '0%': { color: '#00D4AA', textShadow: '0 0 10px rgba(0, 212, 170, 0.5)' },
          '100%': { color: 'inherit', textShadow: 'none' },
        },
        'flash-red': {
          '0%': { color: '#FF4757', textShadow: '0 0 10px rgba(255, 71, 87, 0.5)' },
          '100%': { color: 'inherit', textShadow: 'none' },
        },
      },
      backdropBlur: {
        xs: '2px',
      },
    },
  },
  plugins: [],
};

export default config;
